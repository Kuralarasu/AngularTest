module.exports = require('./lib/sockjs');
