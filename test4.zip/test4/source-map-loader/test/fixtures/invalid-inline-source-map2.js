without SourceMap
// @sourceMappingURL=data:application/source-map;base64,invalid/base64=
// comment