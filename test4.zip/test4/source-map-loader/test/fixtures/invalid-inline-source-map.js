without SourceMap
// @sourceMappingURL=data:application/source-map;base64,"something invalid"
// comment