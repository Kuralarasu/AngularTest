export declare function isFile(filePath: string): boolean;
export declare function isDirectory(filePath: string): boolean;
