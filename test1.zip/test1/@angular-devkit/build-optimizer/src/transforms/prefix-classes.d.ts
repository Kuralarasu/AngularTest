import * as ts from 'typescript';
export declare function testPrefixClasses(content: string): boolean;
export declare function getPrefixClassesTransformer(): ts.TransformerFactory<ts.SourceFile>;
