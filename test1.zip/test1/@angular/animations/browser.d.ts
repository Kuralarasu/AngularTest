/**
 * @license Angular v4.4.5
 * (c) 2010-2017 Google, Inc. https://angular.io/
 * License: MIT
 */ 
 export * from './browser/index'
