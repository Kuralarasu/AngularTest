import { Provider } from '@angular/core';
export declare const OVERLAY_PROVIDERS: Provider[];
export declare class OverlayModule {
}
