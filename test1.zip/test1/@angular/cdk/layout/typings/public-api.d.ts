export declare class LayoutModule {
}
export { BreakpointObserver, BreakpointState } from './breakpoints-observer';
export { Breakpoints } from './breakpoints';
export { MediaMatcher } from './media-matcher';
