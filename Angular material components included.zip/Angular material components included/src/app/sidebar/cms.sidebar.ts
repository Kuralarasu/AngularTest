import { Component } from '@angular/core';

@Component({
  selector: 'cms-sidebar',
  templateUrl: './cms.sidebar.html'
})
export class SidebarComponent {
}
