import { Component,OnInit } from '@angular/core';
import { StudyModuleService } from './study.service.component';

@Component({
  selector: 'study-module',
  templateUrl: './cms.study-module.html'
})
export class StudyModuleComponent {
  client=[];
  studyid=[];
  constructor(private _studySevice:StudyModuleService){}
  ngOnInit()
  {
    this._studySevice.getClient().subscribe(resClient=>this.client=resClient);
    this._studySevice.getClient().subscribe(resClient=>this.studyid=resClient);
  }
}
