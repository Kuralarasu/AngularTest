import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { StudyModuleComponent } from './maincontent/studymodule/cms.study-module';
import { AppComponent } from './app.component';

const appRoutes:Routes=[
{ path: 'study', component: StudyModuleComponent,pathMatch: 'full'},
{ path: '',  component: AppComponent, pathMatch: 'full' }
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      appRoutes,
      {
        enableTracing: true
      }
    )
  ],
  exports: [
    RouterModule
  ],
  providers: [  ]
})
export class AppRoutingComponent { }
export const routingComponents=[StudyModuleComponent,AppComponent];
