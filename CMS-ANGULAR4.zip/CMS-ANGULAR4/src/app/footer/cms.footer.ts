import { Component } from '@angular/core';

@Component({
  selector: 'cms-footer',
  templateUrl: './cms.footer.html'
 
})
export class FooterComponent {
}
