import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppMaterialModule } from './app-material.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/cms.header';
import { SidebarComponent }  from './sidebar/cms.sidebar';
import { FooterComponent }  from './footer/cms.footer';
import { StudyModuleComponent } from './maincontent/studymodule/cms.study-module';
import { AppRoutingComponent }      from './app.routing.component';
import { StudyModuleService } from './maincontent/studymodule/study.service.component';
import {routingComponents} from './app.routing.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SidebarComponent,
    FooterComponent,
    routingComponents
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,   
    AppMaterialModule,    
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingComponent
  ],
  providers: [StudyModuleService],
  
  bootstrap: [AppComponent]
})
export class AppModule { }
