import {Http,Response } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';

@Injectable()
export class StudyModuleService {
     url="http://dfwdw0app022.ent.covance.com:3888/api/Home/GetProposalDetails?studyCode=8285-349";  

     constructor(private http:Http){}
     getClient(){

        return this.http.get(this.url)
        .map((response:Response)=>response.json());
     }
     getStudy(){
        
                return this.http.get("http://dfwdw0app022.ent.covance.com:3888/api/Home/GetStudy?studyCode=8285-349").map((response:Response)=>response.json());
             }
}