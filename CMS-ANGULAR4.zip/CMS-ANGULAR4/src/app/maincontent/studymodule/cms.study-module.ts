import { Component,OnInit } from '@angular/core';
import { StudyModuleService } from './study.service.component';
import {FormControl} from '@angular/forms';
import {Observable} from 'rxjs/Observable';
import {startWith} from 'rxjs/operators/startWith';
import {map} from 'rxjs/operators/map';

@Component({
  selector: 'study-module',
  templateUrl: './cms.study-module.html'
})
export class StudyModuleComponent {

  myControl: FormControl = new FormControl();
  
    options = [
      'One',
      'Two',
      'Three'
    ];
  
    filteredOptions: Observable<string[]>;
  client=[];
  studyid=[];
  constructor(private _studySevice:StudyModuleService){}
  ngOnInit()
  {
    this.filteredOptions = this.myControl.valueChanges
    .pipe(
      startWith(''),
      map(val => this.filter(val))
    );
    this._studySevice.getClient().subscribe(resClient=>this.client=resClient);
    this._studySevice.getStudy().subscribe(resClient=>this.studyid=resClient);
  }
  filter(val: string): string[] {
    return this.options.filter(option =>
      option.toLowerCase().indexOf(val.toLowerCase()) === 0);
  }

}
