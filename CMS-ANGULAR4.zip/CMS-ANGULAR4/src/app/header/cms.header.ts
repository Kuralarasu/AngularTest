import { Component } from '@angular/core';

@Component({
  selector: 'cms-header',
  templateUrl: './cms.header.html'
 
})
export class HeaderComponent {
}
