import { NgModule } from '@angular/core';
import { RouterModule, Routes, RouterLinkActive } from '@angular/router';
import { StudyComponent } from './maincontent/studymodule/study.component';
import { UnderDevComponent } from './maincontent/underdev.component';
import { NotAuthorised } from './maincontent/auth.component';
import { ReportsComponent } from './maincontent/reportsmodule/reports.component';
import { StudyDetailComponent } from './maincontent/studymodule/study-details/study-detail.component';
import { LoginComponent } from './login/login.component';
import { AuthGuardService } from './authentication/services/auth-guard.service';
import { HomeComponent } from './home.component';
import { AppComponent } from './app.component';
const appRoutes: Routes = [

  {
    path: 'home', component: HomeComponent,
    children: [
      { path: 'login', component: LoginComponent },
      {
        path: 'app', component: AppComponent,//canActivateChild: [ AuthGuardService ],
        children: [
          { path: 'study', component: StudyComponent },//, canActivateChild: [ AuthGuardService ] 
          { path: 'proposal', component: UnderDevComponent },
          { path: 'contact-report', component: UnderDevComponent },
          { path: 'report', component: ReportsComponent},
          { path: 'client', component: UnderDevComponent },
          { path: 'admin', component: UnderDevComponent,canActivate: [ AuthGuardService ] },
          { path: 'invalid', component: NotAuthorised },
          { path: '', redirectTo: 'study', pathMatch: 'full' },
          { path: '**', redirectTo: 'study', pathMatch: 'full' },
        ]
      },
      { path: '', redirectTo: 'login', pathMatch: 'full' },
      { path: '**', redirectTo: 'login', pathMatch: 'full' }
    ]
  },
  
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: '**', redirectTo: 'home', pathMatch: 'full' }
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      appRoutes,
       { useHash: true }
      
    )
  ],
  exports: [
    RouterModule
  ],
  providers: []
})
export class AppRoutingModule { }
export const routingComponents = [StudyComponent, UnderDevComponent, ReportsComponent];

