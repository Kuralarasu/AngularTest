import { Component,ViewChild } from '@angular/core';
import { MatTableDataSource,MatPaginator,MatSort } from '@angular/material';
import { Http,Response } from '@angular/http';
import { PhaseService } from '../phase.service';
import { LoadingModule,ANIMATION_TYPES } from 'ngx-loading';

@Component({
  selector: 'phase',
  templateUrl: './phase.html' 
})

export class PhaseComponent 
{
   displayedColumns = ['Details', 'Value', 'Comments'];
   phasedataSourceLength:number=0;
   public phaseLoader = false;
   phasedataSource ;
   @ViewChild(MatPaginator) phasePaginator: MatPaginator;
   @ViewChild(MatSort) sort: MatSort;
   constructor(private _phaseSevice:PhaseService){} 
 
  
   setPhaseDetailDataSource(res)
   {
     this.phasedataSource = new MatTableDataSource(res);
     this.phasedataSource.paginator = this.phasePaginator;
     this.phasedataSource.sort = this.sort;
     this.phasedataSourceLength=this.phasedataSource.data.length; 
   }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.phasedataSource.filter = filterValue;
  }
  
  getPhase(studyNumber,phaseRowId:string)
  {
    this.phaseLoader = true;
    this._phaseSevice.getPhase(studyNumber, phaseRowId).subscribe(res=>{
      this.phaseLoader = false;
      this.setPhaseDetailDataSource(res)});
  }   

  onReset()
  {
    this.phasedataSource=null;  
    this.phasedataSourceLength=0;
  }
  
}

