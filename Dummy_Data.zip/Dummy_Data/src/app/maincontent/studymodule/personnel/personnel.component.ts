import { Component,ViewChild,OnInit } from '@angular/core';
import { MatTableDataSource,MatPaginator,MatSort } from '@angular/material';
import { Http,Response } from '@angular/http';
import { DataSource } from '@angular/cdk/table';
import { PersonnelService } from './personnel.service';
import { LoadingModule,ANIMATION_TYPES } from 'ngx-loading';


@Component({
  selector: 'personnel',
  templateUrl: './personnel.html'
})

export class PersonnelComponent {
  displayedColumns = ['Employee', 'PersonnelType', 'Rank', 'DeptCode'];
  personnelDataSource;
  personnel=[];
  personnelDataSourceLength:number=0;
  public personnelLoader = false;
  showLoading:boolean;
  @ViewChild(MatPaginator) personnelPaginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private _personnelSevice:PersonnelService){} 

  setPersonnelDetailDataSource(res)
  {
    this.personnel=res;
    this.personnelDataSource = new MatTableDataSource(res);
    this.personnelDataSource.paginator = this.personnelPaginator;
    this.personnelDataSource.sort = this.sort;
    this.personnelDataSourceLength=this.personnelDataSource.data.length;
    this.showLoading=false;
  }
    applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.personnelDataSource.filter = filterValue;
  }  

  getPersonnel(studyNumber)
  {
    this.personnelLoader=true;
    this._personnelSevice.getPersonnel(studyNumber).subscribe(res=>{
      this.personnelLoader=false;
      this.setPersonnelDetailDataSource(res)});
    
       }

  
       onReset()
       {
         this.personnelDataSource=null;  
         this.personnelDataSourceLength=0;
         
       }
  
}

