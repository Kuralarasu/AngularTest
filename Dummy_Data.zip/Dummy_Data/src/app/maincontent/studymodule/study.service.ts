import { Http, Response } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { AppConstants } from '../../app-constants';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class StudyService {
    constructor(private http: Http) { }
    getClient(studyNumber) {
        let  url=AppConstants.DD_CLIENT_DETAILS_URL+studyNumber;
        return this.http.get(url)
            .map((response: Response) => response.json())
            .catch((responseError: Response) => Observable.throw(this.errorHandler(responseError)));
    }
    getStudyNumbers(studyNumber,clientId,financialClientId,title) {
        let  url=AppConstants.STUDY_NUMBER_URL+studyNumber+'&clientid='+clientId+'&financialclientid='+financialClientId+'&title='+title;
         return this.http.get(url).map((response: Response) => response.json())
              .catch((responseError: Response) => Observable.throw(this.errorHandler(responseError)));
     }
    getStudyDetails(studyNumber) {
       let  url=AppConstants.STUDY_DETAILS_URL+studyNumber+'&clientId=';
        return this.http.get(url).map((response: Response) => response.json())
             .catch((responseError: Response) => Observable.throw(this.errorHandler(responseError)));
    }
    getAgencyDetails(studyNumber) {
        let  url=AppConstants.STUDY_DETAILS_URL+studyNumber;
        return this.http.get(url)
            .map((response: Response) => response.json());
    }
    getPhaseValues(studyNumber) {
        return this.http.get(AppConstants.DD_PHASE_VALUES_URL+studyNumber)
            .map((response: Response) => response.json());
    }
    errorHandler(responseError: Response) {
        console.log(responseError);
        Observable.throw(responseError != null ? responseError : 'Server Error');
    }
}