import { Http, Response } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { AppConstants } from '../../../app-constants';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class AgencyGuideService {
    constructor(private http: Http) { }

    getAgency(studyNumber) {
        return this.http.get(AppConstants.AGENCY_URL+'studyCode='+studyNumber)
            .map((response: Response) => response.json())
            .catch((responseError: Response) => Observable.throw(this.errorHandler(responseError)));
    }

    getGuide(studyNumber) {
        return this.http.get(AppConstants.GUIDE_LINES_URL+'studyCode='+studyNumber)
            .map((response: Response) => response.json())
            .catch((responseError: Response) => Observable.throw(this.errorHandler(responseError)));
    }
    errorHandler(responseError: Response) {
        console.log(responseError);
        Observable.throw(responseError != null ? responseError : 'Server Error');
    }
}