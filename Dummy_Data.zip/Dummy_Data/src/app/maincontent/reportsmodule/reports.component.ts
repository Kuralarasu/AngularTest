import { Http, Response, ResponseContentType } from '@angular/http';
import { Component, OnInit, OnChanges } from '@angular/core';
import { ReportsService } from './reports-service'
import 'rxjs/Rx';
import { Router, ActivatedRoute } from '@angular/router';
import { Route } from '@angular/router/src/config';
import { MatDialogModule, MatDialog } from '@angular/material';
import {DialogOverviewExampleDialog } from '../../dialog.component';


@Component({
    selector: 'app-report',
    templateUrl: 'reports.html'

})
export class ReportsComponent implements OnInit, OnChanges {
   
    _isReportParameterExpanded: Boolean = false;
    _isReportParameterDisabled: Boolean = true;
    _isChooseReportExpanded: Boolean = false;
    _isChooseReportDisabled: Boolean = true;
    _selectedDeptCodeValue = "";
    _selectedDDValue = "";
    _selectedincludeHumanValue = "";
    _selectedincludeClientNameValue = "";
    clinEndDate;
    clinStrtDate;
    _isPathologyReportParameterHidden: boolean = true;
    _isDiscoveryReportParameterHidden: boolean = true;
    _isReportParameterHidden: boolean = false;
    selectReport: string;
    reports = [
        'PL: Clin Path Workload',
        'Pathology Workload',
        'BA:Discovery Capacity Model',
        'PL: Immunotoxicology workload',
        'In-life feed Projection',
        'Necropsy Workload',
        'PL: Clin Data Completion',
    ];
    deptCode = [
        '5426',
        '5427',
        '5428'
    ];
    includeClientName = [
        'Yes',
        'No'
    ];
    includeHuman = [
        'Yes',
        'No'
    ];
    sites = [
        'Virginia',
        'Wisconsin',
        'UK',
        'Muenster'
    ];
    sortBy = [
        'Feed Type',
        'Species'
    ];
    _reportType = "Necropsy";
    _reportFilter = "Necropsy";
    _site = "Wi";
    _phaseDeptCode = "";
    _sortBy = ""
    _selectedSiteValue: string;
    StartDate;
    EndDate;
    ngOnInit() {
        this.selectReport = " Sheduled Clin Path collection; sorted by date;Promts for start/end date and cost of center; includes collection type, number of sample types, etc";
        this._selectedDDValue = this.reports[0];
        this._selectedDeptCodeValue = this.deptCode[0];
        this._selectedincludeHumanValue = this.includeHuman[0];
        this._selectedincludeClientNameValue = this.includeClientName[0];
        this.clinEndDate = new Date();
        this.clinStrtDate = new Date();
        this._selectedSiteValue = this.sites[0];
        this._sortBy = this.sortBy[0];
        this.StartDate = new Date();
        this.EndDate = new Date();

    }
    ngOnChanges() {
        let reportsInputObj = this.assignInputValues();
        this._service.downloadPDF(reportsInputObj).subscribe(
            (res) => {
                document.querySelector("iframe").src = URL.createObjectURL(res);
            });
    }
    constructor(
        private _service: ReportsService,
        private _router: Router,
        public dialog: MatDialog
    ) {

        let reportsInputObj = this.assignInputValues();
        this._service.downloadPDF(reportsInputObj).subscribe(
            (res) => {
                document.querySelector("iframe").src = URL.createObjectURL(res);
            });
    }
    assignInputValues() {
        let reportsInputObj = {
            DeptCode: this._selectedDeptCodeValue,
            IncludeClientName: this._selectedincludeClientNameValue,
            IncludeHuman: this._selectedincludeHumanValue,
            ClinEndDate: this.clinEndDate,
            ClinStrtDate: this.clinStrtDate,
            ReportName: this._selectedDDValue
        };
        return reportsInputObj;
    }
    assignPathologyInputValues() {
        return {
            DeptCode: this._selectedDeptCodeValue,
            ClinEndDate: this.EndDate,
            clinStrtDate: this.StartDate,
            ReportName: this._selectedDDValue
        };
    }
    assignDiscoveryReportInputValues() {
        return {
            DeptCode: this._selectedDeptCodeValue,
            clinStrtDate: this.StartDate,
            IncludeHuman:this._reportType,
            ReportName: this._selectedDDValue
        };
    }
    downloadPDF() {
        let reportsInputObj;
        if (this._selectedDDValue == "PL: Clin Path Workload") {
            reportsInputObj = this.assignInputValues();
        }

        if (this._selectedDDValue == "Pathology Workload") {
            reportsInputObj = this.assignPathologyInputValues();
        }
        if (this._selectedDDValue == "In-life feed Projection") {
           
        }
        if (this._selectedDDValue == "Necropsy Workload") {
            reportsInputObj = this.assignInputValues();
        }
        if(this._selectedDDValue=="BA:Discovery Capacity Model"){
            reportsInputObj = this.assignDiscoveryReportInputValues(); 
        }
        if(this._selectedDDValue=="PL: Immunotoxicology workload"){

        }
      
        this._service.downloadPDF(reportsInputObj).subscribe(
            (res) => {
                var fileURL = window.URL.createObjectURL(res);
                window.open(fileURL);
            }
        )
    }


    downloadXLS() {
        let reportsInputObj = this.assignInputValues();
        this._service.downloadXLS(reportsInputObj).subscribe(
            (res) => {
                var fileURL = window.URL.createObjectURL(res);
                window.open(fileURL);
            }
        )
    }

    downloadRTF() {
        let reportsInputObj = this.assignInputValues();
        this._service.downloadRTF(reportsInputObj).subscribe(
            (res) => {
                var fileURL = window.URL.createObjectURL(res);
                window.open(fileURL);
            }
        )
    }
    showPdf() {
        let reportsInputObj = this.assignInputValues();
        this._service.downloadPDF(reportsInputObj).subscribe(
        (res) => {
               document.querySelector("iframe").src = URL.createObjectURL(res);
         });
    }
    chooseReport() {
        this._isChooseReportExpanded = true;
        this._isChooseReportDisabled = false;
    }
//next btn clcik on panel
    chooseReportParameter() {
        if (this._selectedDDValue == "PL: Clin Path Workload") {
            this._isReportParameterExpanded = true;
            this._isReportParameterDisabled = false;
            this._isDiscoveryReportParameterHidden = true;
            this._isPathologyReportParameterHidden = true;
            this._isReportParameterHidden = false;
        }
        if (this._selectedDDValue == "Pathology Workload") {
            this._isDiscoveryReportParameterHidden = true;
            this._isPathologyReportParameterHidden = false;
            this._isReportParameterHidden = true;
        }
        if (this._selectedDDValue == "In-life feed Projection") {
            this._isDiscoveryReportParameterHidden = false;
            this._isPathologyReportParameterHidden = true;
            this._isReportParameterHidden = true;
        }
        if(this._selectedDDValue=="BA:Discovery Capacity Model"){
            this._isDiscoveryReportParameterHidden = false;
            this._isPathologyReportParameterHidden = true;
            this._isReportParameterHidden = true;
        }
        if(this._selectedDDValue=="PL: Immunotoxicology workload"){

        }
        if(this._selectedDDValue=="Necropsy Workload"){
            this._isDiscoveryReportParameterHidden =true ;
            this._isPathologyReportParameterHidden = false;
            this._isReportParameterHidden =true ;
        }
    }
    //On change event of report type dropdown
    changeInputParameter(report) {
        //To show the dialog
        if(this._selectedDDValue == 'In-life feed Projection' || 
        this._selectedDDValue == 'PL: Clin Data Completion' || 
        this._selectedDDValue == 'Necropsy Workload'){

            this._isPathologyReportParameterHidden = true;
            this._isDiscoveryReportParameterHidden = true;
            this._isReportParameterHidden = true;
            this.selectReport="";
        let dialogRef = this.dialog.open(DialogOverviewExampleDialog, {
            width: '500px',
            //data: { name: 'this.name', animal: 'this.anima' }
            
          });
         
          dialogRef.afterClosed().subscribe(result => {
            console.log('The dialog was closed');
          });
        }
        if (this._selectedDDValue == "PL: Clin Path Workload") {
            this.selectReport = " Sheduled Clin Path collection; sorted by date;Promts for start/end date and cost of center; includes collection type, number of sample types, etc";
            this._isReportParameterExpanded = true;
            this._isReportParameterDisabled = false;
            this._isReportParameterHidden = false;
            this._isPathologyReportParameterHidden = true;
            this._isDiscoveryReportParameterHidden = true;
        }
        // if (this._selectedDDValue == "Pathology Workload") {
        //     this.selectReport = "Pathology Workload Report";
        //     this._isPathologyReportParameterHidden = false;
        //     this._isReportParameterHidden = true;
        //     this._isDiscoveryReportParameterHidden = true;
        // }
        if (this._selectedDDValue == "BA:Discovery Capacity Model") {
            this.selectReport = "BA:Discovery Capacity Model";
            this._isDiscoveryReportParameterHidden = false;
            this._isPathologyReportParameterHidden = true;
            this._isReportParameterHidden = true;
        }
        if (this._selectedDDValue == "Pathology Workload") {
            this.selectReport="Pathology Workload";
            this._isReportParameterHidden = true;
            this._isPathologyReportParameterHidden =false ;
            this._isDiscoveryReportParameterHidden = true;
        }
    }
}



