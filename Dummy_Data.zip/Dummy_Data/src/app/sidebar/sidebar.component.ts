import { Component } from '@angular/core';
import { AppConstants } from '../app-constants';
import { Globals } from '../globals';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.html'
})
export class SidebarComponent {
  constructor(private _globals:Globals) { 
  }  
}
