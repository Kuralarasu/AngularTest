import { Component,Input,HostListener  } from '@angular/core';
import { Globals } from '../globals';
import { AuthCookie } from '../authentication/services/auth-cookie.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.html'
 
})
export class HeaderComponent {

  // To clear the cookie while closing the window directly
  @HostListener('window:unload', ['$event'])
  handleUnload(event) {
    this.logout();
  }
  @Input() userFullName: string ;
  private redirectUrl: string = '/home/login';
  
  constructor(private _globals:Globals,
    private _authCookie: AuthCookie,
    private router: Router,) { }
  ngOnInit() {      
    this.userFullName=this._globals.fullname;
   // this._globals.fullname;
  }

  logout()
  {
    this._authCookie.deleteAuth();
    this.router.navigate([this.redirectUrl]);
  }
  
}
