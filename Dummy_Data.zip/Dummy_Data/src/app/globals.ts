import { Injectable } from '@angular/core';

@Injectable()
export class Globals {
  numOfStudy: number = 0;
  fullname: string = "Guest";
}