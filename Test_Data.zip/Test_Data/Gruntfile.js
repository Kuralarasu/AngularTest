var path = require('path'),
	fs = require('fs');


const BUILD_TARGET_DIR = 'dist';
const FINAL_BUNDLE_FILENAME = 'web-ui.zip';


const webpack = require("webpack");
const webpackDevMiddleware = require("webpack-dev-middleware");
const serveStatic = require('serve-static');
const compression = require('compression');


module.exports = function (grunt) {

	require("matchdep").filterAll("grunt-*").forEach(grunt.loadNpmTasks);

	var webpackConfig = require("./webpack.config.js");
	var proxiesConfig = require("./proxies.config.js");
	const proxySnippet = require('grunt-connect-proxy/lib/utils').proxyRequest;

	var prepareDevWebpackMiddleware = function () {
		return webpackDevMiddleware(webpack(webpackConfig), {
			devServer: {
				historyApiFallback: true,
				stats: 'minimal'
			}
		});
	};


	grunt.initConfig({
		pkg: grunt.file.readJSON('package.json'),
		// Project settings
		yeoman: {
			//app: require('./bower.json').src || 'src',
			dist: BUILD_TARGET_DIR
		},
		clean: {
			all: ['<%= yeoman.dist %>', FINAL_BUNDLE_FILENAME, 'test-results.xml', 'clean', '.tmp'],
			docs: ['docs']
		},
		webpack: {
			options: require("./config/webpack.prod"),
			build: {
				//THIS IS JUST A PLACEHOLDER FOR THE TASK,
				//ALL THE CONFIGURATION FOR PRODUCTION IS DONE WITHIN THE CONFIG FOLDER
			}
		},
		"webpack-dev-server": {
			options: {
				webpack: webpackConfig
			},
			start: {
				keepAlive: true,
				watch: false,
				webpack: {
					devtool: "eval-source-map",
					debug: true
				}
			}
		},

		ngconstant: {
  // Options for all targets
			options: {
				space: '  ',
				wrap: '"use strict";\n\n module.exports = function(){\n\n return {\%= __ngModule %}\n}',
				name: 'env-config',
			},
			// Environment targets
			dev: {
				options: {
					dest: 'config/env-config.js'
				},
				constants: 'env-config/devEnvConfig.json'
			},
			local: {
				options: {
					dest: 'config/env-config.js'
				},
				constants: 'env-config/localEnvConfig.json'
			},
			sit: {
				options: {
					dest: 'config/env-config.js'
				},
				constants: 'env-config/sitEnvConfig.json'
			},
			asit: {
				options: {
					dest: 'config/env-config.js'
				},
				constants: 'env-config/aSitEnvConfig.json'
			},
			perf: {
				options: {
					dest: 'config/env-config.js'
				},
				constants: 'env-config/perfEnvConfig.json'
			},
			test: {
				options: {
					dest: 'config/env-config.js'
				},
				constants:'env-config/testEnvConfig.json' 
			},
			val: {
				options: {
					dest: 'config/env-config.js'
				},
				constants:'env-config/valEnvConfig.json' 
			},
			pstest: {
				options: {
					dest: 'config/env-config.js'
				},
				constants:'env-config/pstestEnvConfig.json' 
			},
			prod: {
				options: {
					dest: 'config/env-config.js'
				},
				constants:'env-config/prodEnvConfig.json' 
			},
			release: {
				options: {
					dest: 'config/env-config.js'
				},
				constants:'env-config/releaseEnvConfig.json' 
			}
		},
		connect: function () {
			var handler = {
				options: {
					port: 8080,
					hostname: '*',
					livereload: 35729,
					errorHandler: function (req, res, next, err) {
						res.send("Server Request error. req: " + req + ", err: " + err);
					}
				},
				livereload: {
					options: {
						middleware: function () {
							return [
								proxySnippet,
								prepareDevWebpackMiddleware(),
								serveStatic('src'),
								serveStatic('.')
							];
						}
					}
				},
				dist: {
					options: {
						base: '<%= yeoman.dist %>',
						onCreateServer: compression,
						middleware: function () {
							return [
								proxySnippet,
								serveStatic(BUILD_TARGET_DIR)
							]
						}
					}
				},
				dox: {
					options: {
						port: 9000,
						hostname: 'localhost',
						livereload: 93725,
						base: 'docs',
						middleware: function (connect) {
							return [
								proxySnippet,
								mountFolder(connect, 'assets/templates'),
								mountFolder(connect, 'docs')
							];
						}
					}
				}
			};

			var routes = proxiesConfig.routes,
				context = proxiesConfig.context;

			routes.forEach(function (obj) {
				var ctx = obj.context ? obj.context : [];

				handler[obj.arg] = {
					proxies: [{
						context: context.concat(ctx),
						host: obj.host,
						https: obj.https || true
					}]
				}
			});

			return handler

		}(),
		copy: {
			docs: {
				files: [
					{
						cwd: 'assets/templates',
						src: ['**/**.*'],
						dest: 'docs',
						filter: 'isFile',
						expand: true
					}
				]
			},
			buildPartials:{
				files:[
						{cwd: 'src/',
						src: ['ngBreadCrumbTemplate.html'],
						dest: 'dist/src/',						
						expand: true
						}
						]
			}
		},
		compress: {
			main: {
				options: {
					archive: FINAL_BUNDLE_FILENAME
				},
				files: [
					{
						cwd: 'dist',
						src: '**',
						expand: true,
						filter: 'isFile',
						dest: 'EOR.SelfService.WebUI/'
					}
				]
			}
		},
		svgstore: {
			default: {
				files: {
					'src/assets/svg-defs.svg': ['svg/*.svg']
				}
			}
		},
		karma: {
			dev: {
				configFile: 'karma.conf.js',
				autoWatch: false,
				singleRun: true
			},
			unit_auto: {
				configFile: 'karma.conf.js',
				autoWatch: true,
				singleRun: false
			},
			ci: {
				configFile: 'karma.conf.js',
				browsers: ['PhantomJS'],
				singleRun: true,
				autoWatch: false,
				colors: false
			}
		},
		protractor: {
			options: {
				keepAlive: true,
				configFile: "config/protractor.conf.js"
			},
			singlerun: {},
			auto: {
				keepAlive: true,
				options: {
					args: {
						seleniumPort: 4444
					}
				}
			},
			ci: {
				keepAlive: true,
				options: {
					args: {
						seleniumPort: 4444
					}
				}
			}
		},
		ngdocs: {
			options: {
				// styles: ['assets/dashboard.css'],
				template: ['assets/templates/index.tmpl'],
				bestMatch: true,
				title: "<%= pkg.name %>",
				startPage: '/api',
				image: "<%= yeoman.app %>/images/phoenix_logo.png",
				html5Mode: false,
				scripts: [
					'bower_components/angular/angular.js',
					'bower_components/angular-animate/angular-animate.js'
				]
			},
			api: {
				src: ['<%= yeoman.app %>/**/*.js', '<%= yeoman.app %>/**/**/*.ngdoc', 'assets/index.ngdoc', '!src/**/*_test.js'],
				title: 'API Documentation'
			}
		},
		watch: {
			options: {
				livereload: '<%= connect.options.livereload %>',
				spawn: false
			},
			server: {
				files: [
					'src/**/*.html',
					'src/**/*.css',
					'src/**/*.less',
					'src/**/*.js'
				]
			},
			less: {
				files: [
					'src/**/*.less',
					'src/styles/**/*.css',
				],
				options: {
					livereload: '<%= connect.options.livereload %>',
					spawn: false
				}
			},
			protractor: {
				files: ['src/**/*.js', 'test/e2e/**/*_e2e.js'],
				tasks: ['protractor:auto']
			},
			karma: {
				files: ['src/**/*.js', 'test/e2e/**/*_e2e.js'],
				tasks: ['karma:unit_auto']
			},
			components: {
				files: ['components/src/**/*.js', 'src/**/*.less', 'src/styles/**/*.css'],
				options: {
					livereload: '<%= connect.options.livereload %>',
					spawn: false
				}
			}
		}
	});

	// The development server (the recommended option for development)
	var targetEnv = grunt.option('targetEnv') || 'dev';
	grunt.registerTask("dev", ["webpack-dev-server:start"]);
	grunt.registerTask("default", "Usage Text for Grunt.", function () {
		grunt.log.write('Usage\n');
		grunt.log.write('\tgrunt [task]\n');
		grunt.log.write('\n');
		grunt.log.write('Options\n');
		grunt.log.write('\t' + 'serve' + '\t\t' + 'Starts dev server \n');
		grunt.log.write('\t' + 'serve:dist' + '\t' + 'Creates bundles in "dist" directory, runs local server\n');
		grunt.log.write('\t' + 'serve:dox' + '\t' + 'Creates documeation IPI and runss local server: http://localhost:9000\n');
		//grunt.log.write('\t' + 'dev' +'\t\t' 	+ 'Starts dev server \n');
		grunt.log.write('\t' + 'build' + '\t\t' + 'Prepares web-ui.zip artifact \n');
		grunt.log.write('\t' + 'test' + '\t\t' + 'Runs Karma unit tests - singlerun \n');
		grunt.log.write('\t' + 'test:e2e' + '\t' + 'Runs Protractor End-to-End (e2e) tests - singlerun \n');
		grunt.log.write('\t' + 'autotest' + '\t' + 'Runs Karma unit tests for file updates \n');
		grunt.log.write('\t' + 'autotest:e2e' + '\t' + 'Runs Protractor e2e tests for file updates  \n');
		grunt.log.write('\t' + 'test-ci' + '\t\t' + 'Task to execute Karma unit tests on Jenkins \n');
		grunt.log.write('\t' + 'test-ci:e2e' + '\t' + 'Task to execute Protractor e2e tests on Jenkins \n');
	});

	// Production build
	grunt.registerTask("build", function (target) {
		return grunt.task.run([
			"clean:all",
			"svgstore",
			"ngconstant:" + targetEnv,
			"webpack:build",
			"copy:buildPartials",
			"compress"
		]);
	}
	);
	//Karma test target for developer's dev box
	grunt.registerTask('test', ['karma:dev']);
	grunt.registerTask('test:e2e', ['protractor:singlerun']);
	grunt.registerTask('autotest', ['karma:unit_auto']);
	grunt.registerTask('autotest:e2e', ['protractor:auto', 'watch:protractor']);
	//Karma test target for Jenkins CI
	grunt.registerTask('test-ci', ['karma:ci']);
	grunt.registerTask('test-ci:e2e', ['protractor:ci']);

	grunt.registerTask('dox', ['clean:docs', 'ngdocs', 'copy:docs']);


	grunt.registerTask("dist", function (target) {
		return grunt.task.run([
			"configureProxies:" + target,
			"connect:dist:keepalive"
		]);
	});

	grunt.registerTask('serve', function (target, env) {
		grunt.log.write('targetEnv:: ' + targetEnv);
		switch (target) {
			case "dist":
				return grunt.task.run(["build", "dist:" + (typeof (env) === 'undefined' ? 'dev' : env)]);
				break;
			case "dox":
				return grunt.task.run(["ngdocs", "connect:dox:keepalive"]);
				break;
			default:
				return grunt.task.run([
					"clean:all",
					'configureProxies:' + (typeof (target) === 'undefined' ? 'dev' : target),
					"ngconstant:" + targetEnv,
					'svgstore',
					'connect:livereload',
					'watch:server',
					'watch:less',
					'watch:components'
				]);
				break;
		}
	});
};
