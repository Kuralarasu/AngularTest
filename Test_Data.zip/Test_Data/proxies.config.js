/**
 * Created by ramor11 on 6/30/2016.
 */

module.exports = {
	context: ['/phx-assets', '/phx-async', '/phx-rest', '/siteminderagent'],
	routes: [
		/**
		 * Additional Options
		 *
		 *    context:    {array=} default this.context
		 *    host:        {string}
		 *    https:        {boolean=} default yes
		 */
		{arg: 'dev', host: 'dev-phoenix.labcorp.com'},
		{arg: 'demo', host: 'demo-phoenix.labcorp.com'},
		{arg: 'eligibility', host: 'dev-eligibility-phoenix.labcorp.com'},
		{arg: 'demographics', host: 'dev-demographics-phoenix.labcorp.com'},
		{arg: 'dev1', host: 'dev1-phoenix.labcorp.com'},
		{arg: 'dev2', host: 'dev2-phoenix.labcorp.com'},
		{arg: 'dev3', context: ['/phx-analytics'], host: 'dev3-phoenix.labcorp.com'}
	]
};
