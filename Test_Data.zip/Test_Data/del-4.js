<div style="visibility: hidden">
    <div class="md-dialog-container" id="executionDescriptionDialog">
        <form name="form" ng-submit="sendOrdersOnClick()">
            <md-dialog>
         <div class="modal-body">
            <p>Please enter description for the execution</p>
            <md-input-container class="md-block">
                            <label>Description</label>
                            <textarea name="executionDescription" ng-model="executionDescription" md-maxlength="50" md-max-row="1" required></textarea>
                            <div ng-messages="form.executionDescription.$error">
                                <div ng-message="md-maxlength">Maximum length is exceeded.</div>
                                <div ng-message="required">Required entry</div>
                            </div>
            </md-input-container>
         </div>
         <div class="modal-footer">
            <md-dialog-actions>
               <div class="col-md-6">
                  <md-button ng-click="closeDialogOnClick()" class="btn btn-block btn-default pull-left">Cancel</md-button>
               </div>
               <div class="col-md-6">
                 
                  <md-button ng-click="sendOrdersOnClick()" ng-disabled="form.executionDescription.$invalid" class="btn btn-block btn-primary pull-right">Execute</md-button>
               </div>
            </md-dialog-actions>
         </div>
      </md-dialog>
      </form>
   </div>
</div>


<div style="visibility: hidden">
    <div class="md-dialog-container" id="executionDescriptionDialog">
        <form name="form" ng-submit="sendOrdersOnClick()">
            <md-dialog>
                <div class="modal-body">
                    <h4>Please enter description for the execution</h4>
                    <div layout="row">
                        <md-input-container class="md-block">
                            <label>Description</label>
                            <textarea name="executionDescription" ng-model="executionDescription" md-maxlength="50" md-max-row="1" required></textarea>
                            <div ng-messages="form.executionDescription.$error">
                                <div ng-message="md-maxlength">Maximum length is exceeded.</div>
                                <div ng-message="required">Required entry</div>
                            </div>
                        </md-input-container>
                    </div>
                </div>
                <div class="modal-footer">
                    <md-dialog-actions>
                        <div class="col-md-6">
                            <md-button ng-click="closeDialogOnClick()" class="btn btn-block btn-default pull-left">Cancel</md-button>
                        </div>
                        <div class="col-md-6">
                            <md-button ng-click="sendOrdersOnClick()" ng-disabled="form.executionDescription.$invalid" class="btn btn-block pull-right">Execute</md-button>
                        </div>
                    </md-dialog-actions>
                </div>
            </md-dialog>
        </form>
    </div>
</div>