##RELEASE 1.0.3

###[release 1.0.3-160113.14.43]

####Fix[login]: clears pw on fail, validates uid & pw exist
 + Clears password field when login fails.
 + When login clicked, validates username and password exist before submitting login request. If either missing, display error message.

###[release 1.0.3-160108.11.46]

####Fix[8-1-1.1]: adjust label style for DX validation.

###[release 1.0.3-160108.09.33]

####Fix[8-1-1]: increase legibility of INPUT fields. Change "changed fields" highlight color on 270/271.

###[release 1.0.3-160104.15.31]

####Fix[Immediate+ #1]: Prevent multiple login attempts while a login is in progress

####Fix[Immediate+ #2]: 271 Response field widths adjusted to minimize ellipses

####Fix[Immediate+ #3]: Tooltips added to Rules Editor

###[release 1.0.3-151230.09.12]

####Fix[Immediate#7]: Enable keyboard scroll on screens

####Fix[Immediate#11]: Enable zooming - keyboard controlled

##RELEASE 1.0.2

###[release 1.0.2-151216.10.18]

####Fix[hide_dx_flag]: disable change made with 27142.

###[release 1.0.2-151211.15.42]

####Fix[27142.1]: Only show red X or check mark when validating; not searching

###[release 1.0.2-151211.12.02]

####Fix[27081]:  DX DX Validation: show restriction box in results table for Non-HLS codes in search requests.

####Fix[27142]:  issue where UI does not adequately indicate that a valid principal diagnosis code exists

###[release 1.0.2-151209.12.29]

####Fix[27081]:  DX Validation: hide pass/fail icons in results table for search requests.

##RELEASE 1.0.0

###[release 1.0.0-151204.14.14]

####Fix[26276]: Patient Create/Edit: Email field errors.

####Fix[26745]: UI - Inactive Countdown doesn't log user out

####State issues and console errors fixed

####Fix[26985]: Show growl messages for invalid dates on Patient Search, Create/Edit Patient

####Fix[27081]: DX Validation: hide pass/fail icons in results table for search requests.

####Fix[26985]: Show growl messages for invalid dates on Patient Search, Create/Edit Patient

###[release 1.0.0-151202.11.32]

####Fix[26491]:  Discrepancies in UI response because of CACHE issues

####Fix[27079]:  EV 271: Populate Group ID from subscriber (or dependent section if not present in subscriber).

####Fix[26745]:  UI - Inactive Countdown doesn't log user out

####Fix[27032]:  Create Patient/Edit Patient - prevent duplicate growl message after update. Allow second Address to be empty when updating.

###[release 1.0.0-151124.11.05]

####Fix[27030]:  EV response - Benefit Info table header does not match table size

####Fix[27046]:  Unable to login into RCMBU -> HotFix_loginIssue_24thNOv

####Fix[26949]:  EV Response - benefit filter drop down not displaying up when necessary

###[release 1.0.0-151124.09.42]

####Fix[27038]:  Date picker: menu header missing in IE (error thrown).

####Fix[26991]:  Patient Search - MRN & Account number does not allow search

####Fix[27032]:  Create Patient/Edit Patient - correct validation for Other Insurance address.

####Fix[27025]:  fixes create when accession not available

####Fix[27004]:  corrects mapping of address line 2

####Fix[26911]:  Selectbox: when the dropdown menu is open, clicking on the scrollbar should not close the dropdown (including in IE).

###[release 1.0.0-151123.13.00]

####Fix[26663]: Payer Policy: populate Bis Group Name when a Bis Group is selected.

####Fix[26736]: Date picker: Check for date validity (e.g., "02/31/2015" is not valid) each time the INPUT value changes (instead of just when it loses focus).

####Fix[26765]: Back button in physician search

####Fix[26911]: Selectbox: when the dropdown menu is open, clicking on the scrollbar should not close the dropdown (including in IE).

####Fix[26975]: 4 digit SS# Not running in EV UI

####Fix[26985]: Datepicker: entering a year of "0000" should not be changed to "1900" and should be marked invalid.

####Fix[27004]: corrects mapping of address line 2

####Fix[27017]:  Authorization for Hamburger menu

####Fix[27025]: fixes create when accession not available

####Fix[27032]: Create Patient/Edit Patient - correct validation for Other Insurance address.

###[release 1.0.0-151123.10.44]

####Fix[26736]:EV 270: if Birth Date or Service is invalid, show a growl message when the submission is prevented.

####Fix[26765]:Back button in physician search

####Fix[26985]:Datepicker: entering a year of "0000" should not be changed to "1900" and should be marked invalid.

###[release 1.0.0-151120.14.52]

####Fix[26724]: Patient Search: Edits on phone number not present

####Fix[26736]: Date picker: Check for date validity (e.g., "02/31/2015" is not valid) each time the INPUT value changes (instead of just when it loses focus).

####Fix[26747]: Create/Edit Patient - Address Type is required

####Fix[26861]: Phone extension is not on the Create/maintain or get patient UI

####Fix[#26949]: EV Response - benefit filter drop down not displaying up when necessary

####Fix[#26957]: When tabbing to a checkbox or radio input field apply a gold bottom-border to its label text to indicate it is focused.

####Fix [26974]:  Login page takes two attempts to login

####Fix [26978]: clears status messages when bulk upload clicked

####Fix [27001]: DEV- Cannot create a patient

###[release 1.0.0-151118.12.36]

####Fix[26989]: remove unauthorized left nav items

####Fix[26915]: Fixed by another defect fix, although we cannot confirm which one.

####Fix[26914]: Fixed by ctrl-R (refresh)

####Fix[26825]: Build fix, no code change.

####Fix[#26951]: New table design for Rules listing

####Fix[#26899]: Sort Physican search results

####Fix [ 26897 ]: Patient Create screen - collection date should be required

####Fix [26575]: DX Validation: "Clear" button should clear date values.

####Fix [26598, 26724]: updates phone clearing and validation

####Fix[#26778]: Hide X from date picker in IE

####Fix[#26952]: Message when more than 25 records matched

####Fix [26901]: Selectbox: selecting an item should send focus to the associated input field to enable easier tabbing to the next form field.

###[release 1.0.0-151116.14.04]

####Fix [26765]: Need back button to go back to results

####Fix [26885]: New table design for Message history

####Fix [26891]: Already logged out and getting countdown

####Fix [26724]: Patient Search should not proceed if Phone is not 10 digits in length.

####Fix [26857]: DX UI - date picker not being removed when other UI's selected

####Fix [26826]: Permanent expand EV response eb info

####Fix [26876]: Grey-out the inaccessible links at left nav

###[release 1.0.0-151113.14.28]

####FIX [26729] : Print of EV response - not printing the full response

####Fix[#26862]:Remove state and payer fields from EV form

####Fix [26800, 26644]: Shows server error messages on 271 response

####Fix [26578]: Datepicker: entering a non-existent leap year date should make the field invalid (not just appear that way).

####Fix[#26771]: Age calculation error

####Fix[#26827] : Warning message in RulesEditor/condition editor

####FIX [26857] : DX  UI - date picker not being removed when other UI's selected

####FIX [26871] : Create the ability to have print styles for each page

####Fix[#26858]: Gender field required in EV

####Fix [ 26758 ]: Scenario 23 & 24 - Clear Button

####Fix [ 26276 ]: Patient Create/Edit: Email field errors

####FIX [26823] : Phone validation - in the app the clear button is not clearing the phone number

####Fix[#26785]: To Highlight changed fields in EV response

####Fix [26762, 26746]: Selectbox: tabbing into a selectbox-enabled input field should allow you to click on a list item with the mouse.

####Fix [26816]: adds address line2

###[release 1.0.0-151111.14.35]

####Fix [26745]:
UI - Inactive Countdown doesn't log user out
 + Changes in authService.doLogout(), apply this function on session timeout, it used to used the login route, that is no longer in used.

####Fix [26768]:
Remove double error message
 + removing double error message and showing growl message when no records found +unit tests

####Fix [26336]:
Verification-Response: Unit test need to be fixed

###[release 1.0.0-151111.11.55]

####Fix [26747]:
Create/Edit Patient: Address Type is a required field if an Address is provided.

####Fix [26760]:
Physician Search - display issue of PECOS name in search table

####Fix [26680]:
EV: ensure access to raw data 271 is available when request is rejected.

####Fix [26720]:
Patient Search: Entry of Name, DOB, street, city and state should perform a search.

###[release 1.0.0-151110.11.36]

####Fix [26685]:
Payer Policy table - use checkboxes for row selection
 + update design based on design spec from Enno's

####Fix [26227]:
SSN not being masked in the UI after results are displayed
 + Merged with release branch
 + Completed the unit test for this change.

####Fix [26737]:
Test Case #1271 Print Functionality
 + Add contextMenu for print capabilities

####Fix [26735]:
Filters dropdown not closing after clicking outside
 + Now the filter options drop-down will go away after clicking outside. No tests as it is more of DOM manipulation.

####Fix [26683]:
DX Validation Table - adjust column widths
 + Expand table widths

####Fix [26729]:
Print of EV response - not printing the full response
 + Fix Portrait and Landscape print for 271
 + If collapse it will not show, only on expand of Benefits for 271
 + Grunt file bug that it was not creating the version file

####Fix [26692]:
Create/Edit Patient: Phone requires a second Additional Information group.

###[release 1.0.0-151109.13.55]

####Fix [26712]:
Specimen Collect date definition correction. Append timestamp.
 + Modified the patient demographics form controller to to add timestamp to the specimen collection date.

####Fix [26624]:
Gender field in EV should be mandatory
 + restored the code that was lost by overridden code

####Fix [26713]:
Change "Medical Record Number" label to "MRN" (but spell out in required message) in Patient Search and Create/Edit Patient.

####Fix [26578, 26609]:
Date picker: invalid dates (including invalid leap year dates) should be styled as invalid and not disappear.

####Fix [26721]:
Modifies table and column to make more readable

####Fix [26708]:
improves msg when DOB > DOS
 + Modified date validation to improve contextual message.

###[release 1.0.0-151106.13.39]

####Fix [26595]:
clears errors on re-submit on DX Validation

####Fix [26700, 26705]:
Fixes table presentation, missing style sheet.
 + update design based on design spec from Enno's
 + update design based on design spec from Enno's
 + missing file, possible bad merge

####Fix [26709]:
Phone validation - phone number entered is being changed
 + Changed phone-validation-controller to reverse the prefix and line number.

###[release 1.0.0-151105.17.05]

####Fix [26437, 26587, 26598]:
Patient Search UI validation; Create/Edit Patient UI validation and new design
 + Fix [26437]: Patient Edit/Create new design with required field validation.
 + Fix [26587, 26598]: Patient Search with required field validation.

####Fix [Gregg's Request]:
Updated a message per Gregg's request

####Fix [26621 - redux]:
adds case insensitive compare

####R-1-115-3:
Modify Create and Edit Patient to display new fields from OSB
 + This commit adds new fields to the Create Patient Field and the Get Patient screen.

###[release 1.0.0-151105.11.59]

####Fix [26673]:
Remove 'ERROR' text from msg window
 + removing "ERROR" text from message window

####Fix [26684]:
DX Validation Table - provide indicator for hidden row
 + Added read more options, if the text is different

####Fix [26624]:
Make gender field mandatory
 + This is to make gender filed mandatory in EV form and ensure the EV call is not made without being gender selected. Required field styles are also modified to fit into radio button

####Fix [26331]:
In phone type drop-down (IE), 'X' appears in input field
 + Added the following line to billing.less file to remove the 'X' for Internet Explorer: input[type=text]::-ms-clear { display: none; width : 0; height: 0; }

####Fix [26661]:
widens gender col on PayerPolicy table

####Heuristic Task [71]:
Componize Tables, and Customer Provider Entity table fix
 + This is Depended on the CHECKBOX_FIX, I merge from that branch, since it had everything needed to have this page in good working order, and bug fixes.
   + Fix the reference of the file, required location and placed them in both webpack.config and karma.config. The results will keep the component file small. Like the phxapp.js was huge because it was loading all of the components levels
   + adding new lcpTable component

####Fix [26666]:
requires age unit if age begin provided

####Fix [26518]:
Clear State field on clearing the form
 + to reset State dropdown on form clear + unit test

###[release 1.0.0-151104.14.38]

####Fix [26410, 26273]:
Create Patient w/ invalid SSN - Multiple Errors Received; SSN Field Errors
 + Made sure that the server is not called when the SSN is not 4 or 9 digits in length.
 + Combined branches bugfix_26410 and bugfix_26273

####Fix [26525]:
States dropdown
 + Replace state input field with lcp-select dropdown + unit test cases for the change

####Fix [26621]:
add Armed Services states and validate with cities
 + fix(states): adds armed states and state service
 + fix(states): adds armed state support to create client
 + fix(states): adds armedStates support to Physician Search

####Fix [26542]:
Show warning after clicking on apply
 + to show warning message when 'outcome' is modified from rules editor

####Fix [26618]:
fixes pagination when Back button used

###[release 1.0.0-151103.11.04]

####Fix [26586]:
Phone validation issues fixed
 + This one is to fix phone formatting issues in Phone-validation page. It also has unit tests.

####Fix [26352]:
Patient Search Issues
 + Now patient search works with the browser's back button but page refresh will show a fresh search form.

####Fix [Checkbox]:
Checkbox fix
 + Fix the reference of the file, required location and placed them in both webpack.config and karma.config. The results will keep the component file small. Like the phxapp.js was huge because it was loading all of the components levels, The unit testing where failing because it could not find reference of the modules becuase they where all being added to the app.js file. In addition this was making the app.js file huge, since it also loading libraries. I have move all this code into their correct locations.
 + Libraries will need to located within webpack.config so it will be packaged within the vendor.js file.
 + In addition we also need the karma.config to be updated with the new library that needs to be loaded, for example, jsTag.
 + jsTag was being loaded twice, within app.js and vendor.js, THIS IS A NO NO.
 + Componenize CHECKBOX, and fix a bug, that was causing double event click on the checkbox. There will be a test unit in a separate branch there is already too much here.

###[release 1.0.0-151030.16.34]

####Fix [26519, 26575,26594, 26595]:
Remove notifications on submit/clear
 + This is to remove notifications on submit and clear buttons in every controller.

###[release 1.0.0-151030.11.37]

####Fix [26567]:
Fixes Payer Policy date when entering Edit
 + fix(payerPolicy): corrects date conversion for timezone
 + fix(payerPolicy): adds unit test to validate date

####Fix [26538]:
Empty Phone Numbers
 + to fix showing unwanted "(" for empty phone numbers

####Fix [26557]:
EV response - unable to select an option to filter within the Benefits Info table.

###[release 1.0.0-151029.12.26]

####Fix [26237]:
Show MRN/Acct columns in Patient Search results when included in search criteria (including First & Last Name and DOB).

####Fix [26512]:
Datepicker should not allow a 5 digit year.

####Fix [26472]:
####Note: 26472 has been reopened for a related, but different issue, but the duplicate message has been fixed.
Create Patient w/ Name, DOB, Street + Zip. Receive "successful" error message.
 + Removed the call to lcdMessage.error() call in the failure logic. (Duplicate message)

####Fix [26344]:
Remove success message from Dx-validation screen
 + Removing the search success message as its causing inconvenience to the user

####Fix [26481]:
Application does not actually time user out
 + change the ping url for hitting the serve

###[release 1.0.0-151028.12.04]

####Fix [26528]:
reverts #26512

####Fix [26373]:
Entry of no data on Address Validation UI does not provide helpful message

####Fix [26337]:
fix(userService): fixes unit tests

####Fix [26513]:
EV - field title overlapping data
 + update the styles and lcp-date, which was missing class element when input field was not empty
 + fix selectBox which was flickering on the page.
 + WIP know bug in Datepicker

####Fix [26467]:
Prevent editing of EV response data (support for "readonly" attribute on lcp-input-text-directive).

###[release 1.0.0-151027.17.35]

####Fix [26512]:
Limit maxlength of date inputs to 10 characters ("mm/dd/yyyy").

####Fix [26338]:
fixes auth service unit tests

####Fix [26339]:
(authinterceptor): fixes unit tests

###[release 1.0.0-151027.11.42]

####Fix [26237]:
Patient Search - MRN & Account should only be displayed in the return data when MRN/Acct is entered as Search Criteria.

####Fix [26363]:
to prevent user from typing in the letters into the phone field

####Fix [26423]:
Add controls disappear after clearing the form
 + This is to Fix the add controls in the form that used to disappear after clicking on clear button of the form

####Fix [26275]:
Patient Create/Edit Phone Field Errors.
 + Fixed the vertical spacing of the phone number field and the phone type selectbox.
   Mallik has already fixed the issue of invalid values in phone field in pull request #505; branch bugfix_#26363

####Fix [26461]:
to show a warning message when clicked on cancel from save confirmation dialogue

####Fix [26228, 26421]:
Clear button should clear SSN on Patient Search, Create Patient screens.

####Fix [26427]:
Do not submit EV 270 request if required fields are missing or if the Service Date is not greater than or equal to the Birth Date.

###[release 1.0.0-151026.11.59]

####Fix [#####]:
Added maxLength per Anand, LabCorp Payer Code
 + Anand send an email for request to add maxlenght if use send more than 5 char, it will throw a server error.

####Heuristic Task [26]:
address carets in Benefits Information table on 271.

####Heuristic Task [31]:
EV - 270 remove field-level errors when condition cleared.
 + Added field level errors in eligibility-verification.html.
 + Added logic in eligibility-verification-controller.js to not call the back-end web service, if required fields not entered.

###[release 1.0.0-151023.12.32]

####Fix [26431]:
ev270 - adjusts grid to support lower res screens

####Fix [26351]:
When performing a search on a Patient and the patient first name, last name, DOB and only an account number OR an MRN is entered, the UI will display a message of undefined status
 + Removed the direct error message from the controller since the error is already being presented by the auth interceptor.

####Heuristic Task [6]:
Message History Page
 + Modified the table columns width as per the mockup
 + And fixed the unit test cases in Provider entity

###[release 1.0.0-151022.14.02]

####Fix [26380, 26385, 26440]:
correct validation functionality on DX Validation screen.
 + Fix [26380]: DX Validations not bringing back age/gender conflicts - Gender, DOB, DOS were being dropped from the request
 + Fix [26385]: Diagnosis Code entry functionality on Diagnosis Validation is not working as designed.
 + Fix [26440]: Diagnosis Validation UI Issues (tabbing, DX Codes label positioning)

####Heuristic Task [37]:
cust/providerentity drop down off position
 + Corrected the design of drop down to follow design from other pages
 + Break the page html with uiView routing for easy development and enhancements

####Heuristic Task [26]:
Caret should flip when dropdown is open
 + Heuristic task [26]: apply transition to "open" state of dropdown caret.
 + Heuristic task [26]: adjust styling of Provider Entity Search dropdown menu and caret.

####Fix [26412]:
Submit cut off or very close to edge
 + Update the pages footer and fix layout to properly show the scroll bar if needed, and fix the padding of the footer,

####Fix [26396]:
Phone validation - entering data in phone number
 + This method updates HTMLInputElement.selectionStart, selectionEnd, and selectionDirection in one call.

###[release 1.0.0-151021.12.05]

####Fix [26386]:
Partial Display of Last Row in EV 271 response
 + remove style that is mean to be use with scroll-y directive

####Fix [26424]:
EV datepicker issue in IE
 + Fix close event on IE due to scope.digest

####Heuristic Task [11]:
Fix tabbing on SelectBox dropdowns (by adding event handlers for Up/Down arrow keys and Esc).
 + Heuristic task [11]: Fix tabbing on SelectBox dropdowns (by adding event handlers for Up/Down arrow keys and Esc).
   Previously, when a SelectBox-enabled input received focus, the dropdown would appear. This change implements the following behavior:
   If no item is selected:
 + Pressing the Down arrow key will select the first item
 + Pressing the Up arrow key will close the dropdown
 + Pressing the Esc key will close the dropdown
   If an item is selected:
 + Pressing the Down or Up arrow key will select the next/previous item (but not change the value of the input until the Enter key is pressed (as currently implemented) and that item should be visible in the dropdown (that will scroll if necessary)
 + Pressing the Esc key will close the dropdown

####Fix [26393]:
Phone validation - Allow enter to function without tabbing out of phone number
 + Fix the page layout where it was not properly displaying the footer.
 + Fix the ngMaxlenght was suppressing the keyCode 13
 + Added test unit for ngMaxlengh
 + Move ngMaxlengh to the component folder

####Fix [26312]:
EV 271 is not displayed when response does not contain "payerSummaries" array.
 + Fix issue 26312 to enable the 271 to be displayed when the response does not include the payerSummaries array, e.g., for Undefined responses.

####Fix [26375]:
Address Validation needs state drop down of valid states
 + Added the new State Dropdown

####Fix [26425]:x
Inconsistent dropdown bugs
 + Fixes display problem with single column dropdowns.

####Fix [26200]:
Phoenix is currently not providing the Address container properly to the consuming systems
 + Merge branch 'release' into bugfix_addresstype.
 + Moved the Address type field inside the address object.

####Fix [26340]:
Date picker won't accept pasted value.
 + Date picker fix to accept paste data with bad format 1/2/1983

####Fix [26329]:
Fix vertical divider in tables

####Fix [26328]:
Fix title of phone validation error message

###[release 1.0.0-151020.13.42]

####Heuristic Task [18]:
Re-arrange EV 270 layout in logical groups
 + Make changes to the EV-270 layout based on the Heuristic reviews.
 + Changed the name of the pull request.

####Heuristic Task [33]:

 + update to class elements for angular 1.1.5
 +  added enhancement to display the arrow to be below the dropdown when screen is too small.
 +  Improve performance on animate.enter

####Heuristic Task [60]:
Reset Button in condition editor is not consistent
 + This is to fix the styling of Reset button in Condition editor for IE

####Fix [26306]:
Selecting the Clear button from the Create Patient Demographics screen takes the user to the Patient Search screen and not the Create Patient.
 + I made the necessary code changes so that only the fields are cleared on the Create Patient screen; no longer re-directs to Patient Search.

####Fix [26334,26335,26343]:
Physician search table issues
 + All the styling and layout issues fixed in Physician details table

###[release 1.0.0-151019.11.49]

####Heuristic Task [73]:
WB[R-9-48-1, R-9-98-1, R-9-73-1]
 + Quick Dirty FIX for the scroll bars, inside the application. Due to the structure this is a quick fix but some pages may react differently since they are not structure equally.
   + R-9-48-1 review Fix scroll bar, goes behind footer
   + R-9-98-1 review scroll bar too thin
   + R-9-73-1 review new field disappears below footer

####Fix [26292]:
eliminate horizontal scrolling on 271 EB table
 + Change the min-width 100px

####Fix [26348]:
Messaging in physician search is different
 + Currently Physician search is showing error messages differently. Now I have modified the code to follow the new error messaging style and design. There is no defect posted for this in Bugzilla.

####Fix [26326]:
Patient Search: currently can enter invalid value and label appears in value when tabbing out. To be consistent, state should be a dropdown.
 + Patient Demographics: Change state field to a drop-down.
   1. state field is now a drop-down.
   2. Added unit test for the Patient Demographics screen.

###[release 1.0.0-151016.16.07]

####Heuristic Task [44]:
Remove unwanted real estate
 + This is to get rid of unwanted real estate in Account details page.

####Maintenance Task [grunt]:
separates test from build to fix bamboo conflict

###[release 1.0.0-151015.13.17]

####Heuristic task [6]:
Error messages
 + This is to make the error messaging in the app consistent. Most of the task has been done last week . In this PR, I have just modified some styles as per design guidelines.

####Fix [26272]:
Patient Demographics: User can enter invalid state values.
 + Changed state field to a dropdown.

####chore(pom):
update version properties
 + Changes pom.xml version properties to support Bamboo builds.

###[release 1.0.0-151014.16.36]

####Heuristic task [47]:
Fix 271 printing following table restructuregit
 + This change adds a second table for the Benefits Information to be displayed only when printing.

####Heuristic task [20]:
Remove unused sidebar items
 + This is to remove all the not-implemented side nav items from Billing and Customer

####Heuristic task [27]:
new styling for adding function on Create Patient
 + now the 'Add' button in Create Patient looks like 'add rule' in rules editor

###[release 1.0.0-151014.11.57]

####Fix[#26198]:
To restore showing error messages in auth interceptor
 + This is to show error messages in EV form. modified the code to parse the EV response object properly. However, some of the EV error messages are not user friendly. So I have raised a new ticket for the service team to fix them.

####Fix[undocumented]:
Sign-in Controller
 + I notice that the cancel button, dismissing the modal does not have real affect that displaying the site again. The change it will route the user to the login page.

####Fix[#26223]:
Physician Search UI - Allows additional info without clearing
 + Resets the collection object every time user hits the search button 2) Shows the result table only when the result.length > 0
