module.exports = (function() {
  "use strict";

  //Custom styles import
  require("./styles.less");

  var envConfig = require("../../config/env-config")();

  var phxModule = angular.module("e2eTesting.module", ['ui.grid','ui.grid.selection','ui.grid.grouping','ui.grid.resizeColumns','ui.grid.autoResize',
  require('../_common/eor.Common.js').name, envConfig.name]);
                                                                
  //Controllers import
  require("./controllers/testScenarioListController")(phxModule);
  require("./controllers/testScenarioEditListController")(phxModule);
  require("./controllers/testScenarioDefineListController")(phxModule);
  require("./controllers/testScenarioExecuteListController")(phxModule);
  require("./controllers/testScenarioCompleteListController")(phxModule);
  require("./controllers/testScenarioEditController")(phxModule);

  //Constants import
	require('./constants/e2eTestingConstants')(phxModule);
  
  //Services
  require('./services/testDataUrlService')(phxModule);
  require('./services/testDataService')(phxModule);
  require('./services/e2eCommonService')(phxModule);
  
	//Directives
	  
  return phxModule;
})();
