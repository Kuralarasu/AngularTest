module.exports = function () {
    
        var routes = [
            {
                name: 'e2eTestingLayout',
                parent: 'dashboard',
                abstract: true,
                views: {
                    'appBody@': {
                        templateUrl: '/phx/sidebar.tpl.html',
                        controller: ['helpRouteService', function (helpRoute) {
                            helpRoute.init();
                        }]
                    },
                    'leftNavListView@e2eTestingLayout': {
                        template: require('html!./views/sidebar.html'),
                        controller: 'phxCommonAsideNavigationController',
                        controllerAs: 'ctrl'
                    },
                    'breadcrumb@e2eTestingLayout': {
                        template: require('html!./views/breadcrumb.html')
                    }
                },
                resolve: {
                    jsBundle: ['jsBundleResolver', function (jsBundleResolver) {
                        return jsBundleResolver(function (app, resolve) {
                            require.ensure([], function () {
                                app.register(require('./app.js'));
                                resolve();
                            });
                        });
                    }]
                }
            },
            {
                name: 'e2eTesting',
                parent: 'e2eTestingLayout',
                url: 'e2eTesting/',
                views: {
                    'pageContainer': {
                         template: require('html!./views/index.html'),
                         controller: "testScenarioListController",
                         controllerAs: "ctrl"
                    }
                }
            },
            {
                name: 'e2eTestingEdit',
                parent: 'e2eTestingLayout',
                url: 'e2eTestingEdit/:testScenarioId',
                views: {
                    'pageContainer': {
                        template: require('html!./views/testScenarioEdit.html'),
                        controller: "testScenarioEditController",
                        controllerAs: "ctrl"
                        
                    }
                }
            },            
            {
                name: 'e2eTestingEditList',
                parent: 'e2eTestingLayout',
                url: 'e2eTestingEditList/:statusId',
                views: {
                    'pageContainer': {
                        template: require('html!./views/testScenarioEditList.html'),
                        controller: "testScenarioEditListController",
                        controllerAs: "ctrl"
                    }
                }
            },
            {
                name: 'e2eTestingDefineList',
                parent: 'e2eTestingLayout',
                url: 'e2eTestingDefineList/:statusId',
                views: {
                    'pageContainer': {
                        template: require('html!./views/testScenarioDefineList.html'),
                        controller: "testScenarioDefineListController",
                        controllerAs: "ctrl"
                    }
                }
            },
            {
                name: 'e2eTestingExecuteList',
                parent: 'e2eTestingLayout',
                url: 'e2eTestingExecuteList/:statusId',
                views: {
                    'pageContainer': {
                        template: require('html!./views/testScenarioExecuteList.html'),
                        controller: "testScenarioExecuteListController",
                        controllerAs: "ctrl"
                    }
                }
            },
            {
                name: 'e2eTestingCompleteList',
                parent: 'e2eTestingLayout',
                url: 'e2eTestingCompleteList/:statusId',
                views: {
                    'pageContainer': {
                        template: require('html!./views/testScenarioCompleteList.html'),
                        controller: "testScenarioCompleteListController",
                        controllerAs: "ctrl"
                    }
                }
            },
            {
                name: 'e2eTestingResultView',
                parent: 'e2eTestingLayout',
                url: 'e2eTestingResultView/',
                views: {
                    'pageContainer': {
                         template: require('html!./views/testScenarioResultViewer.html')
                    }
                }
            }
        ];
    
        /**
         * Bit of code to define the module for all routes, this will be added to the body.className to add another level
         * of specificity to the classes
         */
        return function (r) {
            r.map(function (o) {
                o.data = {
                    module: 'e2eTesting.Module'
                }
            });
            return r;
        }(routes);
    }();
    