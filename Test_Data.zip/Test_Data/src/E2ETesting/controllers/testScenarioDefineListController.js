module.exports = function(app) {
    "use strict";
  
    app.controller("testScenarioDefineListController", function(
      $scope,
      $http,
      $stateParams,
      $location,
      $window,
      $mdDialog,
      E2E_CONSTANTS,
      testDataService,
      e2eCommonService
    ) {
        $scope.testScenarioGrid = {
          enableRowSelection: true,
          enableSelectAll: true,
          selectionRowHeaderWidth: 35,
          rowHeight: 35,
          showGridFooter: true, enableFiltering: true,
          enableGridMenu: true,
          enableGroupHeaderSelection: false,
          multiSelect: true
        };
        
        $scope.testScenarioGrid.columnDefs = [
          { field: 'Id', displayName: 'Id', minWidth: 25 },
          { field: 'AccessionNumber', displayName: 'Accession', minWidth: 50 },
          { field: 'Subprotocol', displayName: 'Project', minWidth: 50 },
          { field: 'FromSystem', displayName: 'From', minWidth: 50 },
          { field: 'ToSystem', displayName: 'To', minWidth: 50 },
          { field: 'MessageDt', displayName: 'Message Id', minWidth: 50 },
          { field: 'MessageSequence', displayName: 'Message Seq', minWidth: 50 },
          { field: 'CreatedDateTime', displayName: 'Created', minWidth: 50 }
        ];
  
        $scope.testScenarioGrid.onRegisterApi = function (gridApi) {
          $scope.gridApi = gridApi;
          gridApi.grouping.clearGrouping();
          gridApi.selection.on.rowSelectionChanged($scope, function (row) {
            console.log(row.entity.Id);
          });
          gridApi.selection.on.rowSelectionChangedBatch($scope, function (row) {
            $scope.countRows = $scope.gridApi.selection.getSelectedRows().length;
            console.log($scope.countRows);
          });
        };
  
        $scope.selectedStatusId = parseInt($stateParams.statusId);
        $scope.selectedLaboratory = "";
        $scope.selectedScenario = "";
        
        initializeData();

        function initializeData(){
          testDataService.getScenarioStatusType($scope.selectedStatusId)
          .then(function (response) {
            $scope.selectedStatus = response.data;
            console.log("Selected Status");
            console.log(response.data);
          }, function (error) {
            console.log(error);
          });

          testDataService.getLaboratories()
          .then(function (response) {
            $scope.laboratoryData = response.data;
            console.log("Laboratories");
            console.log(response.data);
          }, function (error) {
            console.log(error);
          });
        };

        $scope.getLabTestScenariosOnChange = function (laboratoryId) {
          $scope.selectedScenario = "";
          $scope.testScenarioGrid.data = [];
          testDataService.getLaboratoryTestScenarios($scope.selectedLaboratory)
          .then(function (response) {
            $scope.scenarioData = response.data;
            console.log("Test Scenarios");
            console.log(response.data);
          }, function (error) {
            console.log(error);
          });
        };

        $scope.getScenariosTXesOnChange = function (scenarioId) {
          getScenariosTXes(scenarioId);
        };

        function getScenariosTXes(scenarioId){
          testDataService.getTXesNotExecutedByTestScenario(scenarioId)
          .then(function (response) {
            $scope.testScenarioGrid.data = response.data;
            $scope.testScenarioGrid.core.handleWindowResize();
            console.log("TX");
            console.log(response.data);
          }, function (error) {
            console.log(error);
          });
        };

        $scope.showExecuteDialogOnClick = function(ev){
          if ($scope.selectedLaboratory != "") {
            if (e2eCommonService.verifyGridRecordSelected($scope.gridApi.selection.getSelectedRows())){
              $scope.executionDescription = "";
              $mdDialog.show({
                contentElement: '#executionDescriptionDialog',
                parent: angular.element(document.body),
                targetEvent: ev,
                clickOutsideToClose: false
              });
            };
          } else {
           //alert("Please select a Laboratory from dropdown.");
           promptSelectDialogue(ev);       
          };
        };
        
        function promptSelectDialogue (ev) {
        $scope.scenarioDescription = "";
        $mdDialog.show({
          contentElement: '#SelectDescriptionDialogue',
          parent: angular.element(document.body),
          targetEvent: ev,
          clickOutsideToClose: false
        });
      }; 

        $scope.sendOrdersOnClick = function(){
          var data = {
            "TestScenarioId": $scope.selectedScenario,
            "Description": $scope.executionDescription,
            "ExecutionResultTypeId": E2E_CONSTANTS.testExecutionResultTypeId
          };
    
          testDataService.addTestExecution(data)
          .then(function (response) {
            console.log('Test Execution Id');
            console.log(response.data.Id);
            sendOrders(response.data.Id);
          }, function (message) {
              var outputMessage = message ? message : "error connecting to service.";
              alert(outputMessage);
              console.log(outputMessage);
              return;
          });
        };
  
        function sendOrders(testExecutionId){
          $scope.closeDialogOnClick();
          var selectedOrders = $scope.gridApi.selection.getSelectedRows();
          selectedOrders.forEach(function (item){
            testDataService.txExecuteOrder(item.Id, testExecutionId)
              .then(function () {
                console.log("TX: " + item.Id + " ordered");
                getScenariosTXes($scope.selectedScenario);
              }, function (message) {
                var outputMessage = message ? message : "error connecting to service.";
                getScenariosTXes($scope.selectedScenario);
                alert(outputMessage);
                console.log(outputMessage);
              });
          });
//TODO: get refresh after everything is done
          
        };
  
        $scope.closeDialogOnClick = function() {
          $mdDialog.hide();
        };

    });
  };
  