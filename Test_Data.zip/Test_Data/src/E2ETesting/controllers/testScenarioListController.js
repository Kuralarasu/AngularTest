module.exports = function(app) {
  "use strict";

  app.controller("testScenarioListController", function(
    $scope,
    $http,
    $stateParams,
    $mdDialog,
    $location,
    $window,
    $state,
    E2E_CONSTANTS,
    testDataService,
    e2eCommonService
  ) {
      $scope.selectedLaboratory = "";

      $scope.testScenarioGrid = {
        enableRowSelection: true,
        enableSelectAll: false,
        selectionRowHeaderWidth: 35,
        rowHeight: 35,
        showGridFooter: true, enableFiltering: true,
        enableGridMenu: true,
        enableGroupHeaderSelection: false,
        multiSelect: false
      };
      
      $scope.testScenarioGrid.columnDefs = [

        { field: 'Id', 
            enableHiding: false,
            displayName: 'Scenario Id',
            cellTemplate: '<div class="ui-grid-cell-contents tooltip-uigrid" title="{{row.entity.Id}}" ><a ui-sref="e2eTestingEdit({testScenarioId: row.entity.Id})" Style="color: rgb(31, 116, 140);"><b>{{COL_FIELD}}</b></a></div>',
            minWidth: 50 },
        { field: 'Description', displayName: 'Description', minWidth: 50 },
        { field: 'ScenarioStatusType.Description',  displayName: 'Status', minWidth: 50 },
        { field: 'UserCreated',  displayName: 'Created By', minWidth: 50 }
      ];

      $scope.testScenarioGrid.onRegisterApi = function (gridApi) {
        $scope.gridApi = gridApi;
        gridApi.grouping.clearGrouping();
        gridApi.selection.on.rowSelectionChanged($scope, function (row) {
          console.log(row.entity.Id);
        });
        gridApi.selection.on.rowSelectionChangedBatch($scope, function (row) {
          $scope.countRows = $scope.gridApi.selection.getSelectedRows().length;
          console.log($scope.countRows);
        });
      };
  
      //Main entry point
      getLaboratories();

      function getLaboratories() {
        testDataService.getLaboratories()
          .then(function (response) {
            $scope.laboratoryData = response.data;
            console.log("Laboratories");
            console.log(response.data);
          }, function (error) {
            console.log(error);
          });
      };

      $scope.getLabTestScenariosOnChange = function (laboratoryId) {
        getTestScenarios();
      };

      function getTestScenarios() {
        testDataService.getLaboratoryTestScenarios($scope.selectedLaboratory)
          .then(function (response) {
            $scope.testScenarioGrid.data = response.data;
            $scope.gridApi.core.handleWindowResize();
            console.log("Test Scenarios");
            console.log(response.data);
          }, function (error) {
            console.log(error);
          });
      };
     
      //Add Scenario Methods
      $scope.promptScenarioDescriptionOnClick = function (ev) {
        if ($scope.selectedLaboratory != "") {
          promptScenarioDescriptionDialog(ev);
        } else {
          //alert("Please select a Laboratory from dropdown.");
          promptSelectDialogue(ev);
        };
      };
      
      function promptScenarioDescriptionDialog (ev) {
        $scope.scenarioDescription = "";
        $mdDialog.show({
          contentElement: '#scenarioDescriptionDialog',
          parent: angular.element(document.body),
          targetEvent: ev,
          clickOutsideToClose: false
        });
      };
       function prompttestSelectDialogue (ev) {
        $scope.scenarioDescription = "";
        $mdDialog.show({
          contentElement: '#testSelectDialogue',
          parent: angular.element(document.body),
          targetEvent: ev,
          clickOutsideToClose: false
        });
      };
       
      $scope.closeDialogOnClick = function() {
        $mdDialog.hide();
      };

      $scope.addScenarioOnClick = function(){
        addScenario();
        $mdDialog.hide();
      };

      function addScenario (){
        var data  = {
          "Id": null,
          "Description": $scope.scenarioDescription,
          "LaboratoryId": $scope.selectedLaboratory,
          "ScenarioStatusTypeId": E2E_CONSTANTS.testScenarioStatusTypeId
        };

        testDataService.addTestScenario(data)
          .then(function (data) {
            getTestScenarios();
          }, function (message) {
              var outputMessage = message ? message : "error connecting to service.";
              alert(outputMessage);
              console.log(outputMessage);
          });
      };

      //Edit scenario
      $scope.editScenarioOnClick = function(ev){
        if ($scope.selectedLaboratory != "") {
          var selectedRows = $scope.gridApi.selection.getSelectedRows();

          if (e2eCommonService.verifyGridRecordSelected(selectedRows)){
            $state.go('e2eTestingEdit', {'testScenarioId' : selectedRows[0].Id});
          };
        } else {
         // alert("Please select a Laboratory from dropdown.");
         promptSelectDialogue(ev);
        };
      };
      function promptSelectDialogue (ev) {
        $scope.scenarioDescription = "";
        $mdDialog.show({
          contentElement: '#SelectDescriptionDialogue',
          parent: angular.element(document.body),
          targetEvent: ev,
          clickOutsideToClose: false
        });
      }; 
      //Generate data methods
      $scope.generateScenarioDataOnClick = function(ev){
        if ($scope.selectedLaboratory != "") {
          if (e2eCommonService.verifyGridRecordSelected($scope.gridApi.selection.getSelectedRows())){
            var selectedRows = $scope.gridApi.selection.getSelectedRows();
            e2eCommonService.generateScenarioData(selectedRows).then(function(res){
              getTestScenarios();
            }, function(error){
              getTestScenarios();
              alert(error);    
            });
          };
        } else {
          //alert("Please select a Laboratory from dropdown."); 
          promptSelectDialogue(ev);       
        };
      };

      //Execute scenario
      $scope.accessionGrid = {
        enableRowSelection: true,
        enableSelectAll: true,
        selectionRowHeaderWidth: 35,
        rowHeight: 35,
        showGridFooter: true, 
        enableFiltering: true,
        enableGridMenu: true,
        enableGroupHeaderSelection: false,
        multiSelect: true
      };
    
      $scope.accessionGrid.columnDefs = [
        { field: 'Id', displayName: 'Id', minWidth: 25 },
        { field: 'AccessionNumber', displayName: 'Accession', minWidth: 50 },
        { field: 'Subprotocol', displayName: 'Project', minWidth: 50 },
        { field: 'FromSystem', displayName: 'From', minWidth: 50 },
        { field: 'ToSystem', displayName: 'To', minWidth: 50 },
        { field: 'MessageDt', displayName: 'Message Id', minWidth: 50 },
        { field: 'MessageSequence', displayName: 'Message Seq', minWidth: 50 },
        { field: 'CreatedDateTime', displayName: 'Created', minWidth: 50 }
      ];

      $scope.accessionGrid.onRegisterApi = function (accessionGridApi) {
        $scope.accessionGridApi = accessionGridApi;
        accessionGridApi.grouping.clearGrouping();
        accessionGridApi.selection.on.rowSelectionChanged($scope, function (row) {
          console.log(row.entity.Id);
        });
        accessionGridApi.selection.on.rowSelectionChangedBatch($scope, function (row) {
          $scope.countRows = $scope.accessionGridApi.selection.getSelectedRows().length;
          console.log($scope.countRows);
        });
      };

      $scope.executeScenarioOnClick = function(ev){
        if ($scope.selectedLaboratory != "") {
          if (e2eCommonService.verifyGridRecordSelected($scope.gridApi.selection.getSelectedRows())){
            executeScenario(ev);
          };
        } else {
         //alert("Please select a Laboratory from dropdown.");
         promptSelectDialogue(ev);
        };
      };

      function executeScenario(ev){
        $scope.selectedScenarioId = $scope.gridApi.selection.getSelectedRows()[0].Id;
        GetDialogData();
        $scope.dialogExecutionDescription = "";
        $mdDialog.show({
          contentElement: '#executeScenarioDialog',
          parent: angular.element(document.body),
          targetEvent: ev,
          clickOutsideToClose: false
        });

        function GetDialogData(){
          testDataService.getTXesNotExecutedByTestScenario($scope.selectedScenarioId)
            .then(function (response) {
              $scope.accessionGrid.data = response.data;
              $scope.accessionGridApi.core.handleWindowResize();
              console.log("TX");
              console.log(response.data);
            }, function (error) {
              console.log(error);
          });
        };
      };

      $scope.sendScenarioOrdersOnClick = function(){
        sendScenarioOrders();
      };

      function sendScenarioOrders(){
        var selectedOrders = $scope.accessionGridApi.selection.getSelectedRows();
        if (selectedOrders.length > 0){
          var data = {
            "TestScenarioId": $scope.selectedScenarioId,
            "Description": $scope.executionDescription,
            "ExecutionResultTypeId": E2E_CONSTANTS.testExecutionResultTypeId
          };
  
          testDataService.addTestExecution(data)
          .then(function (response) {
            console.log('Test Execution Id');
            console.log(response.data.id);
            sendOrders(response.data.Id);
          }, function (message) {
              var outputMessage = message ? message : "error connecting to service.";
              alert(outputMessage);
              console.log(outputMessage);
              return;
          });
        }else{
         // alert("Please select at least one order to include in the test.");
          prompttestSelectDialogue(ev);
        };
      };

      function sendOrders(testExecutionId){
          var selectedOrders = $scope.accessionGridApi.selection.getSelectedRows();
          selectedOrders.forEach(function (item){
            testDataService.txExecuteOrder(item.Id, testExecutionId)
            .then(function () {
              console.log("TX: " + item.Id + " ordered");
            }, function (message) {
              var outputMessage = message ? message : "error connecting to service.";
              alert(outputMessage);
              console.log(outputMessage);
            });
        });
        $scope.closeDialogOnClick();
        getTestScenarios();
      };

      //Review results methods
      $scope.reviewResultsOnClick = function(ev){
        if ($scope.selectedLaboratory != "") {
          if (verifyRecordSelected()){
            reviewResults();
          };
        } else {
          //alert("Please select a Laboratory from dropdown.");
          promptSelectDialogue(ev);
        };
      };

      function reviewResults(){

      };

    }
  );
};
