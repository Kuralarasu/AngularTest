module.exports = function(app) {
  "use strict";

  app.controller("testScenarioCompleteListController", function(
    $scope,
    $http,
    $stateParams,
    $location,
    $window,
    E2E_CONSTANTS,
    testDataService,
    e2eCommonService
  ) {
      $scope.testExecutionGrid = {
        enableRowSelection: true,
        enableSelectAll: false,
        selectionRowHeaderWidth: 35,
        rowHeight: 35,
        showGridFooter: true, 
        enableFiltering: true,
        enableGridMenu: true,
        enableGroupHeaderSelection: false,
        multiSelect: false
      };
      
      $scope.testExecutionGrid.columnDefs = [
        { field: 'AccessionNumber', displayName: 'Accession', minWidth: 50 },
        { field: 'ContainerId', displayName: 'Container Id', minWidth: 50 },
        { field: 'TestCode', displayName: 'Test Code', minWidth: 50 },
        { field: 'GroupCode', displayName: 'Group Code', minWidth: 50 },
        { field: 'OrderDeliveryStatus', displayName: 'Order Status', minWidth: 50 },
        { field: 'OrderDeliveryDateTime', displayName: 'Order Date', minWidth: 50 },
        { field: 'ResultReceiptStatus', displayName: 'Receipt Status', minWidth: 50 },
        { field: 'ResultReceiptDateTime', displayName: 'Receipt Date', minWidth: 50 },
        { field: 'ZavacorFileStatus', displayName: 'Filed Status', minWidth: 50 }
      ];

      $scope.selectedStatusId = parseInt($stateParams.statusId);
      $scope.selectedLaboratory = "";
      $scope.selectedScenario = "";
      $scope.selectedExecution = "";
      $scope.executeDate = "";
      $scope.executeStatus = "";
      
      initializeData();

      function initializeData(){
        testDataService.getScenarioStatusType($scope.selectedStatusId)
        .then(function (response) {
          $scope.selectedStatus = response.data;
          console.log("Selected Status");
          console.log(response.data);
        }, function (error) {
          console.log(error);
        });

        testDataService.getLaboratories()
        .then(function (response) {
          $scope.laboratoryData = response.data;
          console.log("Laboratories");
          console.log(response.data);
        }, function (error) {
          console.log(error);
        });
      };

      $scope.getLabTestScenariosOnChange = function (laboratoryId) {
        $scope.selectedScenario = "";
        $scope.selectedExecution = "";
        $scope.executeDate = "";
        $scope.executeStatus = "";
        $scope.testExecutionGrid.data = [];
        testDataService.getLaboratoryTestScenarios($scope.selectedLaboratory)
        .then(function (response) {
          $scope.scenarioData = response.data;
          console.log("Test Scenarios");
          console.log(response.data);
        }, function (error) {
          console.log(error);
        });
      };

      $scope.getTestExecutionsOnChange = function (scenarioId) {
        $scope.selectedExecution = "";
        $scope.executeDate = "";
        $scope.executeStatus = "";
        $scope.testExecutionGrid.data = [];
        testDataService.getCompleteTestExecutionsByScenario(scenarioId)
        .then(function (response) {
          $scope.executionStatusData = response.data;
          console.log("Test Executions");
          console.log(response.data);
        }, function (error) {
          console.log(error);
        });
      };

      $scope.getTestExecutionStatusOnChange = function(executionId){
        testDataService.getTestExecutionsStatusByExecutionWOComment(executionId)
        .then(function (response) {
          $scope.testExecutionGrid.data = response.data;
          $scope.executionDate = response.data[0].ExecuteDateTime;
          $scope.executionStatus = response.data[0].ExecutionResultDescription;
          $scope.testExecutionGrid.core.handleWindowResize();
          console.log("Test Execution Status");
          console.log(response.data);
        }, function (error) {
          console.log(error);
        });
      };

    });
};
