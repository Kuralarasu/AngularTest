module.exports = function(app) {
  "use strict";

  app.controller("testScenarioEditListController", function(
    $scope,
    $http,
    $stateParams,
    $location,
    $window,
    E2E_CONSTANTS,
    testDataService,
    e2eCommonService
  ) {
      $scope.testScenarioGrid = {
        enableRowSelection: true,
        enableSelectAll: true,
        selectionRowHeaderWidth: 35,
        rowHeight: 35,
        showGridFooter: true, enableFiltering: true,
        enableGridMenu: true,
        enableGroupHeaderSelection: false,
        multiSelect: false
      };
      
      $scope.testScenarioGrid.columnDefs = [

        { field: 'Id', 
            enableHiding: false,
            displayName: 'Scenario Id',
            cellTemplate: '<div class="ui-grid-cell-contents tooltip-uigrid" title="{{row.entity.Code}}" ><a ui-sref="e2eTestingEdit" Style="color: rgb(31, 116, 140);"><b>{{COL_FIELD}}</b></a></div>',
            minWidth: 50 },
        { field: 'Description', displayName: 'Scenario Description', minWidth: 50 },
        { field: 'LaboratoryDescription', displayName: 'Laboratory', minWidth: 50 },
        { field: 'UserCreated',  displayName: 'Created By', minWidth: 50 }
      ];

      $scope.testScenarioGrid.onRegisterApi = function (gridApi) {
        $scope.gridApi = gridApi;
        gridApi.grouping.clearGrouping();
        gridApi.selection.on.rowSelectionChanged($scope, function (row) {
          console.log(row.entity.Id);
        });
        gridApi.selection.on.rowSelectionChangedBatch($scope, function (row) {
          $scope.countRows = $scope.gridApi.selection.getSelectedRows().length;
          console.log($scope.countRows);
        });
      };

      $scope.selectedStatusId = parseInt($stateParams.statusId);
      
      initializeData();

      function initializeData(){
        testDataService.getScenarioStatusType($scope.selectedStatusId)
        .then(function (response) {
          $scope.selectedStatus = response.data;
          console.log("Selected Status");
          console.log(response.data);
        }, function (error) {
          console.log(error);
        });

        testDataService.getLaboratories()
        .then(function (response) {
          $scope.laboratoryData = response.data;
          console.log("Laboratories");
          console.log(response.data);
        }, function (error) {
          console.log(error);
        });

        testDataService.getTestScenariosByStatus($scope.selectedStatusId)
        .then(function (response) {
          $scope.testScenarioData = response.data;
          $scope.testScenarioGrid.data = e2eCommonService.mergeTestScenarioWithLaboratory($scope.testScenarioData, $scope.laboratoryData);
          $scope.gridApi.core.handleWindowResize();
          console.log("Test Scenarios");
          console.log(response.data);
        }, function (error) {
          console.log(error);
        });
      };

      $scope.editScenarioOnClick = function(ev){
        if (e2eCommonService.verifyGridRecordSelected($scope.gridApi.selection.getSelectedRows())){
          $location.path('/e2eTestingEdit/');
        };
      };

      $scope.generateScenarioDataOnClick = function(ev){
        if (e2eCommonService.verifyGridRecordSelected($scope.gridApi.selection.getSelectedRows())){
          var selctedRecords = $scope.gridApi.selection.getSelectedRows();
          e2eCommonService.generateScenarioData(selctedRecords).then(
            function(res){
              initializeData();
            },
            function(error){
              initializeData();
              //alert(error);
            });
        }
      };
  });
};
