module.exports = function(app) {
  "use strict";

  app.controller("testScenarioEditController", function(
    $scope,
    $http,
    $stateParams,
    $location,
    $window,
    $mdDialog,
    E2E_CONSTANTS,
    testDataService
  ) {

        $scope.ContainersGrid = {
                enableFiltering: true,
                enableGridMenu: true,
                columnDefs: [
                    { field: 'Id', displayName: 'Cont Def Id',minWidth: 100, cellTooltip: true },
                    { field: 'Container', displayName: 'Container Id',minWidth: 100, cellTooltip: true },
                    { field: 'GroupContainer', displayName: 'Group Container Id',minWidth: 100, cellTooltip: true },
                    { field: 'TestCode',displayName: 'Test Code',minWidth: 100, cellTooltip: true },
                    { field: 'GroupCode', displayName: 'Group Code', minWidth: 100 },
                    { field: 'GroupName', displayName: 'Group Name', minWidth: 100 },
                    { field: 'SpecimenType', displayName: 'Specimen Type', minWidth: 100 },
                    { field: 'SpecTypeDesc', displayName: 'Spec Type Desc', minWidth: 100 },
                    { field: 'LabelLine1', displayName: 'Label Line ', minWidth: 150 },
                    { field: 'LabelLine2', displayName: 'Label Line 2', minWidth: 100 },
                    { field: 'ReceivedCondition', displayName: 'Rec.Condition', minWidth: 100 },
                    { field: 'PackageClass', displayName: 'Package Class', minWidth: 100 },
                    { field: 'PackageId', displayName: 'Package Id', minWidth: 100 },
                    { field: 'PackagePosition', displayName: 'Package Position', minWidth: 100 },
                    {
                    name: 'Edit/Remove',
                    cellTemplate: '<div><md-button class="md-fab md-mini md-primary" ng-click="grid.appScope.editResultRow(row)"><i class="glyphicon glyphicon-edit"></i></md-button><md-button class="md-fab md-mini md-warn" ng-click="grid.appScope.deleteRow(row)"><i class="glyphicon glyphicon-trash"></i></md-button></div>'
                    , minWidth: 150
                }
                    
                ]
            };
    $scope.ContainersGrid.data = [];

    $scope.AdminQuestionsGrid = {
                enableFiltering: true,
                enableGridMenu: true,
                columnDefs: [
                    
                    
                    { field: 'TestCode',displayName: 'Test Code',minWidth: 100, cellTooltip: true },
                    { field: 'TestDescription',displayName: 'Test Description',minWidth: 100, cellTooltip: true },
                    { field: 'ResultAsEntered', displayName: 'Result As Entered', minWidth: 100 },
                    { field: 'ConvResult', displayName: 'Conv. Result', minWidth: 100 },
                    { field: 'ConvUnit', displayName: 'Conv. Unit', minWidth: 100 },
                    { field: 'ResultFormat', displayName: 'Result Format', minWidth: 100 },
                    {
                    name: 'Edit/Remove',
                    cellTemplate: '<div><md-button class="md-fab md-mini md-primary" ng-click="grid.appScope.editResultRow(row)"><i class="glyphicon glyphicon-edit"></i></md-button><md-button class="md-fab md-mini md-warn" ng-click="grid.appScope.deleteRow(row)"><i class="glyphicon glyphicon-trash"></i></md-button></div>'
                    , minWidth: 150
                }
                    
                ]
            };
    $scope.AdminQuestionsGrid.data = [];

    $scope.ProjectLevelAdminsGrid = {
                enableFiltering: true,
                enableGridMenu: true,
                columnDefs: [
                    
                    
                    { field: 'TestCode',displayName: 'Test Code',minWidth: 100, cellTooltip: true },
                    { field: 'AsEntered',displayName: 'As Entered',minWidth: 100, cellTooltip: true },
                    { field: 'ConvResult', displayName: 'Conv Result', minWidth: 100 },
                    { field: 'ConvUnit', displayName: 'Conv Unit', minWidth: 100 },
                    { field: 'SIUnit', displayName: 'SI Unit', minWidth: 100 },
                    {
                    name: 'Edit/Remove',
                    cellTemplate: '<div><md-button class="md-fab md-mini md-primary" ng-click="grid.appScope.editResultRow(row)"><i class="glyphicon glyphicon-edit"></i></md-button><md-button class="md-fab md-mini md-warn" ng-click="grid.appScope.deleteRow(row)"><i class="glyphicon glyphicon-trash"></i></md-button></div>'
                    , minWidth: 150
                }
                    
                ]
            };
    $scope.ProjectLevelAdminsGrid.data = [];

    $scope.TestLevelAdminsGrid = {
                enableFiltering: true,
                enableGridMenu: true,
                columnDefs: [
                    { field: 'ContainerTestDefinitionId', displayName: 'Cont Def Id', minWidth: 100 },
                    { field: 'TestCode',displayName: 'Test Code',minWidth: 100, cellTooltip: true },
                    { field: 'AsEntered',displayName: 'As Entered',minWidth: 100, cellTooltip: true },
                    { field: 'ConvResult', displayName: 'Conv Result', minWidth: 100 },
                    { field: 'ConvUnit', displayName: 'Conv Unit', minWidth: 100 },
                    { field: 'SIUnit', displayName: 'SI Unit', minWidth: 100 },
                    {
                    name: 'Edit/Remove',
                    cellTemplate: '<div><md-button class="md-fab md-mini md-primary" ng-click="grid.appScope.editResultRow(row)"><i class="glyphicon glyphicon-edit"></i></md-button><md-button class="md-fab md-mini md-warn" ng-click="grid.appScope.deleteRow(row)"><i class="glyphicon glyphicon-trash"></i></md-button></div>'
                    , minWidth: 150
                }
                    
                ]
            };
    $scope.TestLevelAdminsGrid.data = [];

    $scope.testScenarioId = parseInt($stateParams.testScenarioId);

    initializeData();
    
            
          function initializeData(){

            testDataService.getTestScenario($scope.testScenarioId)
            .then(function (response) {
              $scope.testScenarioData = response.data;
              console.log("laboratoryTestScenarios");
              console.log(response.data);
              testDataService.getLaboratory(response.data.LaboratoryId)
              .then(function(response){
                $scope.laboratoryData = response.data;
                console.log("Laboratory");
                console.log(response.data);
              }, function (error) {
                console.log(error);
              });
            }, function (error) {
              console.log(error);
            });
    
            testDataService.getOrderDefinitions($scope.testScenarioId)
            .then(function (response) {
                $scope.orderData = response.data;
                console.log("Order Definition");
                console.log(response.data);
            }, function (error) {
                console.log(error);
            });
            
            testDataService.getTxToTypes()
            .then(function (response) {
                $scope.txToTypesData = response.data;
                console.log("getTxToTypes");
                console.log(response.data);
            }, function (error) {
                console.log(error);
            });

            testDataService.getTxFromTypes()
            .then(function (response) {
                $scope.txFromTypesData = response.data;
                console.log("getTxFromTypes");
                console.log(response.data);
            }, function (error) {
                console.log(error);
            });

            testDataService.getPatients()
            .then(function (response) {
                $scope.patientData = response.data;
                console.log("Patients");
                console.log(response.data);
            }, function (error) {
                console.log(error);
            });     

            testDataService.getEthnicityTypes()
            .then(function (response) {
                $scope.ethnicityData = response.data;
                console.log("EthnicityTypes");
                console.log(response.data);
            }, function (error) {
                console.log(error);
            });     
            

            testDataService.getVisitDefinitions()
            .then(function (response) {
                $scope.visitData = response.data;
                console.log("Visit Definition");
                console.log(response.data);
            }, function (error) {
                console.log(error);
            });
            
            testDataService.getInvestigators()
            .then(function (response) {
                $scope.investigatorData = response.data;
                console.log("Investigators");
                console.log(response.data);
            }, function (error) {
                console.log(error);
            });

            testDataService.getAdminTestCodeTypes()
            .then(function (response) {
                $scope.adminTestCodeTypeData = response.data;
                console.log("AdminTestCodeTypes");
                console.log(response.data);
            }, function (error) {
                console.log(error);
            });

            testDataService.getTestCodeTypes()
            .then(function (response) {
                $scope.testCodeTypeData = response.data;
                console.log("TestCodeTypes");
                console.log(response.data);
            }, function (error) {
                console.log(error);
            });

            $scope.order = {
                "Id": "0",
                "FromTxTypeId" : "",
                "ToTxTypeId" : "", 
                "ProjectId" : "", 
                "ProjectActive" : "",
                "InvestigatorDefinitionId" : "", 
                "PatientDefinitionId" : "",
                "VisitDefinitionId" : "",
                "CollectionDateTime" : "",
                "ReceiptDateTime" : "",
                "InvestigatorId" : "",
                "FullName" : "",
                "FirstName" : "",
                "LastName" : "",
                "Address" : "",
                "City" : "",
                "State" : "",
                "Zip" : "",
                "Country" : "",
                "Initials" : "",
                "Gender" : "",
                "Ethnicity" : "",
                "DOB" : "",
                "VisitDescription" : "",
                "VisitCode" : "",
                "KitType" : "",
                "TestScenarioId" : $scope.testScenarioId
            };

            $scope.containerTest = {
                "Id": "",
                "OrderDefinitionId": "",
                "Container": "",
                "TestCode": "",
                "GroupCode": "",
                "GroupName": "",
                "SpecimenType": "",
                "SpecTypeDesc": "",
                "LabelLine1": "",
                "LabelLine2": "",
                "ReceivedCondition": "",
                "PackageClass": "",
                "PackageId": "",
                "PackagePosition": "",
                "GroupContainer": ""
            };

            $scope.adminQuestion = {
                "Id": "",
                "OrderDefinitionId": "",
                "TestCode": "",
                "TestDescription": "",
                "ResultAsEntered": "",
                "ConvResult": "",
                "ConvUnit": "",
                "ResultFormat": ""
            };

            $scope.projectAdmin = {
                "Id": "",
                "OrderDefinition": "",
                "TestCode": "",
                "AsEntered": "",
                "ConvResult": "",
                "SIUnit": "",
                "ConvUnit": ""
            };

            $scope.testAdmin = {
                "Id": "",
                "OrderDefinition": "",
                "TestCode": "",
                "AsEntered": "",
                "ConvResult": "",
                "SIUnit": "",
                "ConvUnit": "",
                "ContainerTestDefinitionId": "0"
            };

          };

          $scope.setOrderFields = function (orderId) {
                var index = $scope.orderData.findIndex(function(x) {return x.Id == orderId;});
                this.order.FromTxTypeId = $scope.orderData[index].TXFromTypeId; 
                this.order.ToTxTypeId = $scope.orderData[index].TXToTypeId; 
                this.order.ProjectId = $scope.orderData[index].ProjectId; 
                this.order.ProjectActive = $scope.orderData[index].ProjectActive;
                this.order.InvestigatorDefinitionId = $scope.orderData[index].InvestigatorDefinitionId; 
                setInvestigatorFields(this.order.InvestigatorDefinitionId, this.order);
                this.order.PatientDefinitionId = $scope.orderData[index].PatientDefinitionId; 
                setPatientFields(this.order.PatientDefinitionId, this.order);
                this.order.VisitDefinitionId = $scope.orderData[index].VisitDefinitionId; 
                setVisitFields(this.order.VisitDefinitionId, this.order);
                var dateControl = document.querySelector('input[ng-model="order.CollectionDateTime"]');
                dateControl.value = $scope.orderData[index].CollectionDateTime;
                var dateControl = document.querySelector('input[ng-model="order.ReceiptDateTime"]');
                dateControl.value = $scope.orderData[index].ReceiptDateTime;
                $scope.getContainerTestDefinitionsByOrderId(orderId);
                $scope.getAdminQuestionsByOrderId(orderId);
                $scope.getProjectAdminsByOrderId(orderId);
                $scope.getTestAdminsByOrderId(orderId);
            };

            $scope.setInvestigatorFields = function(investigatorId){
                setInvestigatorFields(investigatorId, this.order);
            };

            function setInvestigatorFields(idField, scopeObj){
                var index = $scope.investigatorData.findIndex(function(x) {return x.Id == idField});
                scopeObj.InvestigatorId = $scope.investigatorData[index].InvestigatorId;
                scopeObj.FullName = $scope.investigatorData[index].FullName;
                scopeObj.FirstName = $scope.investigatorData[index].FirstName;
                scopeObj.LastName = $scope.investigatorData[index].LastName;
                scopeObj.Address = $scope.investigatorData[index].Address;
                scopeObj.City = $scope.investigatorData[index].City;
                scopeObj.State = $scope.investigatorData[index].State;
                scopeObj.Zip = $scope.investigatorData[index].Zip;
                scopeObj.Country = $scope.investigatorData[index].Country;
            };

            $scope.setPatientFields = function(patientId){
                setPatientFields(patientId, this.order)
            };

            function setPatientFields(idField, scopeObj){
                var index = $scope.patientData.findIndex(function(x) {return x.Id==idField});
                scopeObj.Initials = $scope.patientData[index].Initials;
                scopeObj.Gender = $scope.patientData[index].Gender;
                scopeObj.Ethnicity = $scope.patientData[index].Ethnicity; 
                var dateControl = document.querySelector('input[ng-model="order.DOB"]');
                dateControl.value = $scope.patientData[index].DateOfBirth.substring(0,10);
            };

            $scope.setVisitFields = function(visitId){
                setVisitFields(visitId, this.order);
            };

            function setVisitFields(idField, scopeObj){
                var index = $scope.visitData.findIndex(function(x) {return x.Id==idField});
                scopeObj.VisitDescription = $scope.visitData[index].Description;
                scopeObj.VisitCode = $scope.visitData[index].VisitCode;
                scopeObj.KitType = $scope.visitData[index].KitType;

            };

            $scope.getContainerTestDefinitionsByOrderId = function (orderId) {
                testDataService.getContainerTestDefinitionsByOrderId(orderId)
                .then(function (response) {
                    $scope.ContainersGrid.data = response.data;
                    $scope.containerTestData = response.data;
                    console.log("getContainerTestDefinitionsByOrderId");
                    console.log(response.data);
                }, function (error) {
                    console.log(error);
                });
            };

            $scope.getAdminQuestionsByOrderId = function (orderId) {
                testDataService.getAdminQuestionsByOrderId(orderId)
                .then(function (response) {
                    $scope.AdminQuestionsGrid.data = response.data;
                    console.log("getAdminQuestionsByOrderId");
                    console.log(response.data);
                }, function (error) {
                    console.log(error);
                });
            };
  
            $scope.getProjectAdminsByOrderId = function (orderId) {
                testDataService.getProjectAdminsByOrderId(orderId)
                .then(function (response) {
                    $scope.ProjectLevelAdminsGrid.data = response.data;
                    console.log("getProjectAdminsByOrderId");
                    console.log(response.data);
                }, function (error) {
                    console.log(error);
                });
            };
  
            $scope.getTestAdminsByOrderId = function (orderId) {
                testDataService.getTestAdminsByOrderId(orderId)
                .then(function (response) {
                    $scope.TestLevelAdminsGrid.data = response.data;
                    console.log("getTestAdminsByOrderId");
                    console.log(response.data);
                }, function (error) {
                    console.log(error);
                });
            };

            $scope.clearOrderDefinition = function(){
                this.order.Id = "0"; 
                this.order.FromTxTypeId = ""; 
                this.order.ToTxTypeId = ""; 
                this.order.ProjectId = ""; 
                this.order.ProjectActive = "";
                this.order.InvestigatorDefinitionId = ""; 
                this.order.PatientDefinitionId = "";
                this.order.VisitDefinitionId = "";
                var dateControl = document.querySelector('input[ng-model="order.CollectionDateTime"]');
                dateControl.value = "";
                var dateControl = document.querySelector('input[ng-model="order.ReceiptDateTime"]');
                dateControl.value = "";
                this.order.InvestigatorId = "";
                this.order.FullName = "";
                this.order.FirstName = "";
                this.order.LastName = "";
                this.order.Address = "";
                this.order.City = "";
                this.order.State = "";
                this.order.Zip = "";
                this.order.Country = "";
                this.order.Initials = "";
                this.order.Gender = "";
                this.order.Ethnicity = "";
                var dateControl = document.querySelector('input[ng-model="order.DOB"]');
                dateControl.value = "";
                this.order.VisitDescription = "";
                this.order.VisitCode = "";
                this.order.KitType = "";
                $scope.ContainersGrid.data = [];
                $scope.AdminQuestionsGrid.data = [];
                $scope.ProjectLevelAdminsGrid.data = [];
                $scope.TestLevelAdminsGrid.data = [];
                $scope.testAdmin.ContainerTestDefinitionId = "0";
            };
            
            function dateFormat(dateObj){
                return dateObj.getFullYear() + "-" + (dateObj.getMonth() + 1) + "-" + dateObj.getDate();
            };

            function dateTimeFormat(dateObj){
                return dateObj.getFullYear() + "-" + (dateObj.getMonth() + 1) + "-" + dateObj.getDate() + " " + dateObj.getHours() + ":" + dateObj.getMinutes() + ":00";
            };

            $scope.saveOrderDefinition = function(){
                /*
                var patientDefinitionObj = {
                    "Id": this.order.PatientDefinitionId,
                    "Initials": this.order.Initials,
                    "Ethnicity": this.order.Ethnicity,
                    "Gender": this.order.Gender,
                    "DateOfBirth": dateFormat(this.order.DOB)
                };

                testDataService.postPatientDefinition(patientDefinitionObj)
                .then(function (data) {
                  $scope.selectedPatientId = response.data.Id;
                }, function (message) {
                    var outputMessage = message ? message : "error connecting to service.";
                    alert(outputMessage);
                    console.log(outputMessage);
                });
      
                var visitDefinitionObj = {
                    "Id": this.order.VisitDefinitionId,
                    "Description": this.order.VisitDescription,
                    "VisitCode": this.order.VisitCode,
                    "KitType": this.order.visitKitType
                };

                var investigatorDefinitionObj = {
                    "Id": $scope.order.InvestigatorDefinitionId,
                    "InvestigatorId": this.order.InvestigatorId,
                    "FullName": this.order.FullName,
                    "FirstName": this.order.FirstName,
                    "LastName": this.order.LastName,
                    "Address": this.order.Address,
                    "City": this.order.City,
                    "State": this.order.State,
                    "Zip": this.order.Zip,
                    "Country": this.order.Country
                };  
                */
                var orderDefinitionObj = {
                    "Id": this.order.Id,
                    "TXFromTypeId": this.order.FromTxTypeId,
                    "TXToTypeId": this.order.ToTxTypeId,
                    "ProjectId": this.order.ProjectId,
                    "ProjectActive": this.order.ProjectActive,
                    "InvestigatorDefinitionId": this.order.InvestigatorDefinitionId,
                    "PatientDefinitionId": this.order.PatientDefinitionId,
                    "VisitDefinitionId": this.order.VisitDefinitionId,
                    "TestScenarioId": $scope.testScenarioId,
                    "CollectionDateTime": dateTimeFormat(this.order.CollectionDateTime),
                    "ReceiptDateTime": dateTimeFormat(this.order.ReceiptDateTime)
                };

                testDataService.postOrderDefinition(orderDefinitionObj)
                .then(function (response) {
                  //$scope.order.Id = response.data.Id;
                  $scope.clearOrderDefinition();

                  //Reload the OrderDefinitions, This seems heavy...  
                  testDataService.getOrderDefinitions($scope.testScenarioId)
                  .then(function (response) {
                      $scope.orderData = response.data;
                      console.log("Order Definition");
                      console.log(response.data);
                  }, function (error) {
                      console.log(error);
                  });

                }, function (message) {
                    var outputMessage = message ? message : "error connecting to service.";
                    alert(outputMessage);
                    console.log(outputMessage);
                });

                testDataService.getOrderDefinitions($scope.testScenarioId)
                .then(function (response) {
                    $scope.orderData = response.data;
                    console.log("Order Definition");
                    console.log(response.data);
                }, function (error) {
                    console.log(error);
                });
                
            };

            $scope.deleteOrderDefinition = function(){

            };

            $scope.configureAddTestModal = function () {
                  clearContainerTest();
                  $mdDialog.show({
                      scope: $scope,
                      contentElement: '#configureAddTestModal',
                      preserveScope: true
                  });
              };

              $scope.setContainerTestFields = function(testCodeType){
                $scope.containerTest.TestCode = testCodeType.ZV_CATEGORY;
                testDataService.getZavTestCodeInfoByTestCodeId(testCodeType.ZV_CATEGORY)
                .then(function (response) {
                    $scope.containerTest.GroupCode = "";
                    $scope.containerTest.GroupName = "";
                    $scope.containerTest.SpecimenType = "";
                    $scope.containerTest.SpecTypeDesc = "";
                    $scope.containerTest.LabelLine1 = "";
                    $scope.containerTest.LabelLine2 = "";
                    $scope.containerTest.ReceivedCondition = "";
                    $scope.containerTest.PackageClass = "";
                    $scope.containerTest.PackageId = "";
                    $scope.containerTest.PackagePosition = "";
                    $scope.containerTest.GroupContainer = "";
                    console.log("ZavTestCodeInfo");
                    console.log(response.data);
                }, function (error) {
                    console.log(error);
                });
              };

              $scope.addContainerTest = function(){
                $scope.containerTest.Id = "";
                $scope.containerTest.OrderDefinitionId = $scope.order.Id;
                testDataService.postContainerTestDefinition($scope.containerTest)
                .then(function (response) {
                    $scope.getContainerTestDefinitionsByOrderId($scope.order.Id);
                    $scope.closeDialog();
                }, function (message) {
                    var outputMessage = message ? message : "error connecting to service.";
                    alert(outputMessage);
                    console.log(outputMessage);
                });
              };

              function clearContainerTest(){
                $scope.containerTest.TestCodeType = "";
                $scope.containerTest.Id = "";
                $scope.containerTest.OrderDefinitionId = "";
                $scope.containerTest.Container = "";
                $scope.containerTest.TestCode = "";
                $scope.containerTest.GroupCode = "";
                $scope.containerTest.GroupName = "";
                $scope.containerTest.SpecimenType = "";
                $scope.containerTest.SpecTypeDesc = "";
                $scope.containerTest.LabelLine1 = "";
                $scope.containerTest.LabelLine2 = "";
                $scope.containerTest.ReceivedCondition = "";
                $scope.containerTest.PackageClass = "";
                $scope.containerTest.PackageId = "";
                $scope.containerTest.PackagePosition = "";
                $scope.containerTest.GroupContainer = "";
              };
              
              $scope.configureAddAdminModal = function () {
                  clearAdminQuestion();
                  $mdDialog.show({
                      scope: $scope,
                      contentElement: '#configureAddAdminModal',
                      preserveScope: true
                  });
              };

              $scope.setAdminQuestionFields = function(testCodeType){
                $scope.adminQuestion.TestCode = testCodeType.ZV_TEST_CD;
                testDataService.getZavTestCodeInfoByTestCodeId(testCodeType.ZV_TEST_CD)
                .then(function (response) {
                    $scope.adminQuestion.TestDescription = response.data.TestLongName;
                    $scope.adminQuestion.ResultAsEntered = "";
                    $scope.adminQuestion.ConvResult = "";
                    $scope.adminQuestion.ConvUnit = response.data.ConvUnitDescription;
                    $scope.adminQuestion.ResultFormat = response.data.TestResultValueType;
                    console.log("ZavTestCodeInfo");
                    console.log(response.data);
                }, function (error) {
                    console.log(error);
                });
              };

              $scope.addAdminQuestion = function(){
                $scope.adminQuestion.Id = "";
                $scope.adminQuestion.OrderDefinitionId = $scope.order.Id;
                testDataService.postAdminQuestionDefinition($scope.adminQuestion)
                .then(function (response) {
                    $scope.getAdminQuestionsByOrderId($scope.order.Id);
                    $scope.closeDialog();
                }, function (message) {
                    var outputMessage = message ? message : "error connecting to service.";
                    alert(outputMessage);
                    console.log(outputMessage);
                });
              };

              function clearAdminQuestion(){
                $scope.adminQuestion.TestCodeType = "";
                $scope.adminQuestion.Id = "";
                $scope.adminQuestion.OrderDefinitionId = "";
                $scope.adminQuestion.TestCode = "";
                $scope.adminQuestion.TestDescription = "";
                $scope.adminQuestion.ResultAsEntered = "";
                $scope.adminQuestion.ConvResult = "";
                $scope.adminQuestion.ConvUnit = "";
                $scope.adminQuestion.ResultFormat = "";
              };

              $scope.configureAddProjectLevelAdminModal = function () {
                  clearProjectAdmin();
                  $mdDialog.show({
                      scope: $scope,
                      contentElement: '#configureAddProjectLevelAdminModal',
                      preserveScope: true   
                  });
              };

              $scope.setProjectAdminFields = function(testCodeType){
                $scope.projectAdmin.TestCode = testCodeType.ZV_TEST_CD;
                testDataService.getZavTestCodeInfoByTestCodeId(testCodeType.ZV_TEST_CD)
                .then(function (response) {
                    $scope.projectAdmin.AsEntered = "";
                    $scope.projectAdmin.ConvResult = "";
                    $scope.projectAdmin.ConvUnit = response.data.ConvUnitDescription;
                    $scope.projectAdmin.SIUnit = response.data.SIUnitDescription;
                    console.log("ZavTestCodeInfo");
                    console.log(response.data);
                }, function (error) {
                    console.log(error);
                });
              };

              $scope.addProjectAdmin = function(){
                $scope.projectAdmin.Id = "";
                $scope.projectAdmin.OrderDefinitionId = $scope.order.Id;
                testDataService.postProjectAdminDefinition($scope.projectAdmin)
                .then(function (response) {
                    $scope.getProjectAdminsByOrderId($scope.order.Id);
                    $scope.closeDialog();
                }, function (message) {
                    var outputMessage = message ? message : "error connecting to service.";
                    alert(outputMessage);
                    console.log(outputMessage);
                });
              };

              function clearProjectAdmin(){
                $scope.projectAdmin.TestCodeType = "";
                $scope.projectAdmin.Id = "";
                $scope.projectAdmin.OrderDefinitionId = "";
                $scope.projectAdmin.TestCode = "";
                $scope.projectAdmin.AsEntered = "";
                $scope.projectAdmin.ConvResult = "";
                $scope.projectAdmin.ConvUnit = "";
                $scope.projectAdmin.SIUnit = "";
              };

              $scope.configureAddTestLevelAdminModal = function () {
                  clearTestAdmin();
                  $mdDialog.show({
                      scope: $scope,
                      contentElement: '#configureAddTestLevelAdminModal',
                      preserveScope: true
                  });
              };

              $scope.setTestAdminFields = function(testCodeType){
                $scope.testAdmin.TestCode = testCodeType.ZV_TEST_CD;
                testDataService.getZavTestCodeInfoByTestCodeId(testCodeType.ZV_TEST_CD)
                .then(function (response) {
                    $scope.testAdmin.AsEntered = "";
                    $scope.testAdmin.ConvResult = "";
                    $scope.testAdmin.ConvUnit = response.data.ConvUnitDescription;
                    $scope.testAdmin.SIUnit = response.data.SIUnitDescription;
                    console.log("ZavTestCodeInfo");
                    console.log(response.data);
                }, function (error) {
                    console.log(error);
                });
              };

              $scope.addTestAdmin = function(){
                $scope.testAdmin.Id = "";
                $scope.testAdmin.OrderDefinitionId = $scope.order.Id;
                testDataService.postTestAdminDefinition($scope.testAdmin)
                .then(function (response) {
                    $scope.getTestAdminsByOrderId($scope.order.Id);
                    $scope.closeDialog();
                }, function (message) {
                    var outputMessage = message ? message : "error connecting to service.";
                    alert(outputMessage);
                    console.log(outputMessage);
                });
              };

              function clearTestAdmin(){
                $scope.testAdmin.TestCodeType = "";
                $scope.testAdmin.Id = "";
                $scope.testAdmin.OrderDefinitionId = "";
                $scope.testAdmin.TestCode = "";
                $scope.testAdmin.AsEntered = "";
                $scope.testAdmin.ConvResult = "";
                $scope.testAdmin.ConvUnit = "";
                $scope.testAdmin.SIUnit = "";
              };

              $scope.closeDialog = function () {
                  $mdDialog.hide();
              };

  
  });
};
