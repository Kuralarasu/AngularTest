module.exports = function (testDataModule) {
    'use strict';
    testDataModule.factory('testDataService', testDataService);

    testDataService.$inject = ['$q', 'eorRestAPIService', 'testDataUrlService'];

    function testDataService($q, eorRestAPIService, testDataUrlService) {
        var testDataObject = {};
        testDataObject.getLaboratories = getLaboratories;
        testDataObject.getLaboratory = getLaboratory;
        testDataObject.getLaboratoryTestScenarios = getLaboratoryTestScenarios;
        testDataObject.addTestScenario = addTestScenario;
        testDataObject.generateScenarioData = generateScenarioData;
        testDataObject.getScenarioStatusType = getScenarioStatusType;
        testDataObject.getTestScenariosByStatus = getTestScenariosByStatus;
        testDataObject.getTXesNotExecutedByTestScenario = getTXesNotExecutedByTestScenario;
        testDataObject.getTXesNotExecutedByLaboratory = getTXesNotExecutedByLaboratory;
        testDataObject.txExecuteOrder = txExecuteOrder;
        testDataObject.addTestExecution = addTestExecution;
        testDataObject.getTxToTypes = getTxToTypes;
        testDataObject.getTxFromTypes = getTxFromTypes;
        testDataObject.getTestScenarios = getTestScenarios;
        testDataObject.getTestScenario = getTestScenario;
        testDataObject.getPatients = getPatients;
        testDataObject.getInvestigators = getInvestigators;
        testDataObject.getVisitDefinitions = getVisitDefinitions;
        testDataObject.getTestScenarioDetails = getTestScenarioDetails;
        testDataObject.getProjects = getProjects;
        testDataObject.getInprogressTestExecutionsByScenario = getInprogressTestExecutionsByScenario;
        testDataObject.getCompleteTestExecutionsByScenario = getCompleteTestExecutionsByScenario;
        testDataObject.getTestExecutionsStatusByExecution = getTestExecutionsStatusByExecution;
        testDataObject.getTestExecutionsStatusByExecutionWOComment = getTestExecutionsStatusByExecutionWOComment;
        testDataObject.getOrderDefinitions = getOrderDefinitions;
        testDataObject.getEthnicityTypes = getEthnicityTypes;
        testDataObject.getContainerTestDefinitionsByOrderId = getContainerTestDefinitionsByOrderId;
        testDataObject.getAdminQuestionsByOrderId = getAdminQuestionsByOrderId;
        testDataObject.getProjectAdminsByOrderId = getProjectAdminsByOrderId;
        testDataObject.getTestAdminsByOrderId = getTestAdminsByOrderId;
        testDataObject.postPatientDefinition = postPatientDefinition;
        testDataObject.postVisitDefinition = postVisitDefinition;
        testDataObject.postInvestigatorDefinition = postInvestigatorDefinition;
        testDataObject.postOrderDefinition = postOrderDefinition;
        testDataObject.getAdminTestCodeTypes = getAdminTestCodeTypes;
        testDataObject.getZavTestCodeInfoByTestCodeId = getZavTestCodeInfoByTestCodeId;
        testDataObject.postAdminQuestionDefinition = postAdminQuestionDefinition;
        testDataObject.postProjectAdminDefinition = postProjectAdminDefinition;
        testDataObject.postTestAdminDefinition = postTestAdminDefinition;
        testDataObject.getTestCodeTypes = getTestCodeTypes;
        testDataObject.postContainerTestDefinition = postContainerTestDefinition;

        //Generic methods
        function get(url, config) {
            var deferred = $q.defer();
            eorRestAPIService.get(url, config).then(
                function (response) {
                    deferred.resolve(response);
                },
                function (error) {
                    deferred.reject(response);
                }
            );
            return deferred.promise;
        };

        function post(url, data, config){
            var deferred = $q.defer();
            eorRestAPIService.post(url, data, config).then(
                function (response) {
                    deferred.resolve(response);
                },
                function (error) {
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        };

        //get methods
        function getTestAdminsByOrderId(orderId) {
            var url = testDataUrlService.getTestAdminsByOrderIdUrl(orderId);
            var config = { withCredentials: false };
            return get(url, config);
        };

        function getProjectAdminsByOrderId(orderId) {
            var url = testDataUrlService.getProjectAdminsByOrderIdUrl(orderId);
            var config = { withCredentials: false };
            return get(url, config);
        };
        
        function getAdminQuestionsByOrderId(orderId) {
            var url = testDataUrlService.getAdminQuestionsByOrderIdUrl(orderId);
            var config = { withCredentials: false };
            return get(url, config);
        };

        function getContainerTestDefinitionsByOrderId(orderId) {
            var url = testDataUrlService.getContainerTestDefinitionsByOrderIdUrl(orderId);
            var config = { withCredentials: false };
            return get(url, config);
        };

        function getLaboratories() {
            var url = testDataUrlService.getLaboratoriesUrl();
            var config = { withCredentials: false };
            return get(url, config);
        };

        function getLaboratory(laboratoryId) {
            var url = testDataUrlService.getLaboratoryUrl(laboratoryId);
            var config = { withCredentials: false };
            return get(url, config);
        };

        function getTxToTypes() {
            var url = testDataUrlService.getTxToTypesUrl();
            var config = { withCredentials: false };
            return get(url, config);
        };

        function getTxFromTypes() {
            var url = testDataUrlService.getTxFromTypesUrl();
            var config = { withCredentials: false };
            return get(url, config);
        };        

        function getTestScenarios() {
            var url = testDataUrlService.getTestScenarios();
            var config = { withCredentials: false };
            return get(url, config);
        }; 

        function getTestScenario(scenarioId) {
            var url = testDataUrlService.getTestScenarioUrl(scenarioId);
            var config = { withCredentials: false };
            return get(url, config);
        }; 

        function getPatients() {
            var url = testDataUrlService.getPatientsUrl();
            var config = { withCredentials: false };
            return get(url, config);
        };     
        
        function getInvestigators() {
            var url = testDataUrlService.getInvestigatorsUrl();
            var config = { withCredentials: false };
            return get(url, config);
        };         

        function getVisitDefinitions() {
            var url = testDataUrlService.getVisitDefinitionsUrl();
            var config = { withCredentials: false };
            return get(url, config);
        }; 
      
        function getTestScenarioDetails(testScenarioId) {
            var url = testDataUrlService.getTestScenarioDetailsUrl(testScenarioId);
            var config = { withCredentials: false };
            return get(url, config);
        };         

        function getProjects() {
            var url = testDataUrlService.getProjectsUrl();
            var config = { withCredentials: false };
            return get(url, config);
        }; 
        
        function getLaboratoryTestScenarios(laboratoryId) {
            var url = testDataUrlService.getLaboratoryTestScenariosUrl(laboratoryId);
            var config = { withCredentials: false };
            return get(url, config);
        };

        function getScenarioStatusType(laboratoryId) {
             var url = testDataUrlService.getScenarioStatusTypeUrl(laboratoryId);
             var config = { withCredentials: false };
            return get(url, config);
        };

        function getTestScenariosByStatus(statusId) {
            var url = testDataUrlService.getTestScenariosByStatusUrl(statusId);
            var config = { withCredentials: false };
           return get(url, config);
       };

       function getTXesNotExecutedByTestScenario(testScenarioId) {
            var url = testDataUrlService.getTXesNotExecutedByTestScenarioUrl(testScenarioId);
            var config = { withCredentials: false };
            return get(url, config);
        };

        function getTXesNotExecutedByLaboratory(laboratoryId) {
            var url = testDataUrlService.getTXesNotExecutedByLaboratoryUrl(laboratoryId);
            var config = { withCredentials: false };
            return get(url, config);
        };

        function getInprogressTestExecutionsByScenario(scenarioId) {
            var url = testDataUrlService.getInprogressTestExecutionsByScenarioUrl(scenarioId);
            var config = { withCredentials: false };
            return get(url, config);
        };

        function getCompleteTestExecutionsByScenario(scenarioId) {
            var url = testDataUrlService.getCompleteTestExecutionsByScenarioUrl(scenarioId);
            var config = { withCredentials: false };
            return get(url, config);
        };

        function getTestExecutionsStatusByExecution(executionId) {
            var url = testDataUrlService.getTestExecutionsStatusByExecutionUrl(executionId);
            var config = { withCredentials: false };
            return get(url, config);
        };
        
        function getTestExecutionsStatusByExecutionWOComment(executionId) {
            var url = testDataUrlService.getTestExecutionsStatusByExecutionWOCommentUrl(executionId);
            var config = { withCredentials: false };
            return get(url, config);
        };

        function getOrderDefinitions(scenarioId) {
            var url = testDataUrlService.getOrderDefinitionsUrl(scenarioId);
            var config = { withCredentials: false };
            return get(url, config);
        };
        
        function getEthnicityTypes() {
            var url = testDataUrlService.getEthnicityTypesUrl();
            var config = { withCredentials: false };
            return get(url, config);
        };

        function getAdminTestCodeTypes() {
            var url = testDataUrlService.getAdminTestCodeTypesUrl();
            var config = { withCredentials: false };
            return get(url, config);
        };
        
        function getZavTestCodeInfoByTestCodeId(testCodeId) {
            var url = testDataUrlService.getZavTestCodeInfoByTestCodeIdUrl(testCodeId);
            var config = { withCredentials: false };
            return get(url, config);
        };

        function getTestCodeTypes() {
            var url = testDataUrlService.getTestCodeTypesUrl();
            var config = { withCredentials: false };
            return get(url, config);
        };
        
        
        //post  methods
        function addTestScenario(newTestScenarioObj) {
            var deferred = $q.defer();
            var url = testDataUrlService.addTestScenarioUrl();
            var config = { withCredentials: true };
            return post(url, newTestScenarioObj, config);
        };

        function generateScenarioData(scenarioIdObj) {
            var deferred = $q.defer();
            var url = testDataUrlService.generateScenarioDataUrl();
            var config = { withCredentials: false };
            return post(url, scenarioIdObj, config);
        };

        function addTestExecution(testExecutionObj) {
            var deferred = $q.defer();
            var url = testDataUrlService.addTestExecutionUrl();
            var config = { withCredentials: false };
            return post(url, testExecutionObj, config);
        };

        function txExecuteOrder(txId, data) {
            var deferred = $q.defer();
            var url = testDataUrlService.txExecuteOrderUrl(txId);
            var config = { withCredentials: false };
            return post(url, data, config);
        };

        function postPatientDefinition(data) {
            var deferred = $q.defer();
            var url = testDataUrlService.postPatientDefinitionUrl();
            var config = { withCredentials: false };
            return post(url, data, config);
        };

        function postVisitDefinition(data) {
            var deferred = $q.defer();
            var url = testDataUrlService.postVisitDefinitionUrl();
            var config = { withCredentials: false };
            return post(url, data, config);
        };

        function postInvestigatorDefinition(data) {
            var deferred = $q.defer();
            var url = testDataUrlService.postInvestigatorDefinitionUrl();
            var config = { withCredentials: false };
            return post(url, data, config);
        };

        function postOrderDefinition(data) {
            var deferred = $q.defer();
            var url = testDataUrlService.postOrderDefinitionUrl();
            var config = { withCredentials: false };
            return post(url, data, config);
        };

        function postAdminQuestionDefinition(data) {
            var deferred = $q.defer();
            var url = testDataUrlService.postAdminQuestionDefinitionUrl();
            var config = { withCredentials: false };
            return post(url, data, config);
        };

        function postProjectAdminDefinition(data) {
            var deferred = $q.defer();
            var url = testDataUrlService.postProjectAdminDefinitionUrl();
            var config = { withCredentials: false };
            return post(url, data, config);
        };

        function postTestAdminDefinition(data) {
            var deferred = $q.defer();
            var url = testDataUrlService.postTestAdminDefinitionUrl();
            var config = { withCredentials: false };
            return post(url, data, config);
        };
        
        function postContainerTestDefinition(data) {
            var deferred = $q.defer();
            var url = testDataUrlService.postContainerTestDefinitionUrl();
            var config = { withCredentials: false };
            return post(url, data, config);
        };

        return testDataObject;
    };
};
