module.exports = function (e2eCommon) {
    'use strict';
    e2eCommon.factory('e2eCommonService', e2eCommonService);

    e2eCommonService.$inject = ['testDataService', '$q'];
    
    function e2eCommonService(testDataService, $q) {
        var commonMethods = {};

        commonMethods.mergeTestScenarioWithLaboratory = mergeTestScenarioWithLaboratory;
        commonMethods.verifyGridRecordSelected = verifyGridRecordSelected;
        commonMethods.generateScenarioData = generateScenarioData;

//Make sure this isn't unique to editlist controller
        function mergeTestScenarioWithLaboratory(testScenarioData, laboratoryData){
            testScenarioData.forEach(function (scenarioItem) {
              laboratoryData.forEach(function (laboratoryType) {
                if (scenarioItem.LaboratoryId === laboratoryType.Id) {
                  scenarioItem.LaboratoryDescription = laboratoryType.Code;
                }
              });
            });
            return testScenarioData;
          };
    
          function verifyGridRecordSelected (selectedGridRecord) {
            console.log("Selected Record");
            console.log(selectedGridRecord);
            if (selectedGridRecord.length == 0){
              alert("Please select a record from grid.");
              return false;
            }else{
              return true;
            };
          };
    
          function generateScenarioData(selectedGridRecord){
            var data = {
              "TestScenerioId": selectedGridRecord[0].Id
            };
            var deferred = $q.defer();
    
           testDataService.generateScenarioData(data)
              .then(function (data) {
                deferred.resolve(data);                
              }, function (message) {
                var outputMessage = message ? message : "error connecting to service.";
                deferred.reject(message);
              });
           return deferred.promise;
          };
    
        return commonMethods;
    };
};
