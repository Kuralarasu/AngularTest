module.exports = function (testDataModule) {
    'use strict';
    testDataModule.service('testDataUrlService', testDataUrlService);

    testDataUrlService.$inject = ['E2E_CONSTANTS'];
    
    function testDataUrlService(E2E_CONSTANTS) {

        this.getLaboratoriesUrl = getLaboratoriesUrl;
        this.getLaboratoryUrl = getLaboratoryUrl;
        this.getLaboratoryTestScenariosUrl = getLaboratoryTestScenariosUrl;
        this.addTestScenarioUrl = addTestScenarioUrl;
        this.generateScenarioDataUrl = generateScenarioDataUrl;
        this.getScenarioStatusTypeUrl = getScenarioStatusTypeUrl;
        this.getTestScenariosByStatusUrl =getTestScenariosByStatusUrl;
        this.getTXesNotExecutedByTestScenarioUrl = getTXesNotExecutedByTestScenarioUrl;
        this.txExecuteOrderUrl = txExecuteOrderUrl;
        this.addTestExecutionUrl = addTestExecutionUrl;
        this.getTxToTypesUrl =getTxToTypesUrl;
        this.getTxFromTypesUrl = getTxFromTypesUrl;
        this.getTestScenariosUrl = getTestScenariosUrl;
        this.getTestScenarioUrl = getTestScenarioUrl;
        this.getPatientsUrl = getPatientsUrl;
        this.getInvestigatorsUrl = getInvestigatorsUrl;
        this.getVisitDefinitionsUrl = getVisitDefinitionsUrl;
        this.getTestScenarioDetailsUrl = getTestScenarioDetailsUrl;
        this.getTXesNotExecutedByLaboratoryUrl = getTXesNotExecutedByLaboratoryUrl
        this.getInprogressTestExecutionsByScenarioUrl = getInprogressTestExecutionsByScenarioUrl;
        this.getCompleteTestExecutionsByScenarioUrl = getCompleteTestExecutionsByScenarioUrl;
        this.getTestExecutionsStatusByExecutionUrl = getTestExecutionsStatusByExecutionUrl;
        this.getTestExecutionsStatusByExecutionWOCommentUrl = getTestExecutionsStatusByExecutionWOCommentUrl;
        this.getProjectsUrl = getProjectsUrl;
        this.getOrderDefinitionsUrl = getOrderDefinitionsUrl;
        this.getEthnicityTypesUrl = getEthnicityTypesUrl;
        this.postPatientDefinitionUrl = postPatientDefinitionUrl;
        this.postVisitDefinitionUrl = postVisitDefinitionUrl;
        this.postInvestigatorDefinitionUrl = postInvestigatorDefinitionUrl;
        this.postOrderDefinitionUrl = postOrderDefinitionUrl;
        this.getContainerTestDefinitionsByOrderIdUrl = getContainerTestDefinitionsByOrderIdUrl;
        this.getAdminQuestionsByOrderIdUrl = getAdminQuestionsByOrderIdUrl;
        this.getProjectAdminsByOrderIdUrl = getProjectAdminsByOrderIdUrl;
        this.getTestAdminsByOrderIdUrl = getTestAdminsByOrderIdUrl;
        this.getAdminTestCodeTypesUrl = getAdminTestCodeTypesUrl;
        this.getZavTestCodeInfoByTestCodeIdUrl = getZavTestCodeInfoByTestCodeIdUrl;
        this.postAdminQuestionDefinitionUrl = postAdminQuestionDefinitionUrl;
        this.postProjectAdminDefinitionUrl = postProjectAdminDefinitionUrl;
        this.postTestAdminDefinitionUrl = postTestAdminDefinitionUrl;
        this.getTestCodeTypesUrl = getTestCodeTypesUrl;
        this.postContainerTestDefinitionUrl = postContainerTestDefinitionUrl;

        //gets
        function getTestAdminsByOrderIdUrl(orderId) {
            var url = E2E_CONSTANTS.testDataServiceUrl + "TestAdminDefinitions?searchExpression=p=>p.OrderDefinitionId==" + orderId;
            return url;
        }

        function getProjectAdminsByOrderIdUrl(orderId) {
            var url = E2E_CONSTANTS.testDataServiceUrl + "ProjectAdminDefinitions?searchExpression=p=>p.OrderDefinitionId==" + orderId;
            return url;
        }

        function getAdminQuestionsByOrderIdUrl(orderId) {
            var url = E2E_CONSTANTS.testDataServiceUrl + "AdminDefinitions?searchExpression=p=>p.OrderDefinitionId==" + orderId;
            return url;
        }

        function getContainerTestDefinitionsByOrderIdUrl(orderId) {
            var url = E2E_CONSTANTS.testDataServiceUrl + "ContainerTestDefinitions?searchExpression=p=>p.OrderDefinitionId==" + orderId;
            return url;
        }

        function getTxToTypesUrl() {
            var url = E2E_CONSTANTS.testDataServiceUrl + "TxToTypes/";
            return url;
        }

        function getTxFromTypesUrl() {
            var url = E2E_CONSTANTS.testDataServiceUrl + "TxFromTypes/";
            return url;
        }

        function getTestScenariosUrl() {
            var url = E2E_CONSTANTS.testDataServiceUrl + "TestScenarios";
            return url;
        }

        function getTestScenarioUrl(scenarioId) {
            var url = E2E_CONSTANTS.testDataServiceUrl + "TestScenarios/" + scenarioId + "?expandGraph=[%22ScenarioStatusType%22]";
            return url;
        }

        function getPatientsUrl() {
            var url = E2E_CONSTANTS.testDataServiceUrl + "PatientDefinitions";
            return url;
        }

        function getInvestigatorsUrl() {
            var url = E2E_CONSTANTS.testDataServiceUrl + "InvestigatorDefinitions";
            return url;
        }     
        
        function getVisitDefinitionsUrl() {
            var url = E2E_CONSTANTS.testDataServiceUrl + "VisitDefinitions";
            return url;
        }  

        function getTestScenarioDetailsUrl(testScenerioId) {
            var url = E2E_CONSTANTS.testDataServiceUrl + "TestScenarios?searchExpression=p=>p.Id==" + testScenerioId + "&expandGraph=[%22PatientDefinition%22,%22VisitDefinition%22,%22InvestigatorDefinition%22]";
            return url;
        }

        function getLaboratoriesUrl() {
            var url = E2E_CONSTANTS.laboratoryServiceUrl + "Laboratories";
            return url;
        }

        function getLaboratoryUrl(laboratoryId) {
            var url = E2E_CONSTANTS.laboratoryServiceUrl + "Laboratories/" + laboratoryId;
            return url;
        }

        /*function getLaboratoryTestScenariosUrl(laboratoryId) {
            //var url = E2E_CONSTANTS.testDataServiceUrl + "TestScenarios?searchExpression=p=>p.LaboratoryId==" + laboratoryId + "&expandGraph=[%22ScenarioStatusType%22]";
            var url = E2E_CONSTANTS.testDataServiceUrl + 'TestScenarios/?searchExpression=p=%3Ep.Id==3';

            return url;
        }*/
         function getLaboratoryTestScenariosUrl(laboratoryId) {
            var url = E2E_CONSTANTS.testDataServiceUrl + "TestScenarios?searchExpression=p=>p.LaboratoryId==" + laboratoryId + "&expandGraph=[%22ScenarioStatusType%22]";

            return url;
        }

        function getScenarioStatusTypeUrl(id){
            var url = E2E_CONSTANTS.testDataServiceUrl + "ScenarioStatusTypes/" + id;
            return url;
        }

        function getTestScenariosByStatusUrl(statusId){
            var url = E2E_CONSTANTS.testDataServiceUrl + "TestScenarios?searchExpression=p=>p.ScenarioStatusTypeId==" + statusId + "&expandGraph=[%22ScenarioStatusType%22]";
            return url;
        }

        function getProjectsUrl(){
            var url = E2E_CONSTANTS.testDataServiceUrl + "ProjectTypes";
            return url;
        }
            
        function getTXesNotExecutedByTestScenarioUrl(testScenarioId){
            var url = E2E_CONSTANTS.testDataServiceUrl + "TXes?searchExpression=p=>p.TestScenarioId = " + testScenarioId + " and p.Executed != %221%22";
            return url;
        }

        function getTXesNotExecutedByLaboratoryUrl(laboratoryId){
            var url = E2E_CONSTANTS.testDataServiceUrl + "TXes?searchExpression=p=>p.TestScenario.LaboratoryId = " + laboratoryId + " and p.Executed != %221%22&expandGraph=[%22TestScenario%22]";
            return url;
        }

        function getInprogressTestExecutionsByScenarioUrl(scenarioId){
            var url = E2E_CONSTANTS.testDataServiceUrl + "TestExecutions?searchExpression=p=>p.TestScenarioId = " + scenarioId + " and p.ExecutionResultTypeId = " + E2E_CONSTANTS.testExecutionResultTypeId + "&expandGraph=[%22ExecutionResultType%22]";            return url;
        }

        function getCompleteTestExecutionsByScenarioUrl(scenarioId){
            var url = E2E_CONSTANTS.testDataServiceUrl + "TestExecutions?searchExpression=p=>p.TestScenarioId = " + scenarioId + " and p.ExecutionResultTypeId != " + E2E_CONSTANTS.testExecutionResultTypeId + "&expandGraph=[%22ExecutionResultType%22]";
            return url;
        }

        function getTestExecutionsStatusByExecutionUrl(executionId){
            var url = E2E_CONSTANTS.testDataServiceUrl + "TestScenarioExecutionStatus?searchExpression=p=>p.ExecutionId = " + executionId;
            return url;
        }

        function getTestExecutionsStatusByExecutionWOCommentUrl(executionId){
            var url = E2E_CONSTANTS.testDataServiceUrl + "TestScenarioExecutionStatus?searchExpression=p=>p.ExecutionId = " + executionId +" and p.CommentFlag=%22%22";
            return url;
        }

        function getOrderDefinitionsUrl(scenarioId){
            var url = E2E_CONSTANTS.testDataServiceUrl + "OrderDefinitions?searchExpression=p=>p.TestScenarioId=" + scenarioId;
            return url;
        }
        
        function getEthnicityTypesUrl(){
            var url = E2E_CONSTANTS.testDataServiceUrl + "EthnicityTypes";
            return url;
        }

        function getAdminTestCodeTypesUrl(){
            var url = E2E_CONSTANTS.testDataServiceUrl + "AdminTestCodeTypes";
            return url;
        }
        
        function getZavTestCodeInfoByTestCodeIdUrl(testCodeId){
            var url = E2E_CONSTANTS.zavacorAdapterServiceUrl + "TestCodeInfo?server=" + E2E_CONSTANTS.e2eDefaultZavacor + "&testCode=" + testCodeId;
            return url;
        }
        
        function getTestCodeTypesUrl(){
            var url = E2E_CONSTANTS.testDataServiceUrl + "TestCodeTypes";
            return url;
        }
        
        //posts
        function addTestScenarioUrl() {
            var url = E2E_CONSTANTS.testDataServiceUrl + "TestScenarios";
            return url;
        }

        function generateScenarioDataUrl(scenarioId){
            var url = E2E_CONSTANTS.testDataServiceUrl + "GenTXTestData";
            return url;
        }

        function addTestExecutionUrl() {
            var url = E2E_CONSTANTS.testDataServiceUrl + "TestExecutions";
            return url;
        }

        function txExecuteOrderUrl(txId){
            var url = E2E_CONSTANTS.testDataServiceUrl + "TXes/"+ txId +"/ExecuteOrder";
            return url;
        }

        function postPatientDefinitionUrl() {
            var url = E2E_CONSTANTS.testDataServiceUrl + "PatientDefinitions";
            return url;
        }

        function postVisitDefinitionUrl() {
            var url = E2E_CONSTANTS.testDataServiceUrl + "VisitDefinitions";
            return url;
        }

        function postInvestigatorDefinitionUrl() {
            var url = E2E_CONSTANTS.testDataServiceUrl + "InvestigatorDefinitions";
            return url;
        }

        function postOrderDefinitionUrl() {
            var url = E2E_CONSTANTS.testDataServiceUrl + "OrderDefinitions";
            return url;
        }

        function postAdminQuestionDefinitionUrl() {
            var url = E2E_CONSTANTS.testDataServiceUrl + "AdminDefinitions";
            return url;
        }
        
        function postProjectAdminDefinitionUrl() {
            var url = E2E_CONSTANTS.testDataServiceUrl + "ProjectAdminDefinitions";
            return url;
        }

        function postTestAdminDefinitionUrl() {
            var url = E2E_CONSTANTS.testDataServiceUrl + "TestAdminDefinitions";
            return url;
        }
        
        function postContainerTestDefinitionUrl() {
            var url = E2E_CONSTANTS.testDataServiceUrl + "ContainerTestDefinitions";
            return url;
        }
        
    }
}