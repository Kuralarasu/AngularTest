module.exports = {
    "order": 7, //define the order of the module to display onto UI
    // "position": 'secondary', //position of the order, default secondary, primary is reserved for topmost nav bar
    "display": "E2E Testing",//Module name to display to UI
    /**
     * Siteminder Authorization ID name
     */
	"auth": ["e2eTesting"],
	"maps": [
        { id: "e2eTesting", state: 'e2eTesting'},
        { id: "eore2eTesting", state: 'eore2eTesting'},
        { id: "e2eTestingEdit", state: 'e2eTestingEdit'},
        { id: "e2eTestingEditList", state: 'e2eTestingEditList'},
        { id: "e2eTestingDefineList", state: 'e2eTestingDefineList'},
        { id: "e2eTestingExecuteList", state: 'e2eTestingExecuteList'},
        { id: "e2eTestingCompleteList", state: 'e2eTestingCompleteList'},
		{ id: "e2eTestingResultView", state: 'e2eTestingResultView'},
    ]
};
