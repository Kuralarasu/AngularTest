module.exports = function (app) {
    
        "use strict";
    
        app.factory('E2E_CONSTANTS', function (EnvironmentConstants) {
    
            var urlObj = {
                //URLs
                "testDataServiceUrl": EnvironmentConstants.host + EnvironmentConstants.testDataServicePort + "/api/v1/",
                "userAuthServiceUrl": EnvironmentConstants.host + EnvironmentConstants.userAuthServiceport + "/api/",
                "laboratoryServiceUrl": EnvironmentConstants.host + EnvironmentConstants.labServiceport + "/api/",
                "masterDataServiceUrl": EnvironmentConstants.host + EnvironmentConstants.cimServiceport + "/api/",
                "zavacorAdapterServiceUrl": EnvironmentConstants.host + EnvironmentConstants.zavacorServiceport + "/api/",
                "e2eDefaultZavacor": EnvironmentConstants.e2eDefaultZavacor,

                //TestScenario Types
                "testScenarioStatusTypeId": 1,
                //Test Execution Result Types
                "testExecutionResultTypeId": 1

            }
    
            return urlObj;
        });
    };
    