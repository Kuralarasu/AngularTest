//For custom styles in Reference Data
require("./styles.less");

//inject the PHOENIX APPLICATION
var phxApp = require('phoenix/phxRoot');

require('./routes')(phxApp);
