module.exports = require('./src/lcpPhoneInput');
