/**
 * Created by ramor11 on 10/18/2016.
 */

module.exports = require('./src/lcpAutocompleteSelect');
