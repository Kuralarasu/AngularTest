## LabCorp Phoenix

This is the core libraries for LabCorp Phoenix project. It contains core layout and colors provided for theme. In addition it has a collection of libraries by our developer called modules. 


## What are modules?

Module are single object element to simplify reusable code thought out the application.  Modules are not required within your modules but will make development quicker. To include a module, it will only be required to require it within your vendor file.

```js
//first module needed to load angular, jquery dependencies and needed dependencies for phxRoot application
require('phoenix');

/**
 *
 * Load application dependencies which will be compiled in vendor.js
 *
 * Module Directories are defined within webpack.config.js where it will search for necessary paths
 * ['.tmp', 'node_modules', 'bower_components']
 *
 *
 */
require('phoenix/lcpSelect'); //the use of lcp-select directive module
///etc.


```


## Dependency Injection

When a new module gets injected into the vendor file, it will need to be part of the application module dependency injection.

```js
    angular.module("test.Module", [/*inject other modules <ocLazyLoader documentation>*/]);
```

##Application Core Dependencies

```js
  "dependencies": {
    "jsface": "2.2.0",
    "jquery": "~2.1.4",
    "angular-animate": "~1.4.8",
    "angular-aria": "~1.4.8",
    "jquery-ui": "~1.11.2",
    "bootstrap": "^3.3.6",
    "angular": "1.5.8",
    "angular-resource": "1.5.8",
    "angular-mocks": "1.5.8",
    "angular-cookies": "1.5.8",
    "angular-sanitize": "1.5.8",
    "angular-messages": "1.5.8",
    "font-awesome": "~4.0",
    "angular-ui-router": "~0.2.15",
    "FileSaver": "https://github.com/eligrey/FileSaver.js.git",
    "moment": "https://github.com/moment/moment.git",
    "angular-hotkeys": "https://github.com/chieffancypants/angular-hotkeys.git",
    "angular-filter": "https://github.com/a8m/angular-filter.git",
    "angular-material": "^1.1.1",
    "material-design-icons": "^2.2.0",
    "angular-uuid4": "^0.3.1",
    "lokijs": "^1.4.1",
    "oclazyload": "^1.0.9"
  }
```


