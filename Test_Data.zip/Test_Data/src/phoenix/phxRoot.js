/**
 * Created by ramor11 on 10/4/2016.
 */
var phxApp = require('./src/_common/app');
require('./src/_common/bootstrap.js');

module.exports = phxApp;
