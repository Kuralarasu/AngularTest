
(function(angular) {
    'use strict';

    angular.module('phxuilib.lcpRepeatDone',[]).directive('lcpRepeatDone', repeatDone);

    repeatDone.$inject = ['$timeout', '$log'];

    function repeatDone($timeout, $log) {
        var repeatId;
        return function(scope, ele, attr) {
            if (scope.$last) {
                attr.$set('repeat-id', repeatId);
                scope.$emit('on-repeat-done', {name: attr.name, uniqueId: repeatId});
            } else {
                if (scope.$first) {
                    repeatId = Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1) + Date.now().toString();
                    //$log.log("Repeat Done id set:", repeatId, scope);
                }
            }

            $log.info('repeat event: ', scope, ele, attr);
            scope.$emit('on-repeat-happens', {scope: scope, attr: attr, ele: ele});
        };
    }

})(window.angular);


