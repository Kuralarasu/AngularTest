/**
 * Created by ramor11 on 10/5/2016.
 */



require('./input-checkbox.less');
require('./checkbox.html.js');
var module = require('./input-checkbox-directive');
module.exports = module;

