/// <reference path="../../../typings/tsd.d.ts" />
/* tslint:disable:no-string-literal */
/**
 * @ngdoc directive
 * @name lcpInputCheckbox
 *
 * @description
 * It will automatically create the elements needed to create a custom radio or checkbox base on LabCorp Style Guide.
 * The lcpInputCheckbox directive allows you to specify custom behaviour on compiled element.
 *
 * It will accept numerous different element set as attributes or objects.
 *
 *
 * @element E
 *
 *
 * lcpInputCheckbox additional accepted attributes.
 * @params { name, label, id, ng-model, value}
 *
 * A collection of attributes that allows creation of custom event handlers that are defined as
 * angular expressions and are compiled and executed within the current scope.
 *
 *
 */

module inputCheckbox.directive {
    class InputCheckbox implements ng.IDirective {
        public restrict = "E";
        public replace = true;
        public scope = {
            _class: "@class",
            checked: "=ngChecked",
            id: "@",
            label: "@",
            name: "@",
            ngModel: "=ngModel",
            type: "@",
            value: "@"
        };
        // public link: (scope: ng.IScope, ele: ng.IAugmentedJQuery, attrs: ng.IAttributes, compile: ng.ICompileService) => void;
        // public compile: ng.IDirectiveCompileFn;
        public link: (scope: ng.IScope, ele: ng.IAugmentedJQuery, attrs: ng.IAttributes) => void;
        public templateUrl: string = "phxuilib/components/lcpCheckbox/checkbox.html";

        public static instance(): ng.IDirective {
            return new InputCheckbox();
        }

        constructor() {
            this.link = this.linkFunc;
        }

        public linkFunc(scope: ng.IScope, ele: ng.IAugmentedJQuery, attrs: ng.IAttributes) {
            if (attrs["type"] === "radio") {
                console.error("input-checkbox can no longer be used for radio buttons");
            }
        }
    }

    angular.module("phxuilib.lcpCheckbox", []).directive("inputCheckbox", InputCheckbox.instance);
}
