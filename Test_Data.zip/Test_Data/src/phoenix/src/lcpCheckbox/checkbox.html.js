angular.module("phxuilib/components/lcpCheckbox/checkbox.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("phxuilib/components/lcpCheckbox/checkbox.html",
    "<div><md-checkbox md-no-ink aria-label=\"{{label}}\" class=\"md-primary {{_class}}\" value=\"{{value}}\" ng-model=\"ngModel\">{{label}}</md-checkbox></div>");
}]);
