'use strict';

describe('Directive: lcpInputCheckbox', function() {
    beforeEach(module('phxuilib'));

    var element,
        scope,
        input,
        label,
        labelText = 'Subscriber',
        name = 'typeRadioSelection',
        value = 'subscriber';

    beforeEach(inject(function($rootScope, $compile) {
        scope = $rootScope.$new();
        scope.firstName = inputText;

        element = angular.element([
            '<lcp-input-checkbox label="',
            labelText,
            '" type="radio" name="',
            name,
            '" value="',
            value,
            '" disabled ',
            'ng-model="ctrl.typeRadioSelection"></lcp-input-checkbox>'
        ].join(''));

        $compile(element)(scope);
        scope.$digest();

        input = element.find('input');
        label = element.find('span');
    }));

    // TODO: these tests need to be un X'd and corrected during checkbox and radio button re-style.
    xit('should have an input field', function() {
        expect(input.length).toBe(1);
    });

    xit('should have a type attribute of "radio"', function() {
        expect(input.getAttribute('type').toEqual('radio'));
    });

    xit('should have a disabled attribute', function() {
        expect(input.attr('disabled')).toBeTruthy();
    });

    xit('should have a label', function() {
        expect(label.length).toBe(1);
        expect(label.html()).toEqual(labelText);
    });
});
