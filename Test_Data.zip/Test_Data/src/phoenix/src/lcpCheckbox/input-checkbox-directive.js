var inputCheckbox;
(function (inputCheckbox) {
    var directive;
    (function (directive) {
        var InputCheckbox = (function () {
            function InputCheckbox() {
                this.restrict = "E";
                this.replace = true;
                this.scope = {
                    _class: "@class",
                    checked: "=ngChecked",
                    id: "@",
                    label: "@",
                    name: "@",
                    ngModel: "=ngModel",
                    type: "@",
                    value: "@"
                };
                this.templateUrl = "phxuilib/components/lcpCheckbox/checkbox.html";
                this.link = this.linkFunc;
            }
            InputCheckbox.instance = function () {
                return new InputCheckbox();
            };
            InputCheckbox.prototype.linkFunc = function (scope, ele, attrs) {
                if (attrs["type"] === "radio") {
                    console.error("input-checkbox can no longer be used for radio buttons");
                }
            };
            return InputCheckbox;
        }());
        angular.module("phxuilib.lcpCheckbox", []).directive("inputCheckbox", InputCheckbox.instance);
    })(directive = inputCheckbox.directive || (inputCheckbox.directive = {}));
})(inputCheckbox || (inputCheckbox = {}));
//# sourceMappingURL=input-checkbox-directive.js.map