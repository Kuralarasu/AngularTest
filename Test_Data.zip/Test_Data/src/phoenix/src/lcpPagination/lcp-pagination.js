	/**
	 * @ngdoc directive
	 * @name lcp.pagination
	 *
	 *
	 * @description
	 *
	 * This directive is a material design styled directive intended to be used with the lcp-table.
	 *
	 * @scope
     *    itemsPerPage: "="  //value for the number of items per page
     *    itemsPerPageOptions: "=",  // array of option values for items per page select
     *    page: "=ngModel", // number of the current page
     *    onPaginate: "&", // callback function upon navigation event
     *    totalItems: "="  // total items in paginated dataset
	 *
	 * @example:
	 *
	 *
	 * ```html
	 *
     *   <lcp-pagination items-per-page="ctrl.paginator.itemsPerPage"
     *               total-items=" ctrl.paginator.totalItems "
     *               ng-model=" ctrl.paginator.currentPage "
     *               on-paginate=" ctrl.paginator.onPageNavigation(start, itemsPerPage) "
     *               items-per-page-options="ctrl.paginator.itemsPerPageOptions"
     *               ></lcp-pagination>
	 *
	 * ```
	 *
	 * ```js
	 *
	 *	self.paginator = {};
	 *	self.paginator.itemsPerPage = 5;
	 *	self.paginator.itemsPerPageOptions = [5, 10, 25, 50, 100];
	 *	self.paginator.currentPage = 1;
	 *	self.paginator.totalItems = 0;
	 *	self.paginator.start = 1;
     *
	 *	self.paginator.onPageNavigation = function(start, itemsPerPage) {
	 *		self.featureData = featureService.getPaginatedData(start, itemsPerPage);
	 *	};
	 *
	 * ```
	 *
	 */

(function (angular) {
	angular.module("lcp.pagination", [])
		.directive("lcpPagination", lcpPagination);
	lcpPagination.$inject = ['$timeout'];

    function lcpPagination($timeout) {
		var directive = {
			restrict: "E",
			require: "ngModel",
			scope: {
				itemsPerPage: "=",
				itemsPerPageOptions: "=",
				page: "=ngModel",
				onPaginate: "&",
				totalItems: "="
			},
			controller: PaginationController,
			bindToController: true,
			controllerAs: "ctrl",
			link: PaginationPostLink,
			template: require('html!./lcp-pagination.html')
		};

        function PaginationController($scope) {
			var self = this;

			$scope.$watch('ctrl.totalItems', function(newV, oldV) {
				self.totalItems = newV;
				if (newV > 0) { // TODO: perhaps not make this judgement
					calculateStartAndEnd();
				}
			});

			var calculateStartAndEnd = function() {
				self.start = Math.min(((self.page - 1) * self.itemsPerPage) + 1, self.totalItems);
				self.end = Math.min((self.start + self.itemsPerPage - 1), self.totalItems);
				if (self.itemsPerPage > 0) {
					self.maxPage = Math.ceil(self.totalItems / self.itemsPerPage);
					self.pages = range(self.maxPage);
				}
			}
			var range = function(size) {
				var x = [];
				var i = 1;
				while(x.push(i++)<size){}
				return x;
			}
			self.onPageChange = function(targetPage) {
				if (targetPage) {
					self.page = targetPage;
				}
				updateListing();
				calculateStartAndEnd();
			}
			self.onItemsPerPageChange = function() {
				self.page = 1;
				updateListing();
				calculateStartAndEnd();
			}
			self.onFirstClick = function() {
				if (self.page > 1) {
					self.page = 1;
					updateListing();
					calculateStartAndEnd();
				}
			}
			self.onPreviousClick = function() {
				if (self.page > 1) {
					self.page--;
					updateListing();
					calculateStartAndEnd();
				}
			}
			self.onNextClick = function() {
				if (self.page < self.maxPage) {
					self.page++;
					updateListing();
					calculateStartAndEnd();
				}
			}
			self.onLastClick = function() {
				if (self.page < self.maxPage) {
					self.page = self.maxPage;
					updateListing();
					calculateStartAndEnd();
				}
			}
			var updateListing = function() {
				if (self.onPaginate) {
					if (self.selectedIndex && self.itemsPerPage > 0) {
						self.page = Math.floor(self.selectedIndex / self.itemsPerPage)
					}
					self.start = Math.min(((self.page - 1) * self.itemsPerPage) + 1, self.totalItems);
					self.end = Math.min((self.start + self.itemsPerPage - 1), self.totalItems);
					self.onPaginate({start: self.start, itemsPerPage: self.itemsPerPage});
				}
			}

		}

		function PaginationPostLink($scope, $element, $attrs, ngModelCtrl) {
			ngModelCtrl.$render = function() {
				$timeout(function() {
					$scope.ctrl.onPageChange($scope.ctrl.page);
				},0);
			};

		}

		return directive;
    };
})(window.angular);
//# sourceMappingURL=input-text-directive.js.map
