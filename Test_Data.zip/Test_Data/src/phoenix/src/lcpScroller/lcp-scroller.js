var scroller;
(function (scroller) {
    var directive;
    (function (directive) {
        var Scroller = (function () {
            function Scroller() {
                this.restrict = "A";
                this.link = this.linkFunc;
            }
            Scroller.instance = function () {
                return new Scroller();
            };
            Scroller.prototype.linkFunc = function (scope, ele, attr, ctrl) {
                ele.bind("scroll", onScroll);
                function onScroll(e) {
                    scope.$emit("table-scroll", { evt: e });
                }
            };
            return Scroller;
        }());
        angular.module("phxuilib.lcpScroller", []).directive("scroller", Scroller.instance);
    })(directive = scroller.directive || (scroller.directive = {}));
})(scroller || (scroller = {}));
//# sourceMappingURL=lcp-scroller.js.map