/// <reference path="../../../typings/tsd.d.ts" />
module scroller.directive {

    // TODO: This directive is not currently used in the app
    class Scroller implements ng.IDirective {
        public restrict = "A";
        public link: (scope: ng.IScope, ele: ng.IAugmentedJQuery, attr: ng.IAttributes, ctrl: any) => void;

        public static instance(): ng.IDirective {
            return new Scroller();
        }
        constructor() {
            this.link = this.linkFunc;
        }

        public linkFunc(scope: ng.IScope, ele: ng.IAugmentedJQuery, attr: ng.IAttributes, ctrl: any) {
            ele.bind("scroll", onScroll);

            function onScroll(e) {
                scope.$emit("table-scroll", {evt: e});
            }

        }

    }

    angular.module("phxuilib.lcpScroller", []).directive("scroller", Scroller.instance);
}


