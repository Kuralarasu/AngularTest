(function(angular) {
    'use strict';

    angular.module('phxuilib.radioButton',[]).directive('lcpInputRadio', inputRadio);

    function inputRadio() {
        var uniqueId = 1;
        var directive = {};
        directive.restrict = 'E'; /* restrict this directive to elements */
        directive.replace = true;
        directive.transclude = true;

        directive.scope = {
            name : '@',
            value : '@',
            lcpModel : '=lcpModel',
            lcpClick: '?=lcpClick'
        };

        directive.template = [
            '<input type="radio" name="{{name}}" value="{{value}}" ng-model="{{lcpModel}}" id="{{::radioId}}" class="lcp-radio" /> ',
            '<label for="{{radioId}}" ng-transclude>  ',
            '</label>'
        ].join('');

        directive.link = function(scope, element, attrs) {
            scope.radioId = 'radio' + uniqueId++;
            $(element).on('click', function(event) {
                event.stopPropagation();
                if (scope.lcpClick) {
                    lcpClick(event);
                }
            });
        };

        return directive;
    }
})(window.angular);


