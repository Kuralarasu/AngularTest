## LCP Radio Button
### Usage

<div class="lcp-group--horizontal">
  <lcp-radio name="radioGroup" value="yes" lcpModel="vm.answer">Yes</lcp-radio>
  <lcp-radio name="radioGroup" value="no" lcpModel="vm.answer">No</lcp-radio>
</div>

<div class="lcp-group--horizontal">
  <lcp-radio name="radioGroup" value="yes" lcpModel="vm.answer">Yes</lcp-radio>
  <lcp-radio name="radioGroup" value="no" lcpModel="vm.answer">No</lcp-radio>
</div>

