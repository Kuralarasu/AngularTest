/// <reference path="../../../typings/tsd.d.ts" />
/* tslint:disable:no-string-literal */
/**
 * @ngdoc directive
 * @name lcpInputText
 *
 * @description
 *
 * TODO:.....The angular directive will just assign the $error to the formController while not actually stopping the
 * directive from executing any more keypress.
 * This directive is a hack to avoid additional keypress on number specify
 *
 */

module lcpInputText.directive {
    class InputText implements ng.IDirective {


        public static $inject: Array<string> = ["$timeout"];
        // public priority = 2;
        public restrict = "E";
        public replace = true; // deprecated
        public require = "?ngModel";
        public scope= {
                focused: "@focused",
                id: "@id",
                label: "@label",
                lcpNumbersOnly: "@",
                maxlength: "@",
                minlength: "@",
                name: "@",
                ngMaxLength: "=ngMaxlength",
                ngMinLength: "=ngMinlength",
                ngRequired: "=ngRequired",
                pattern: "@",
                required: "@",
                type: "@",
                value: "=ngModel"
            };
        public controller = InputTextController;
        public controllerAs = "ctrl";

        public compile: ng.IDirectiveCompileFn;
        public templateUrl: string =  "phxuilib/components/lcpInputText/input-text.html";

        private uniqueId;
        // private focused;
        private _$timeout: ng.ITimeoutService;

        public static instance($timeout: ng.ITimeoutService): angular.IDirective {
            return new InputText($timeout);
        }
        constructor($timeout: ng.ITimeoutService) {
            this._$timeout = $timeout;
            this.compile = this.compileFunc;
        }

        private compileFunc = (ele: ng.IAugmentedJQuery, attrs: ng.IAttributes, transclude: any): ng.IDirectivePrePost => {
            return {
                post: (scope: ng.IScope, postele: ng.IAugmentedJQuery, attr: ng.IAttributes, ctrl: ng.INgModelController) => {
                    Object.keys(attr.$attr).forEach(function (key) {
                        if (key !== "class" && key !== "id" && key !== "ngClass" && key !== "disabled" && key !== "readonly") {
                            postele.removeAttr(attr.$attr[key]);
                        }
                    });

                    let focused = attr["focused"] ? scope.$eval(attr["focused"]) : false,
                        input = postele.find("input");

                    if (focused) {
                        $(input).focus();
                    }

                    // If you have input type=password it wont initialize the input field,
                    // as if it has any data, this will inform the input element, that there is a
                    // value
                    this._$timeout(function () {
                        if (empty) {
                            // console.log("this.empty: ", this.empty, typeof this.empty);
                        } else {
                            console.log("not this.empty: ", this.empty, typeof this.empty, ele);
                        }
                        if (!empty(scope["value"])) {
                            input.addClass("ng-not-empty");
                        }
                    }, 0, false);

                    function empty(mixed_var) {
                        let undef, key, i, len;
                        let emptyValues = [undef, null, false, 0, "", "0"];

                        for (i = 0, len = emptyValues.length; i < len; i++) {
                            if (mixed_var === emptyValues[i]) {
                                return true;
                            }
                        }
                        if (typeof mixed_var === "object") {
                            for (key in mixed_var) {
                                // TODO: should we check for own properties only?
                                if (mixed_var.hasOwnProperty(key)) {
                                    return false;
                                }
                            }
                            return true;
                        }

                        return false;
                    }

                    let onFocus = ($event) => {
                        input.val(input.val().replace(/\t+/g, ""));
                    };

                    input.on("focus", onFocus);

                },
                pre: (scope: ng.IScope, preele: ng.IAugmentedJQuery, attr: ng.IAttributes, ctrl: ng.INgModelController) => {
                    let uniqueId = this.uniqueId,
                        input = preele.find("input"),
                        label = preele.find("label");

                    if (ctrl) {
                        ctrl.$name = ctrl.$name || uniqueId;
                    }

                    label.attr({"for": attr["id"] || uniqueId});

                    if (!scope["label"]) {
                        label.css({"display": "none"});
                    }

                    Object.keys(attr).forEach(function (key) {
                        switch (key) {
                            case "disabled":
                            case "readonly":
                                if (angular.isDefined(attr[key])) {
                                    angular.element(input[0]).attr(key, "true");
                                }
                                break;
                            case "value":
                                break;
                            default:
                                break;
                        }
                    });
                }
            };

        };

    }

    class InputTextController {
        public static $inject = ["$scope"];
        public uniqueId;
        public focused;

        constructor($scope: ng.IScope) {
            this.uniqueId = Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1) + Date.now().toString();

            this.focused = $scope["focused"] === "true" ? true : false;
        }

    }

    angular.module("phxuilib.lcpInputText", ['phxuilib/components/lcpInputText/input-text.html'])
        .directive("lcpInputText", ["$timeout", InputText.instance]);
}

