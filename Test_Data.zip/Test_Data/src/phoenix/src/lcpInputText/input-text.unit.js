'use strict';

describe('Directive: lcpInputText', function() {
    beforeEach(module('phxuilib.lcpInputText'));
    beforeEach(module('phxuilib/components/lcpInputText/input-text.html'));

    var element,
        scope,
        input,
        label,
        labelText = 'First Name',
        inputText = 'Steven';

    beforeEach(inject(function($rootScope, $compile) {
        scope = $rootScope.$new();
        scope.firstName = inputText;

        element = angular.element([
            '<lcp-input-text label="',
            labelText,
            '" readonly disabled class="truncate"',
            'ng-model="firstName"></lcp-input-text>'
        ].join(' '));

        $compile(element)(scope);
        scope.$digest();

        console.log('lcp-inpjut-text: ', element);
        input = element.find('input');
        label = element.find('label');
    }));

    it('should have an input field', function() {
        expect(input.length).toBe(1);
    });

    it('should have a label', function() {
        expect(label.length).toBe(1);
        expect(label.html()).toEqual(labelText);
    });

    it('should have a readonly attribute', function() {
        expect(input.attr('readonly')).toBeTruthy();
    });

    it('should have a disabled attribute', function() {
        expect(input.attr('disabled')).toBeTruthy();
    });

    describe('ngModelController:', function() {
        var ngModel = null;
        beforeEach(function() {
            ngModel = input.controller('ngModel');
        });
        it('should have a value', function() {
            expect(ngModel.$viewValue).toEqual(inputText);
        });
    });
});
