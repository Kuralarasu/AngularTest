/// <reference path="../../../typings/tsd.d.ts" />
/* tslint:disable:no-string-literal */
/**
 * @ngdoc directive
 * @name lcpInputText
 *
 * @description
 *
 * TODO:.....The angular directive will just assign the $error to the formController while not actually stopping the
 * directive from executing any more keypress.
 * This directive is a hack to avoid additional keypress on number specify
 *
 */
var lcpInputText;
(function (lcpInputText) {
    var directive;
    (function (directive) {
        var InputText = (function () {
            function InputText($timeout) {
                var _this = this;
                // public priority = 2;
                this.restrict = "E";
                this.replace = true; // deprecated
                this.require = "?ngModel";
                this.scope = {
                    focused: "@focused",
                    id: "@id",
                    label: "@label",
                    lcpNumbersOnly: "@",
                    maxlength: "@",
                    minlength: "@",
                    name: "@",
                    ngMaxLength: "=ngMaxlength",
                    ngMinLength: "=ngMinlength",
                    ngRequired: "=ngRequired",
                    pattern: "@",
                    required: "@",
                    type: "@",
                    value: "=ngModel"
                };
                this.controller = InputTextController;
                this.controllerAs = "ctrl";
                this.templateUrl = "phxuilib/components/lcpInputText/input-text.html";
                this.compileFunc = function (ele, attrs, transclude) {
                    return {
                        post: function (scope, postele, attr, ctrl) {
                            Object.keys(attr.$attr).forEach(function (key) {
                                if (key !== "class" && key !== "id" && key !== "ngClass" && key !== "disabled" && key !== "readonly") {
                                    postele.removeAttr(attr.$attr[key]);
                                }
                            });
                            var focused = attr["focused"] ? scope.$eval(attr["focused"]) : false, input = postele.find("input");
                            if (focused) {
                                $(input).focus();
                            }
                            // If you have input type=password it wont initialize the input field,
                            // as if it has any data, this will inform the input element, that there is a
                            // value
                            _this._$timeout(function () {
                                if (empty) {
                                }
                                else {
                                    console.log("not this.empty: ", this.empty, typeof this.empty, ele);
                                }
                                if (!empty(scope["value"])) {
                                    input.addClass("ng-not-empty");
                                }
                            }, 0, false);
                            function empty(mixed_var) {
                                var undef, key, i, len;
                                var emptyValues = [undef, null, false, 0, "", "0"];
                                for (i = 0, len = emptyValues.length; i < len; i++) {
                                    if (mixed_var === emptyValues[i]) {
                                        return true;
                                    }
                                }
                                if (typeof mixed_var === "object") {
                                    for (key in mixed_var) {
                                        // TODO: should we check for own properties only?
                                        if (mixed_var.hasOwnProperty(key)) {
                                            return false;
                                        }
                                    }
                                    return true;
                                }
                                return false;
                            }
                            var onFocus = function ($event) {
                                input.val(input.val().replace(/\t+/g, ""));
                            };
                            input.on("focus", onFocus);
                        },
                        pre: function (scope, preele, attr, ctrl) {
                            var uniqueId = _this.uniqueId, input = preele.find("input"), label = preele.find("label");
                            if (ctrl) {
                                ctrl.$name = ctrl.$name || uniqueId;
                            }
                            label.attr({ "for": attr["id"] || uniqueId });
                            if (!scope["label"]) {
                                label.css({ "display": "none" });
                            }
                            Object.keys(attr).forEach(function (key) {
                                switch (key) {
                                    case "disabled":
                                    case "readonly":
                                        if (angular.isDefined(attr[key])) {
                                            angular.element(input[0]).attr(key, "true");
                                        }
                                        break;
                                    case "value":
                                        break;
                                    default:
                                        break;
                                }
                            });
                        }
                    };
                };
                this._$timeout = $timeout;
                this.compile = this.compileFunc;
            }
            InputText.instance = function ($timeout) {
                return new InputText($timeout);
            };
            InputText.$inject = ["$timeout"];
            return InputText;
        }());
        var InputTextController = (function () {
            function InputTextController($scope) {
                this.uniqueId = Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1) + Date.now().toString();
                this.focused = $scope["focused"] === "true" ? true : false;
            }
            InputTextController.$inject = ["$scope"];
            return InputTextController;
        }());
        angular.module("phxuilib.lcpInputText", ['phxuilib/components/lcpInputText/input-text.html'])
            .directive("lcpInputText", ["$timeout", InputText.instance]);
    })(directive = lcpInputText.directive || (lcpInputText.directive = {}));
})(lcpInputText || (lcpInputText = {}));
//# sourceMappingURL=input-text-directive.js.map
