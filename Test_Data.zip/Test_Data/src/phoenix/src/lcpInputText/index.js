/**
 * Created by ramor11 on 10/5/2016.
 */


require('./input-text.html.js');
var module = require('./input-text-directive');
module.exports = module;
