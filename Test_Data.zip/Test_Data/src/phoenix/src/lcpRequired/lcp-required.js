/**
	Usage:
	-------------------------------------------------------
	In order to use lcp-required below are the requirements
	** Form Name  should have been defined
	** field name should have been defined

	Example:
		<form name='myForm'>
			<lcp-input lcp-required minlength='10'  name="firstName"></lcp-input>
		</form>
*/



(function(angular) {
    'use strict';

    angular.module('phx.lcpRequired',[]).directive('lcpRequired', RequiredFormElement);
    RequiredFormElement.$inject = ['$compile', '$timeout']

	function RequiredFormElement($compile, $timeout) {
		var directive = {
			priority: 10, //run first
			restrict: 'A',
			require: ['?ngModel', '^?form']
		};


		directive.link = {
			pre: function (scope, ele, attrs, ctl) {

				//lets not apply if its a lcp-select or lcp-date-picker
				if(  attrs.hasOwnProperty('lcpOptions')){ //  || attrs.hasOwnProperty('lcpDatePicker')
					return;
				}

				attrs.$set('required', 'required');

				if (typeof jQuery === 'undefined') {
					throw ('JQuery is not installed');
					return;
				}



				ctl._validators = ['required'];

				var jEle = $(ele),
					lcpR = jEle.parent().find('.lcpRequired')[0];

		        var input = ele.find("input")[0] ? ele.find("input") : ele,
		           ngModel = input.controller("ngModel");
				input.attr('required', true);

		        var errMsgDvRef  = null;

				input.on("keyup", function (event) {

					angular.forEach(ctl._validators, function(val){
						console.log("lcpRequired.keyup: ", val, ngModel, ctl);
						if( ngModel.$$parentForm.$error.hasOwnProperty(val) ){
							angular.forEach(ngModel.$$parentForm.$error[val], function(_keyRef){
								if( _keyRef.$name == ctl[0].$name ){
									var _t = $(errMsgDvRef).find("[ng-message='"+val+"']");
									_t.css({'opacity':1, 'margin-top':'0px'});
								};
							});

						};
					});


				});

				input.on("keydown", function (event) {

					angular.forEach(ctl._validators, function(val){
						console.log("lcpRequired.keydown: ", val, ngModel, ctl);
						if( ngModel.$$parentForm.$error.hasOwnProperty(val) ){
							angular.forEach(ngModel.$$parentForm.$error[val], function(_keyRef){
								if( _keyRef.$name == ctl[0].$name ){
									var _t = $(errMsgDvRef).find("[ng-message='"+val+"']");
									_t.css({'opacity':1, 'margin-top':'0px'});
								};
							});

						};
					});


				});



				$timeout(function () {

					if (lcpR && ctl[1])return;

					//add the md class to show * for required fields
					jEle.find('label').addClass('md-required');
					var query_1 = ctl[1].$name+"."+ctl[0].$name+".$error || "+ctl[1].$submitted;


					var errMsgContainer =   "<div ng-messages='"+query_1+"' class='errMsgs'> <div ng-message='required'>Required.</div>";
					if( attrs.ngMinlength || attrs.lcpMinlength || attrs.minlength ){
						errMsgContainer += "<div ng-message='minlength'>Field is too short</div>";
						 ctl._validators.push('minlength');
					};

					if( attrs.ngMaxlength || attrs.lcpMaxlength || attrs.maxlength ){
						errMsgContainer += "<div ng-message='maxlength'>Field is too long</div>";
						ctl._validators.push('maxlength');
					};
					errMsgContainer += "</div>";

					//insert after the input field
					jEle.append(errMsgContainer);
					errMsgDvRef = jEle.find('div.errMsgs');

					//lets compile it
					$compile( errMsgDvRef )(scope);
					console.log("lcp-required: ", scope, jEle, errMsgContainer, errMsgDvRef, attrs, ctl, input, ngModel);


				}, 1);

			},
			post: function (scope, ele, attrs, ctl) {

			}
		}


		return directive;
	};


})(window.angular);



