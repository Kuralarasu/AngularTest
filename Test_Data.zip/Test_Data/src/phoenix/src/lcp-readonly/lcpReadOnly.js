/**
 * Created by mallik on 4/26/2016.
 
 Example:  <lcp-readonly placeholder="Name" text="{{ ::ctrl.name }}"></<lcp-readonly>


 */




(function (angular) {
	'use strict';
	angular.module('lcp.readonly.directive', []).directive('lcpReadonly', lcpReadOnly);

	lcpReadOnly.$inject = [];

	function lcpReadOnly() {

		var directive = {
			restrict: 'E',
			scope: {
				label: "@placeholder",
				text: "@text"
			},
			controller: ['$scope', '$element', '$attrs', function ($scope, $element, $attrs) {

			}],
			controllerAs: 'ctrl',
			bindToController: true
		};


		directive.template = [
			'<md-input-container class="md-block md-input-has-value">',
			'<label ng-bind-html="ctrl.label"></label>',
			'<span ng-bind="ctrl.text" class="md-input phxtxt-input" readonly></span>',
			'</md-input-container>'
		].join(' ');


		return directive;
	};

})(window.angular);
