'use strict';


describe('Directive: ngMaxlength ', function() {
    beforeEach(angular.mock.module('phxuilib'));

    var element,
        scope,
        input,
        ngModel;

    beforeEach(inject(function($rootScope, $compile) {
        scope = $rootScope.$new();

        element = angular.element([
            '<div class="form-group">',
            '<input type="text" ng-maxlength="10" ng-model="phoneNumber" />',
            '</div>'
        ].join(' '));

        scope.phoneNumber = '1234567890';

        $compile(element)(scope);

        scope.$digest();
    }));

// TODO 160204 commented out to pass

    /******
     * Make sure some of the basic design still exist
     */
    it('should have a input field', function() {
         input = element.find('input');
         expect(input.length).toBe(1);
    });

    it('should have a 10 chars', function() {
         ngModel = input.controller('ngModel');
         expect(ngModel.$viewValue.length).toBe(10);
    });

    it('should have a 10 chars', function() {
         ngModel = input.controller('ngModel');
         expect(ngModel.$viewValue.length).toBe(10);
    });

    describe('Set viewValue to 11 chars', function() {
         beforeEach(function() {
             ngModel.$setViewValue('12345678901');
         });

         it('expect to be $invalid', function() {
             expect(ngModel.$invalid).toBe(true);

         });
    });
});
