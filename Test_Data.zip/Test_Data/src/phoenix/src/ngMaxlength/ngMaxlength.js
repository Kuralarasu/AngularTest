var maxlength;
(function (maxlength) {
    var directive;
    (function (directive) {
        var Maxlength = (function () {
            function Maxlength() {
                this.priority = 2;
                this.restrict = "A";
                this.require = "?ngModel";
                this.link = this.linkFunc;
            }
            Maxlength.instance = function () {
                return new Maxlength();
            };
            Maxlength.prototype.linkFunc = function (scope, ele, attrs) {
                ele.on("keypress", function (event) {
                    var value = event.target.value, maxLength = Number(attrs.ngMaxlength);
                    if (event.target.selectionStart === 0 && event.target.selectionEnd === maxLength) {
                    }
                    else if (value.length >= maxLength) {
                        if (event.keyCode !== 13) {
                            event.preventDefault();
                        }
                        scope.$apply();
                    }
                });
            };
            return Maxlength;
        }());
        angular.module("phxuilib.ngMaxlength", []).directive("ngMaxlength", Maxlength.instance);
    })(directive = maxlength.directive || (maxlength.directive = {}));
})(maxlength || (maxlength = {}));
//# sourceMappingURL=ngMaxlength.js.map