/// <reference path="../../../typings/tsd.d.ts" />
/**
 * @ngdoc directive
 * @name ngMaxlength
 *
 * @description
 *
 * The angular directive will just assign the $error to the formController while not actually stopping the
 * directive from executing any more keypress.
 * This directive is a hack to avoid additional keypress on number specify
 *
 */

module maxlength.directive {
    class Maxlength implements ng.IDirective {
        public priority = 2;
        public restrict = "A";
        public require = "?ngModel";
        public link: (scope: ng.IScope, ele: ng.IAugmentedJQuery, attrs: ng.IAttributes) => void;

        public static instance(): ng.IDirective {
            return new Maxlength();
        }
        constructor() {
            this.link = this.linkFunc;
        }

        private linkFunc(scope, ele, attrs) {
            ele.on("keypress", function (event) {
                let value = event.target.value,
                    maxLength = Number(attrs.ngMaxlength);

                if (event.target.selectionStart === 0 && event.target.selectionEnd === maxLength) {
                    // DO NOTHING
                    // We reached. this is here for the delay on key events
                } else if (value.length >= maxLength) {
                    if (event.keyCode !== 13) {
                        event.preventDefault();
                    }
                    scope.$apply();
                }

            });
        }

    }

    angular.module("phxuilib.ngMaxlength", []).directive("ngMaxlength", Maxlength.instance);
}





