(function (angular) {
	'use strict';

	angular.module('phx.lcpEscKey', []).directive('lcpEscKey', lcpEscKey);
	lcpEscKey.$inject = []

	function lcpEscKey() {
		var directive = {
			priority: 10,
			restrict: 'A'
		};

		directive.link = {
			post: function (scope, element, attr) {

					$(document).on("keyup", function (event) {
						if (event.which === 27) {
							scope.$apply(function () {
								scope.$eval(attr.lcpEscKey);
							});

							event.preventDefault();
						}
					});
			}
		}

		return directive;
	}

})(window.angular);



