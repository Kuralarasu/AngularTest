/**
 * Created by ramor11 on 10/5/2016.
 */


var module = require('./lcpReadOnly');
module.exports = module;
