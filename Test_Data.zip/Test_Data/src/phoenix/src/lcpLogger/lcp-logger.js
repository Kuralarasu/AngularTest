/**
 * Created by ramor11 on 3/7/2016.
 */
(function (angular) {
	"use strict";

	/**
	 * @ngdoc overview
	 * @name logger.decorator
	 *
	 *
	 * @description
	 *
	 * Event logger is a tool to display logs on production environments,
	 * By added url query debug=true, will display the logs from the instance of that controller, enabled.
	 *
	 * Within the console,
	 * angular.element(document.body).injector().get('Logger').setLoggingEnabled(true);
	 *
	 * Will enable loggind for the entire site.
	 *
	 */

	angular.module('phxuilib.lcpLogger', []).provider('Logger', LoggerProvider);

	/**
	 * @ngdoc service
	 * @name logger.decorator.Logger
	 *
	 * @description
	 * Allows modification of Angular $log features. It is set to display on console while the user is in
	 * development mode, localhost:8080
	 *
	 * ```js
	 *      var logger = $log.getInstance('ControllerName');
	 * ```
	 * Output:
	 *```js
	 *  Friday 2:22:10 pm::[ControllerName]> Message
	 *```
	 *
	 */


	function LoggerProvider() {
		var debug = eval(location.search.split('debug=')[1] || location.hash.split('debug=')[1]);
		this.$get = [
			'$rootScope',
			'version',
			function ($rootScope, version) {
				var $injector = angular.injector(["ng"]),
					$filter = $injector.get('$filter'),
					isProd = version.environment === 'production',
					loggingEnabled = typeof(debug) === 'boolean' ? debug : (typeof(debug) === 'undefined' ? (!isProd ? true : debug) : debug);

				return {
					enhanceAngularLog: function ($log) {
						$log.enabledContexts = [];

						$log.setLoggingEnabled = function (boolean) {
							loggingEnabled = boolean;
						};

						$log.getInstance = function (context) {
							$log.enabledContexts[context] = loggingEnabled;

							return {
								log: enhanceLogging($log.log, context),
								info: enhanceLogging($log.info, context),
								warn: enhanceLogging($log.warn, context),
								debug: enhanceLogging($log.debug, context),
								error: enhanceLogging($log.error, context)
							};
						};

						function enhanceLogging(loggingFunc, context) {
							return function () {
								var contextEnabled = loggingEnabled || $log.enabledContexts[context];
								if (contextEnabled === undefined || contextEnabled) {
									var modifiedArguments = [].slice.call(arguments);
									if (arguments.length === 1 && typeof(arguments[0]) === "object") {
										angular.forEach(
											arguments,
											function (value) {
												this.push(value);
											}, modifiedArguments
										);
									}

									//TODO://workout bug on log output
									//context = [$filter('date')(new Date(), 'medium'), '::[' + context + '] => '].join('');
									modifiedArguments[0] = (typeof(modifiedArguments[0]) === "string" ? modifiedArguments[0] : "");
									loggingFunc.apply(null, modifiedArguments);
								}
							};
						}
					}
				};
			}
		];
	}


})(window.angular);
