/**
 * Created by redroger on 1/21/14.
 */


angular.module("phxuilib.jarvisMenu", []).directive("jarvisMenu", JarvisMenu);

JarvisMenu.$inject = ["$timeout"];


function JarvisMenu($timeout) {

	var directive = {
		restrict: "A",
		scope: {
			opts: "=?jarvisMenu"
		},
		link: linkFun
	};

	function linkFun(scope, element, attr) {

		if (typeof jQuery === "undefined" && jQuery === null) {
			throw new DOMException("Missing JQuery");
		}

		var el = $(element),
			defaults = {
				accordion: true,
				speed: 200,
				closedSign: '[+]',
				openedSign: '[-]'
			};

		// Extend our default options with those provided.
		if (typeof(scope.opts) != "undefined" && typeof(scope.opts) != "undefined") {
			defaults = angular.extend({}, defaults, scope.opts)
		}


		function update(direction, html, callback) {
			var dir = direction ? '$slidedown' : '$slideup';

			this.find("b:first").delay(defaults.speed).html(html);
			this[direction ? 'removeClass' : 'addClass']("open");

			if (this[0])this[0].__proto__[dir] = function (cb) {
				var _this = $(this), called = _this.data('jm'),
					ul = _this.find("ul");

				if (called)return;
				_this.data('jm', true);

				if (ul.size() != 0)eval(dir)(ul, function () {
					_this.data('jm', false);
					cb.apply(_this);
				})

			};

			if (typeof callback === 'function')callback.apply(this);
			scope.$emit("directive:jarvisMenu", {element: this, class: direction})
		}


		function $slideup(ele, callback) {
			ele.slideUp(defaults.speed, function () {
				var _this = $(this).parent("li");
				update.apply(_this, [true, defaults.closedSign, callback]);
			});
		}


		function $slidedown(ele, callback) {
			ele.slideDown(defaults.speed, function () {
				var _this = $(this).parent("li");
				update.apply(_this, [false, defaults.openedSign, callback]);
			});
		}


		//add a mark [+] to a multilevel menu
		el.find("li").each(function () {
			if ($(this).find("ul").size() != 0) {
				$(this).addClass("jarvis-menu");
				//add the multilevel sign next to the link
				$(this).find("a:first").append("<b class='collapse-sign'>" + defaults.closedSign + "</b>");

				//avoid jumping to the top of the page when the href is an #
				if ($(this).find("a:first").attr('href') === "#") {
					$(this).find("a:first").click(function (e) {
						event.preventDefault();
						event.stopPropagation();
					});
				}
			}
		});

		$timeout(function(){
			//open active level
			el.find("li.active").each(function () {
				$slidedown($(this).parents("ul"));
			});
		},600);

		el.find("li a").on('click', function () {
			//remove all active element
			//$(this).parents().find("li").removeClass('active')

			if ($(this).parent().find("ul").size() != 0) {
				var parent = $(this).parent(),
					ul = parent.find("ul"),
					first = parent.find('ul:first');


				if (defaults.accordion && !ul.is(':visible')) {
					var parents = $(this).parent().parents("ul"),
						visible = el.find("ul:visible");

					visible.each(function (visibleIndex) {
						var close = true;
						parents.each(function (parentIndex) {
							if (parents[parentIndex] == visible[visibleIndex]) {
								close = false;
								return false;
							}
						});
						if (close && ul !== visible[visibleIndex]) {
							$slideup($(visible[visibleIndex]));
						}
					});
				} // end if
				if (first.is(":visible") && !first.hasClass("active")) {
					$slideup(first, function () {
						$(this).parent("li").removeClass("active")
					});
				} else {
					$slidedown(first, function () {
						$(this).parent("li").addClass("active")
					});
				}
			} else {
				$(this).parent().addClass('active')
			}

		})


	}


	return directive;
};
