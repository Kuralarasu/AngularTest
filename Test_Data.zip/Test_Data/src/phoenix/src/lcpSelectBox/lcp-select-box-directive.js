/**
 * @ngdoc directive
 * @name lcpSelectbox
 *
 * @description
 * It will automatically create the elements needed to create a custom dropdown base on LabCorp Style Guide.
 * The lcpSelectbox directive allows you to specify custom behaviour when element is clicked.
 *
 * It will accept numerous different element set as attributes or objects.
 *
 *
 * @element EA
 *
 *
 * @params {expression} lcpSelectbox {@link object/expression} to evaluates options upon
 *
 * lcpSelectbox additional accepted attributes.
 * @params {class, name, label, id, placeholder, options, selected} Insert the class on parent container
 *
 * @example
 <example>
 <file name="controller.js">
 ```js
 $scope.lcpSelectboxOpts = {
        placeholder: 'Service Types',
        options: self.ServiceType, //it can be an array of strings, or array of objects {name:'string', value: 'string', selected:'{optional:boolean}'}
        selected: 30, //set the default value, if its a boolean it will be empty
        name: "serviceTypes",
        id: "serviceTypes",
        map:{name:name,value:value} //if the options object needs to map to a different parameters for name and value name => onotherName, value => anotherValue
        column:1; //its a class referent of the column, default is 3, where it will add the class associated
        search:true, //allow filtering default true
        //Will be trigger on drop down selected
        onSelected: function () {
            //callback function to perform other stuff,
            //returns arguments
            //self.verifyEntry.serviceTypeId = arguments[0].value;
        }
     }
 ```
 </file>


 <file name="index.html">
 ```html

 <div lcp-select-box="ctrl.serviceTypesOpts" ng-model="ctrl.verifyEntry.serviceTypeId"></div>

 //to disable the scroll feature
 <div lcp-select-box="ctrl.serviceTypesOpts" ng-model="ctrl.verifyEntry.serviceTypeId" scroll=false></div>


 //Either options will load the necessary variables into lcpSelectbox directive

 <div lcp-select-box id="serviceTypes" name="serviceTypes" options="ctrl.ServiceType" placeholder="Service Types"
 ng-model="ctrl.verifyEntry.serviceType"></div>

 ```
 </file>
 </example>
 *
 * A collection of attributes that allows creation of custom event handlers that are defined as
 * angular expressions and are compiled and executed within the current scope.
 *
 */



(function(angular) {
    'use strict';

    angular.module('phxuilib.lcpSelectBox',['phxuilib/components/lcpSelectBox/lcpDropdown.html'])
        .directive('lcpSelectBox', SelectBox);

    function strcasecmp(f_string1, f_string2) {
        var string1 = String(f_string1 + '').toLowerCase();
        var string2 = String(f_string2 + '').toLowerCase();
        if (string1 > string2) {
            return 1;
        } else if (string1 === string2) {
            return 0;
        }
        return -1;
    }

    function getObjData(obj, string) {
        if (typeof obj === 'undefined') return '';
        var jsonParts = string.trim().split('.'),
            result = '';
        if (jsonParts.length > 0 && obj.hasOwnProperty(jsonParts[0])) {
            result = obj[jsonParts[0]];
            jsonParts.splice(0, 1);
            if (jsonParts.length > 0)
                result = getObjData(result, jsonParts.join('.'));
        }
        return result;
    }

    SelectBox.$inject = ['$compile', '$animate', '$document', '$templateCache', '$window', '$log', '$timeout'];
    function SelectBox($compile, $animate, $document, $templateCache, $window, $log, $timeout) {
        var directive = {
            restrict: 'A', /*It can be either one, if its an attribute it is expected to have an object for its parameters */
            priority: 0,
            require: 'ngModel',
            scope: {
                options: '=*?', //an array of items to pass into the select drop downs
                selected: '=ngModel',
                opts: '=*lcpSelectBox', //if this object exist, it will override the existing attributes in the element
                required: '@?'
            },
            controller: ['$scope', function($scope) {
                var self = this, selectedObject = null, onSelectionClick = false;

                self.inputValue = {name: '', value: ''};
                //controller the status of drop down
                self.open = false;
                //resolve any pending selections
                self.pending = null;
                //reset flag used by arrow keyup/keydown handlers
                self.arrowKeyPressed = false;
                //timeout to allow a click inside the menu to cancel the input"s blur handler:
                self.blurTimeoutFlag = null;
                //blur timeout (ms):
                self.blurTimeoutMs = 200;
                //flag to indicate the INPUT was focused after a selection was made:
                self.focusedAfterSelection = false;
                //flag to prevent closing the menu in IE when clicking on the menu (specifically the scroll bar):
                self.menuIsActive = false;
                /**
                 * Build the options set from directive attribute
                 * @param ctrl
                 * @param attr
                 * @returns {*}
                 */
                var options = angular.extend({}, {
                    map: {name: 'name', value: 'value'},
                    id: Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1) + Date.now().toString(),
                    column: 1,
                    options: angular.copy(self.options) || getObjData(self.opts, 'options') || [], //set the options to reset
                }, angular.copy(self.opts) || {});

                self.options = [];

                self.opts = options;
                //lets watch for changes
                var onWatchItems = $scope.$watchGroup([function() {
                    return self.opts.options;
                }, 'options', function() {
                    return self.selected;
                }], function(opts) {

                    var options = opts[0] || opts[1];

                    if (!options || !options.length)return;
                    buildSelectOpts(options);
                }.bind(self));

                $scope.$watchCollection(function() {
                    return self.selected;
                }, function(newValue, oldValue) {
                    if (strcasecmp(newValue, oldValue) !== 0) {
                        var obj = getValueObj(self.options, newValue);
                        self.setModel(obj);
                        onSelectionClick = false;
                    }
                }).bind(self);

                self.onSelection = function(event, obj) {
                    event.preventDefault();
                    event.stopPropagation();

                    delete self.inputValue.selected;
                    self.setModel(obj);
                    //if there is a callback
                    if (self.opts.onSelected) {
                        self.opts.onSelected.apply(self, [obj]);
                    }
                };

                function getValueObj(obj, value) {
                    for (var i in obj) {
                        if (obj[i] && strcasecmp(obj[i].value, value) === 0) {
                            return obj[i];
                        }
                    }
                    return false;
                }

                self.setModel = function(obj, remain_open) {
                    onSelectionClick = true;
                    //This is to avoid the watch from calling the build again on change
                    selectedObject = obj;
                    for (var i in self.options) {
                        delete self.options[i].selected;
                        if (obj.name) {
                            if (obj && strcasecmp(obj.value, self.options[i].value) === 0 && !obj.selected) {
                                obj.selected = true;
                                self.options[i].selected = true;
                                self.inputValue = angular.copy(obj);
                                self.selected = obj.value;
                            }
                            onWatchItems(); //kill this watch no longer needed
                        } else {
                            self.selected = '';
                            self.inputValue = {};
                        }
                    }
                    if (typeof remain_open === 'undefined') {
                        self.focused = false;
                        self.open = false;
                    }

                    self.pending = null;
                };
                /**
                 * Function that takes the object and builds the UL.LI from the object
                 * Must have the following keys
                 * @param obj - {name:"", value:""}
                 */
                function buildSelectOpts(objs) {
                    if (!(self.opts).hasOwnProperty('map')) {
                        return;
                    }

                    //Store the options to pass
                    self.options = [];
                    if (!objs)return; //if this does not exist we are not building nothing

                    var arr = angular.isArray(objs) ? objs : [objs];
                    angular.forEach(arr, function(obj) {
                        if (!obj.hasOwnProperty('value') && typeof obj === 'string') {
                            obj = {
                                name: String(obj).trim(),
                                value: String(obj).trim()
                            };
                        } else if (!obj.hasOwnProperty('value') || !obj.hasOwnProperty('name')) {
                            //if the object is an object but does not contain name, value
                            obj = {
                                name: String(obj[self.opts.map['name']]).trim(),
                                value: String(obj[self.opts.map['value']]).trim()
                            };
                        }
                        if (!selectedObject && obj.selected) {
                            selectedObject = obj;
                        }

                        if (String(self.selected) === obj.value) {
                            selectedObject = obj;
                        }

                        self.options.push(obj);
                    });

                    if (selectedObject) {
                        self.setModel(selectedObject);
                    }
                }

                self.onKeyDown = function($event) {
                    // If the menu is open and the Esc key is pressed, close the dropdown:
                    if ($event.keyCode === 27 && self.open) {
                        self.open = false;
                        return;
                    }

                    // Up arrow:
                    if ($event.keyCode === 38) {
                        // If the menu is closed, do not open it (and don"t preventDefault):
                        if (!self.open) {
                            return;
                        }
                        $event.preventDefault();
                        // Select the pending item (from search) or selectedObject:
                        var currentItem = self.pending || selectedObject;
                        // If the first item is already selected,
                        // or there is no selected item, close the selectBox:
                        if (angular.isDefined(self.options[0].selected) || !currentItem) {
                            self.open = false;
                            self.arrowKeyPressed = false;
                        } else {
                            // Otherwise, select the previous item:
                            delete self.options[self.options.indexOf(currentItem)].selected;
                            var newSelected = self.options[self.options.indexOf(currentItem) - 1];
                            newSelected.selected = true;
                            self.pending = newSelected;
                            self.open = true;
                            self.arrowKeyPressed = true;
                        }
                    }

                    // Down arrow:
                    if ($event.keyCode === 40) {
                        $event.preventDefault();
                        // If the dropdown is closed, open it and return:
                        if (!self.open) {
                            self.open = true;
                            return;
                        }
                        // Select the pending item (e.g., set by the filter) or selectedObject:
                        var currentItem = self.pending || selectedObject;
                        // If no item is selected:
                        // * if there is a pending item, select next item
                        // * otherwise select the first item
                        if ((!currentItem || !currentItem.value) || !self.inputValue.value) {
                            var itemIndex = 0;
                            if (self.pending && self.pending.selected) {
                                var pendingIndex = self.options.indexOf(self.pending);
                                delete self.options[pendingIndex].selected;
                                itemIndex = pendingIndex + 1;
                            }
                            self.options[itemIndex].selected = true;
                            self.pending = self.options[itemIndex];
                            self.arrowKeyPressed = true;
                        } else if (angular.isDefined(self.options[self.options.length - 1].selected)) {
                            // If the last item is already selected, do nothing:
                            self.arrowKeyPressed = false;
                            return;
                        } else {
                            // Otherwise, select the next item:
                            delete self.options[self.options.indexOf(currentItem)].selected;
                            var newSelected = self.options[self.options.indexOf(currentItem) + 1];
                            newSelected.selected = true;
                            self.pending = newSelected;
                            self.arrowKeyPressed = true;
                        }
                    }
                };

                var searchTimeout;
                self.onKeyUp = function($event) {
                    if (self.opts.search) {
                        searchTimeout = $timeout(function() {
                            if (isFunction(self.opts.search)) {
                                self.opts.search(self.inputValue);
                            }
                        }, 500);
                    }
                };

                function isFunction(o) {
                    //var getClass = {}.toString();
                    //return o && getClass.call(o) == "[object Function]";
                    return typeof (o) === 'function';
                }

            }],
            controllerAs: 'ctrl',
            bindToController: true,
            templateUrl: 'phxuilib/components/lcpSelectBox/lcpDropdown.html',
            replace: true
        };

        /**
         * Get the position of the element
         * @param ele
         * @returns {{top: number, left: number}}
         */
        function getPosition(ele) {
            var rect = null;
            try {
                rect = ele.getBoundingClientRect();

            } catch (e) {
                rect = ele[0].getBoundingClientRect();
            }

            var rectTop = rect.top + window.pageYOffset - document.documentElement.clientTop;
            var rectLeft = rect.left + window.pageXOffset - document.documentElement.clientLeft;

            return {top: rectTop, left: rectLeft};
        }

        directive.link = {
            pre: function(scope, ele, attr, ctrl) {

                var options = angular.extend({}, angular.copy(scope.ctrl.opts) || {}, {
                    placeholder: attr.placeholder || (scope.ctrl.opts) ? scope.ctrl.opts.placeholder : "",
                    id: attr.id ||  (scope.ctrl.opts) ? scope.ctrl.opts.id : undefined
                });
                //override the new values
                ctrl.opts = options;

            },
            post: function(scope, ele, attr, ctrl) {
                var $parent = angular.element($document[0].querySelector('body')),
                    opts = ctrl.opts,
                    ulElement = angular.element($templateCache.get('phxuilib/components/lcpSelectBox/lcpDropdown_ul.html')),
                    trigger = ele.find('a').on('click', onTrigger),
                    input = $(ele.find('input')),
                    disable = false;

                if (angular.isDefined(opts.placeholder)) {
                    ele.find('label').html(opts.placeholder).attr({for: opts.id});
                }

                Object.keys(attr).forEach(function(key) {
                    switch (key) {
                        case 'disabled':
                            if (scope.$eval(attr.disabled)) {
                                input.attr('disabled', true);
                                trigger.attr('disabled', true);
                                disable = true;
                            }

                            break;
                        case 'readonly':
                            if (scope.$eval(attr.readonly)) {
                                input.attr('readonly', true);
                                trigger.attr('readonly', true);
                                disable = true;

                            }
                            break;
                        default :
                            break;
                    }
                });

                if (!disable) {
                    input.on('focus', onFocus)
                        .on('blur', onBlurFunc)
                        .on('keypress keydown', onKeyPressFunc)
                        .on('keyup', onKeyUpPress);

                    //this is to append the element to the body and not to the element
                    //this will allow for the dropdown to be visible within overscroll
                    //element
                    ulElement.attr({'data-dropdown-target': opts.id})
                        .css({visibility: 'hidden'})
                        .on('mouseenter mouseleave', onMouseEnterLeave);
                    angular.element($window).on('resize', documentClickBind);

                    $compile(ulElement)(scope);
                }

                //remove these from the element we don"t need them there
                Object.keys(attr.$attr).forEach(function(key) {
                    if (key !== 'class' && key !== 'id' && key !== 'ngClass')
                        ele.removeAttr(attr.$attr[key]);
                });

                Object.keys(attr).forEach(function(key) {
                    switch (key) {
                        case 'disabled':
                            input.attr('disabled', true);
                            break;
                        default :
                            break;
                    }
                });


                function onKeyUpPress(event) {
                    // If there is a pending selection set by the Up/Down arrow keys, do nothing:
                    if (ctrl.arrowKeyPressed) {
                        return;
                    }

                    var string = event.target.value;

                    var obj = ctrl.options,
                        input = string ? string.replace(/ /g, '').toLowerCase() : null,
                        handler = [], selected = {};
                    for (var i in obj) {
                        var value = String(obj[i].value).replace(/ /g, '').toLowerCase(),
                            name = String(obj[i].name).replace(/ /g, '').toLowerCase(),
                            isName = name.indexOf(input) !== -1 ? true : false,
                            isValue = value.indexOf(input) !== -1 ? true : false;

                        delete obj[i].selected;

                        if (input) {
                            if (isName || isValue) {
                                handler.push(obj[i]);
                                if (strcasecmp(input, value) === 0 || strcasecmp(input, name) === 0 || handler.length === 1)
                                    selected = obj[i];
                            }
                        }
                    }
                    if (handler[0]) {
                        handler[0].selected = true;
                    }

                    ctrl.pending = selected;
                    return obj;
                }

                function onKeyPressFunc(event) {
                    event.keyCode = event.charCode || event.keyCode;
                    if (event.keyCode === 13)event.preventDefault();
                    //set model if Enter key
                    if (ctrl.pending && event.keyCode === 13) {
                        ctrl.setModel(ctrl.pending);
                        return;
                    }
                    var menu = ulElement[0].querySelector('.lcpSelectMenu'); // the scrolling container
                    var item = menu.querySelector('.active'); // the selected (or pending) item
                    if (ctrl.open && item) {
                        var itemIsVisible = item.offsetTop > menu.scrollTop && item.offsetTop + item.offsetHeight < menu.scrollTop + menu.offsetHeight;
                        if (!itemIsVisible) {
                            // Scroll the menu so the item is visible:
                            item.scrollIntoView();
                        }
                    }
                }

                /**
                 * Function to set the widths of the columns
                 * bases on the passed options
                 */
                function setColumnsWidth() {
                    if (opts.column || opts.column !== 1) {
                        var listItems = ulElement ? ulElement[0].querySelectorAll('li') : [];
                        if (!listItems.length) {
                            return;
                        }

                        var splits = ulElement.data('size') / 2,
                            eleWidth = (splits >= 100 ? splits : 100) * opts.column;

                        ulElement.css({'min-width': eleWidth + 'px'});
                        angular.forEach(listItems, function(item) {
                            var ele = angular.element(item);
                            ele.css({width: Number(100 / opts.column) + '%', float: 'left'});
                        });
                    }

                    setPosition();
                }

                function setPosition() {
                    var position = getPosition(ele),
                        topPos = Number(position.top + ele[0].clientHeight),
                        wH = window.innerHeight,
                        uList = ulElement.find('ul');

                    $timeout(function() {
                        if (uList[0].offsetHeight > ulElement[0].offsetHeight) {
                            if (scope.$eval(attr.scroll) === false) {
                                uList.parent().css({'min-height': uList[0].offsetHeight + 'px'});
                                ulElement.removeClass('scroll-enable');
                            } else {
                                ulElement.addClass('scroll-enable');
                            }
                        }

                        if ((topPos + ulElement.data('size').height + 20) >= wH) {
                            topPos = topPos - ulElement.data('size').height - input[0].offsetHeight - 15;
                            ulElement.addClass('arrow-down');
                        } else {
                            ulElement.removeClass('arrow-down');
                        }
                        ulElement.css({
                            top: topPos + 'px',
                            left: position.left + 'px',
                            width: ele[0].offsetWidth + 'px',
                            visibility: position.left === 0 && topPos === 0 ? 'hidden' : 'visible'
                        });
                    }, 0, false);
                }

                function setHeights() {
                    $timeout(function() {
                        ulElement.css({display: 'block', top: '-9999px', left: '-9999px'});
                        ulElement.data('size', {
                            height: ulElement[0].offsetHeight,
                            width: ulElement[0].clientWidth
                        });
                        ulElement.css({display: '', top: '-9999px', left: '-9999px', visibility: 'hidden'});

                        setColumnsWidth();
                    }, 0, false);
                }

                function onTrigger(event) {
                    event.preventDefault();
                    $timeout.cancel(ctrl.blurTimeoutFlag);
                    if (!ctrl.open) {
                        ctrl.focusedAfterSelection = false;
                        input[0].focus();
                    } else {
                        dropUI();
                    }
                }

                function onFocus($event) {
                    $event.preventDefault();
                    if (ctrl.focusedAfterSelection || ctrl.menuIsActive) {
                        if (ctrl.menuIsActive) {
                            $timeout.cancel(ctrl.blurTimeoutFlag);
                            ctrl.menuIsActive = false;
                        } else {
                            ctrl.focusedAfterSelection = false;
                            ctrl.focused = true;
                            ctrl.open = false;
                            scope.$digest();
                        }
                    } else if (!ctrl.open) {
                        setStatus(true);
                        setHeights();
                        $timeout(function() {
                            $animate.enter(ulElement, $parent, angular.element($parent[0].lastChild));
                        }, 0, false);
                        var selectedItem = ulElement[0].querySelector('.active');
                        if (selectedItem) {
                            selectedItem.scrollIntoView(false);
                        }
                        $document.on('click mouseup', documentClickBind);
                    } else {
                        dropUI();
                    }
                }

                function onMouseEnterLeave() {
                    ulElement.toggleClass('dropdown-menu-hover');
                }

                function documentClickBind($event) {
                    $event.preventDefault();
                    var target = $event.target;
                    //ctrl.menuIsActive = $event.currentTarget.activeElement.classList.contains("lcpSelectMenu");
                    ctrl.menuIsActive = ulElement.hasClass('dropdown-menu-hover');
                    if (ctrl.menuIsActive) {
                        $timeout.cancel(ctrl.blurTimeoutFlag);
                    }
                    var clickedOutsideElement = !$(ele.parent()).is(target) && $(ele.parent()).has(target).length === 0;
                    var clickedInMenu = $(ulElement).has(target).length > 0;
                    if (clickedInMenu || ctrl.menuIsActive) {
                        $timeout.cancel(ctrl.blurTimeoutFlag);
                        ctrl.focusedAfterSelection = true;
                        input[0].focus();
                    } else if (clickedOutsideElement) {
                        dropUI();
                    }
                }

                function dropUI() {
                    if (ctrl.menuIsActive) {
                        return;
                    }
                    ulElement.css({visibility: 'hidden'});
                    $document.unbind('click mouseup', documentClickBind);
                    setStatus(false);
                }

                function setStatus(boolean) {
                    ctrl.focused = boolean;
                    ctrl.open = boolean;
                    scope.$digest();
                }

                function onBlurFunc($event) {
                    $event.stopPropagation();
                    if (ctrl.pending) {
                        ctrl.setModel(ctrl.pending);
                    }
                    ctrl.arrowKeyPressed = false;
                    ctrl.blurTimeoutFlag = $timeout(function() {
                        if (ulElement.css('visibility') !== 'hidden') {
                            $timeout(dropUI, 0, false);
                        }
                    }, ctrl.blurTimeoutMs);
                }

                /**
                 * Destroy, so we wont keep bubbling up on document body
                 */
                scope.$on('$destroy', function() {
                    var opts = scope.ctrl.opts,
                        ulElement = angular.element($document[0].querySelector("[data-dropdown-target='" + opts.id + "']"));

                    ulElement.off('mouseenter mouseleave').remove();
                    $document.unbind('click mouseup', documentClickBind);
                    ele.find('a').unbind('click', onTrigger);
                    $timeout.cancel(ctrl.blurTimeoutFlag);

                    //unbind a couple things
                    input.unbind('focus', onFocus).unbind('blur', onBlurFunc).unbind('keypress keydown', onKeyPressFunc).unbind('keyup', onKeyUpPress);
                    angular.element($window).unbind('resize', documentClickBind);
                });
            }
        };

        return directive;
    }
})(window.angular);
