angular.module("phxuilib/components/lcpSelectBox/lcpDropdown_ul.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("phxuilib/components/lcpSelectBox/lcpDropdown_ul.html",
    "<div class=\"dropdown-menu\" style=\"padding: 0\" ng-class=\"{'show':ctrl.open}\"><div class=\"lcpSelectMenu\"><ul><li data-ng-repeat=\"options in ctrl.options track by $index\" ng-class=\"{'active':options.selected}\" data-value=\"{{options.value}}\"><a class=\"truncate\" title=\"{{options.name}}\" ng-click=\"ctrl.onSelection($event, options)\" ng-bind=\"options.name\"></a></li></ul></div></div>");
}]);
