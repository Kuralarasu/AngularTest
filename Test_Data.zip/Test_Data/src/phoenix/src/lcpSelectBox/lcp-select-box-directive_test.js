'use strict';


describe('Directive: lcpSelectBox ', function() {
    beforeEach(module('phxuilib.lcpSelectBox'));
    beforeEach(module('phxuilib/components/lcpSelectBox/lcpDropdown.html'));

    var ServiceType = [
            {name: 'Health Benefit Plan Coverage', value: 30, selected: true},
            {name: 'Diagnostic Lab', value: 5},
            {name: 'Blood Charges', value: 10},
            {name: 'Diagnostic Medical', value: 73},
            {name: 'Screening Laboratory', value: 'CL'}
        ],
        element, scope, trigger, input,
        serviceTypeCode = 30,
        serviceTypesOpts = {
            placeholder: 'Service Types',
            options: ServiceType,
            column: 2,
            name: 'serviceTypes',
            id: 'serviceTypes'
        },
        eventMock = {
            preventDefault: angular.noop,
            stopPropagation: angular.noop
        };

    beforeEach(inject(function($rootScope, $compile, $injector) {
        scope = $rootScope.$new();

        element = angular.element([
            '<div class="form-group">',
            '<div lcp-select-box="serviceTypesOpts" ng-model="serviceTypeCode"></div>',
            '</div>'
        ].join(' '));

        //element.appendTo(document.body);
        //angular.element(document.body).append(element);

        scope.serviceTypeCode = serviceTypeCode;
        scope.serviceTypesOpts = serviceTypesOpts;

        $compile(element)(scope);

        scope.$digest();
    }));

    afterEach(function() {
        element.remove();
    });

    /******
     * Make sure some of the basic design still exist
     */
    it('should have a input field', function() {
        input = element.find('input');
        expect(input.length).toBe(1);
    });

    it('should have a trigger', function() {
        trigger = element.find('a');
        expect(trigger.hasClass('trigger')).toBe(true);
        expect(trigger.length).toBe(1);
    });

    it('should have a label', function() {
        var label = element.find('label');
        expect(label.length).toBe(1);
        expect(label.html()).toEqual(serviceTypesOpts.placeholder);
    });

    describe('clicks the trigger ', function() {
        beforeEach(function() {
            spyOnEvent(trigger, 'click');
        });

        it('expect to have been triggered', function() {
            trigger[0].click();
            expect('click').toHaveBeenTriggeredOn(trigger);
        });

        describe('clicks an item', function() {
            it('expect the input to be populated', function() {
                var ctrl = scope.$$childHead.ctrl;
                ctrl.onSelection(eventMock, ServiceType[0]); // called when clicking a menu item
                expect(input.val()).toEqual(ServiceType[0].name);
            });
        });
    });
});
