/**
 * Created by ramor11 on 10/5/2016.
 */

require('./lcpDropdown.html.js');
require('./lcpDropdown_ul.html.js');

var module = require('./lcp-select-box-directive');
module.exports = module;
