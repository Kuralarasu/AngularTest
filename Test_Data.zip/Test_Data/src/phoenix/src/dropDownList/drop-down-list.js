/**
 * Created by redroger on 6/2/2015.
 *
 *        self.faThOpts = [
 [{
 			//offsetTop: -20,//This can be added as attributes on the dom element, attributes takes priority
			//offsetRight: 10,//This can be added as attributes on the dom element, attributes takes priority
			//multiSelect: true,//This can be added as attributes on the dom element, attributes takes priority
			//position: 'left',
				name: 'Poster',
				icon: 'fa fa-th-large',
				callback: function () {
				}
			}],
 [{
				name: 'Details',
				icon: "fa fa-th-list",
				callback: function () {
				}
			}],
 [{
				name: 'List',
				icon: "fa fa-list",
				callback: function () {
				}
			}]
 ]

 */


(function (angular) {
	"use strict";


	angular.module('lcp.dropDownList.directive', ['lcp.unorderedList.factory']).directive('dropDownList', DropDownOptions)

	DropDownOptions.$inject = ['$compile', '$document', 'lcpUnorderedList.factory'];

	function DropDownOptions($compile, $document, UnorderedList) {

		var directive = {
			restrict: 'AEC',
			scope: {
				ops: "=dropDownList"
			},
			link: linkFunc
		};


		function linkFunc(scope, ele, attr, ctrl) {


			var cmElement = angular.element('<div class="bg-drop-downs-list"></div>'),
				uListObj = null;

			ele.unbind('click').on('click', onClick);

			function onClick(e) {


				if (cmElement.data('onClick'))return;
				cmElement.$destroy = destroy;

				uListObj = new UnorderedList(ele, scope.ops);
				uListObj.show(cmElement, scope);

				//append to body
				angular.element($document[0].querySelector('body')).append(cmElement[0]);


				return false;
			}

			function destroy() {
				if (uListObj) {
					uListObj.remove();
					uListObj = null;
				}
			}


			scope.$on('$destroy', function () {
				destroy();
				cmElement.remove();
				ele.unbind('click', onClick);
			});

		}

		return directive;

	}


})(window.angular);
