/**
 * Created by Ramor11 on 1/12/2016.
 *
 * Future use of DOOM (Document Object Oriented Models)
 */


(function (angular) {
	'use strict';

	angular.module('lcp.unorderedList.factory', [])
		.run(["$templateCache", function ($templateCache) {
			$templateCache.put(
				'/unordered-list/unordered-list.tpl.html',
				[
					'<div class="dropdown-buttons md-whiteframe-1dp"><ul data-ng-repeat="ul in ctrl.ulList"><li data-ng-repeat="li in ul" class="{{::li.class}}">',
					'<div data-ng-click="ctrl.callback(ctrl.$$model || $event, li, ul, ctrl.ulList);ctrl.forceClose($event);" ',
					'ng-class="{\'active\':li.selected}"><span class="ul-icon" ng-bind-html="::li.icon"></span><span ng-bind-html="::li.name"></span>',
					'<i class="material-icons pull-right" style="margin-top: 8px;" data-ng-show="li.list">chevron_right</i>',
					'</div>',
					'<ul data-ng-show="li.list"><li data-ng-repeat="subli in li.list">',
					'<div data-ng-click="ctrl.callback(ctrl.$$model || $event,subli, li, ctrl.ulList)" ',
					'ng-class="{\'active\':subli.selected}"><span class="ul-icon" ng-bind-html="::subli.icon"></span>span ng-bind-html="::subli.name"></span></div>',
					'</li></ul>',
					'</li></ul></div>'
				].join(''))
		}])
		.factory('lcpUnorderedList.factory', UnorderedListFactory)
		.directive('lcpUnorderedList', UnorderedListDirective)

	UnorderedListFactory.$inject = ['$compile', '$animate'];
	UnorderedListDirective.$inject = ['$window', '$document', '$rootScope'];


	function UnorderedListDirective($window, $document, $rootScope) {

		var directive = {
			restrict: 'E',
			controller: [angular.noop],
			controllerAs: 'ctrl',
			bindToController: true,
			replace: true,
			templateUrl: '/unordered-list/unordered-list.tpl.html',
			link: {
				pre: function (scope, ele, attr, ctrl) {
					ele.attr('id', Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1) + Date.now().toString());
					var data = ele.data('lcpUnorderedList');
					Object.keys(data).forEach(function (key) {
						ctrl[key] = data[key];
					});


					var opts = !angular.isArray(ctrl.ulList[0]) ? [ctrl.ulList] : ctrl.ulList,
						ulList = [];
					angular.forEach(opts, function (obj) {
						if (obj.length)
							this.push(obj)

					}, ulList);
					ctrl.ulList = ulList;

					ctrl.callback = function (model, obj, ul, theadOpts) {
						angular.forEach(ul, function (o) {
							var bool = angular.equals(o, obj);
							o.selected = bool ? !o.selected : bool;
						});

						obj.callback.apply(obj, [model, ul, theadOpts])

						$rootScope.$broadcast('ngClick.unordered.list.directive', [model, obj, ul, theadOpts])

					}

				},
				post: linkFunc
			}
		};

		function toPix(v) {
			return v.toFixed(3) + 'px';
		}

		function getPosition(ele) {
			var rect = null;
			try {
				rect = ele.getBoundingClientRect();
			} catch (e) {
				rect = ele[0].getBoundingClientRect();
			}


			var rT = rect.top + $window.pageYOffset - $document[0].documentElement.clientTop,
				rL = rect.left + $window.pageXOffset - $document[0].documentElement.clientLeft;

			return {top: rT, left: rL};
		}

		function linkFunc(scope, ele, attr, ctrl) {
			var clssLst = ['dd-right-pos', 'dd-left-pos'],
				attLst = ['direction', 'offset', 'templateUrl'];

			ele['_addClass'] = function (clss) {
				this.removeClass(clss === clssLst[0] ? clssLst[1] : clssLst[0]);
				this.addClass(clss);
			};

			var t = ctrl.$$parent[0] || ctrl.$$parent,
				attr = attLst.forEach(function (val, i) {
					var value = function (s) {
							var val = s.replace(/([A-Z])/g, function ($1) {
									return "-" + $1.toLowerCase();
								}),
								data = ['data', val].join('-');
							return [data, val];
						}(val),
						res = function (num) {
							return !isNaN(num) ? Number(num) : num;
						}(String(t.getAttribute(value.filter(function (val) {
							return t.getAttribute(val);
						})[0])).trim());
					attLst[i] = res === "null" ? false : res;
					return attLst;
				}),
				elePos = getPosition(t),
				wW = window.innerWidth, //window width
				pW = t.clientWidth,  //the click target
				pH = t.clientHeight, //the click target
				ulW = ele[0].clientWidth + 1 /* border */,
				isOut = attLst[0] === 'left' || elePos.left + ulW > wW,
				leftPosition = function () {
					ele['_addClass'].apply(ele, [clssLst[isOut ? 0 : 1]]);
					(ctrl.$$parent).data('isOpen', true);

					var offset = (14 /*position of the arrow*/ - ((pW - 16/* width of arrow + offset of arrow indentation*/) / 2)),
						result = isOut ? (wW - (wW - elePos.left + ulW) + pW) + offset : elePos.left - offset;
					if (attLst[1])
						result += attLst[1];
					return result
				};


			if ((wW - leftPosition() - ulW) < ulW) {
				ele.addClass('dd-pull-left')
			}


			ele.css({
				position: 'absolute',
				top: toPix(elePos.top + (pH + 10)), //add ten for the array height
				left: toPix(leftPosition())
			});

			$rootScope.$broadcast('ngInit.UNORDERED.LIST.DIRECTIVE', [ctrl.$$model, ctrl.$$parent, ctrl.ulList, ele]);

			unBind();
			$window.addEventListener('scroll', destroy, true);
			angular.element($document).on("click mousedown", mouseUp);
			angular.element($window).on("resize", destroy);

			ctrl.forceClose = function (e) {
				return destroy(e);
			};

			ctrl.destroy = function (e) {
				return destroy(e);
			};

			scope.$on('$destroy', destroy);

			function mouseUp(e) {
				e.preventDefault();
				if (!ele[0].contains(e.target) && !t.contains(e.target))destroy(e);
			}

			function unBind() {
				angular.element($document).off("click mousedown", mouseUp);
				angular.element($window).off("resize", destroy)
				$window.removeEventListener('scroll', destroy);
			}

			function destroy(e) {
				ctrl.$iEle.$destroy();
				ctrl.$iEle.remove();
				ele.remove();
				unBind();
			}


			scope.$on('$destroy', destroy)
		}

		return directive
	}


	function UnorderedListFactory($compile, $animate) {
		var directiveContainer = '<lcp-unordered-list></lcp-unordered-list>',
			UnorderedList = function (ele, ulList) {
				var _this = this,
					handler = [],
					opts = !angular.isArray(ulList[0]) ? [ulList] : ulList;

				var model = ele.controller('ngModel');
				if (model)_this.$$model = model.$viewValue;

				angular.forEach(opts, function (obj) {
					if (obj.length)
						this.push(obj)
				}, handler);

				_this.ulList = ulList;
				_this.$$parent = ele;
			};

		UnorderedList.prototype.show = function (iEle, scope) {
			var _this = this;
			this.$iEle = iEle;

			this.$iEle.data('onClick', true);
			this.$directive = angular.element(directiveContainer);
			this.$directive.data('lcpUnorderedList', _this);
			$compile(this.$directive)(scope);
			$animate.enter(this.$directive, iEle);

		};

		UnorderedList.prototype.remove = function () {

			var _this = this;
			_this.$iEle.data('onClick', false);
			$animate.leave(_this.$directive);
		};

		return UnorderedList;
	}

})(window.angular)
