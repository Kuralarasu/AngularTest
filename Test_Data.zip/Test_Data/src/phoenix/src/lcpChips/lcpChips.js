/**
 * Created by reyra on 3/16/2016.
 */
(function (angular) {
	'use strict';

	angular.module('lcp.chips.directive', []).directive('lcpChips', lcpChips);

	lcpChips.$inject = ['$timeout']

	function lcpChips($timeout) {
		var directive = {
			require: ['lcpChips', '?ngModel'],
			restrict: 'E',
			replace: true,
			scope: {
				label: "@placeholder",
				id: "@",
				separator: "=?",
				model: "=ngModel",
				readonly: "=?",
				focused: "=?",
				mdOnSelect: "=?",
				mdTransformChip: "=?",
				mdOnAdd: "=?",
				deleteButtonLabel: "=?",
				mdMaxChips: "=?"
			},
			controller: ['$scope', function ($scope) {
				var self = this;

				self.focused = angular.isDefined(self.focused) ? self.focused : false;
				self.readonly = angular.isDefined(self.readonly) ? self.readonly : false;
				self.mdMaxChips = angular.isDefined(self.mdMaxChips) ? (self.mdMaxChips < 0 ? 9999 : self.mdMaxChips) : 9999;


			}],
			controllerAs: 'ctrl',
			bindToController: true,
			link: postLinkFunc
		};


		directive.template = ['<div class="msp-chips" ng-class="{\'md-focused\':ctrl.focused,\'has-input-values\':ctrl.model.length}"><label ng-bind-html="ctrl.label"></label>',
			'<md-chips ng-model="ctrl.model"',
			'md-separator-keys="ctrl.separator"',
			'readonly="ctrl.readonly"',
			'md-on-select="ctrl.mdOnSelect"',
			'md-on-add="ctrl.mdOnAdd"',
			'secondary-placeholder="{{ctrl.label}}"',
			'md-transform-chip="ctrl.mdTransformChip"',
			'delete-button-label="{{ctrl.deleteButtonLabel}}"',
			'md-max-chips="{{ctrl.mdMaxChips}}"',
			'</md-chips></div>'].join(' ');

		function postLinkFunc(scope, ele, attr, ctrl) {

			var ngModelCtrl = angular.extend({}, {$setViewValue: angular.noop}, ctrl[1]),
				lcpChipsCtrl = ctrl[0];

			if (!ngModelCtrl) {
				return; // do nothing if no ng-model
			}

			ngModelCtrl.$viewChangeListeners.push(function () {
				scope.$eval(attr.ngChange);
			});


			$timeout(function () {
				var input = ele.find('input');
				if (ctrl.focused)input[0].focus()
				input.on('focus', function (e) {
					ctrl.focused = true;
					ele.addClass('md-focused')
				}).on('blur', function (e) {
					ctrl.focused = false;
					ele.removeClass('md-focused');
					//incase user set value to input but did not press enter
					var value = e.target.value;
					if(value){
						lcpChipsCtrl.model.push(value)
						ngModelCtrl.$setViewValue(lcpChipsCtrl.model);
						ngModelCtrl.$render();
						e.target.value = "";
					}


				});
			}, 100)
		};


		return directive;
	};

})(window.angular);
