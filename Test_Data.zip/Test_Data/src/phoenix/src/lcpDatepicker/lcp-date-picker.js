var moment = require('moment');

var lcpDatePicker;
(function (lcpDatePicker) {
	var directive;
	(function (directive) {
		var DatePicker = (function () {
			function DatePicker($timeout, $window, $document, $log, $mdUtil) {
				var _this = this;
				this.restrict = "A";
				this.priority = 9;
				this.require = "ngModel";
				this.replace = true;
				this.scope = {
					ddOpts: "=lcpDatePicker",
					format: "@",
					model: "@?ngModel",
					required: "@",
					ngRequired: "@",
					value: "=?ngModel"
				};
				this.controller = DatePickerController;
				this.controllerAs = "ctrl";
				this.bindToController = true;
				this.template = [
					'<div class="lcpDatePicker">',
					'<label class="md-datepicker-label">{{ctrl.opts.placeholder}}</label>',
					'<md-datepicker ng-model="ctrl.value" ng-change="ctrl.ngChange()"></md-datepicker>',
					'</div>'].join('');
				this.buildOpts = function (scope, attr) {
					var unique = Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1) + Date.now().toString(),
						defaults = {
							class: attr.class,
							id: attr.id || unique,
							maxDate: new Date(attr.maxDate) || false,
							minDate: new Date(attr.minDate) || false,
							name: attr.name || attr.id || unique,
							placeholder: attr.placeholder,
							required: attr.required || attr.ngRequired
						};
					scope.ctrl.opts = angular.extend({}, scope.ctrl.opts, defaults, scope.ddOpts);
					return scope.ctrl.opts;
				};
				this.preLinkFunc = function (scope, ele, attr, ctrl) {
					var opts = _this.buildOpts(scope, attr),
						input = ele.find("input"),
						mdDatepicker = ele.find("md-datepicker"),
						uniqueName = true;
					Object.keys(attr).forEach(function (key) {
						switch (key) {
							case "disabled":
								input.attr("disabled", true);
								break;
							case "required":
								if (attr["required"] !== undefined) {
									input.attr("ng-required", "");
									mdDatepicker.attr("ng-required", attr["ngRequired"] !== undefined ? attr["ngRequired"] : "required");
								}
								break;
							// If an ID is used - but no name - ensure the name attribute is present:
							case "id":
							case "name":
								mdDatepicker.attr("name", attr[key]);
								uniqueName = false;
								break;
							case "minDate":
								mdDatepicker.attr("md-min-date", "ctrl.opts.minDate");
								break;
							case "maxDate":
								mdDatepicker.attr("md-max-date", "ctrl.opts.maxDate");
								break;
							default:
								break;
						}
					});
					if (uniqueName) {
						// if no "id" or "name" is provided as an attr, use the unique value generated in buildOpts():
						mdDatepicker.attr("name", scope.ctrl.opts.id);
					}
					ele.controller("ngModel").$name = opts.name;
				};
				this.postLinkFunc = function (scope, ele, attr, ctrl) {
					var ngModelCtrl = angular.extend({$setViewValue: angular.noop}, ctrl),
						opts = scope.ctrl.opts,
						input = ele.find("input"),
						inputValueCached = "",
						openButton = input.next(),
						that = _this;

					ngModelCtrl.$viewChangeListeners.push(function () {
						scope.$eval(attr.ngChange);
					});


					scope.ctrl.ngChange = onCalendarChange;

					function onCalendarChange($event) {

						if(!angular.isDefined($event)) return;

						_this._$timeout(function () {
							setValidAndEmptyStates();
						}, 100);
						inputValueCached = input.val();

						ngModelCtrl.$setViewValue(arguments[1]);
						ngModelCtrl.$render();
					};

					_this._$timeout(function () {
						if (scope.ctrl.value) {
							setValidAndEmptyStates();
						}
					}, 0, false);

					var onBlurFunc = function ($event) {
						input[0].classList.remove("isFocused");
						input[0].classList.remove("onFocus");
						input[0].classList.remove("cachedValueRestored");
						ele.toggleClass("lcp-datepicker-not-empty", input[0].value.length);
						parseInput($event.target.value);
						$event.stopPropagation();
						ctrl.focus = false;
						ele.removeClass("md-datepicker-input-focused");
						_this._$timeout(function () {
							inputValueCached = input[0].value;
							setValidAndEmptyStates();
						}, 0);
					};

					input.on("focus", onFocus)
						.on("blur", onBlurFunc)
						.on("input", _this._$mdUtil.debounce(onInput, 200, _this));

					openButton.on("blur", onButtonBlurFunc)
						.on("click", onButtonClickFunc);

					function onButtonBlurFunc() {
						inputValueCached = input.val();
						restoreCachedValue();
					}

					function onButtonClickFunc() {
						that._$timeout(function () {
							var selected = that._$document[0].querySelector(".md-calendar-selected-date"),
								dateElm = selected ? selected : that._$document[0].querySelector(".md-calendar-date-today");
							if (dateElm) {
								dateElm.focus();
							}
						}, 500);
					}

					scope.$on("md-calendar-change", onCalendarChange);

					function onInput($event) {
						// that._$log.log('datepicker: onInput');
						if (!input[0].classList.contains("cachedValueRestored")) {
							input[0].classList.remove("onFocus");
						}
						input[0].classList.remove("cachedValueRestored");
						parseInput($event.target.value);
						that._$timeout(function () {
							// that._$log.log('datepicker: onInput calling setValidAndEmptyStates');
							setValidAndEmptyStates();
						}, 0); // ensure $mdDateLocaleProvider.parseDate has run
					}

					function parseInput(inputDate) {
						var inputDateReplaced = inputDate.replace(/^((\d{2})[\/]{0,1}(\d{2,2}))(?=(\d{1,4})$)/, "$2/$3/");
						var parsedDate = new Date(inputDateReplaced);
						if (parsedDate) {
							if (inputDate.length > 8 && inputDateReplaced !== inputDate) {
								scope.$broadcast("md-calendar-change", parsedDate);
							} else if (inputDate.length === 8 && isFinite(inputDate)) {
								input[0].value = inputDateReplaced;
								scope.$broadcast("md-calendar-change", parsedDate);
							}
						}
					}

					function setValidAndEmptyStates() {
						that._$timeout(function () {
							// that._$log.log('datepicker: setValidAndEmptyStates');
							var mdDatepicker = ele.find("md-datepicker"),
								isRequired = mdDatepicker.attr("ng-required") === "required",
								value = input[0].value,
								valueIsEmpty = !value,
								has2Slashes = valueIsEmpty ? false : (value.match(/\//g) || []).length === 2,
								hasAtLeast8Characters = valueIsEmpty ? false : value.length > 7,
								has8Characters = valueIsEmpty ? false : value.length === 8,
								has10Characters = valueIsEmpty ? false : value.length === 10,
								valueIsNumeric = valueIsEmpty || has2Slashes ? false : /^\d+$/.test(value),
								isTouched = mdDatepicker[0].classList.contains("ng-touched"),
								isValid = (valueIsEmpty && !isRequired) || hasAtLeast8Characters && ((has2Slashes && has10Characters) || (valueIsNumeric && has8Characters));
							ctrl.$setValidity("valid", isValid);
							ele.toggleClass("lcp-datepicker-touched", isTouched);
							ele.toggleClass("lcp-datepicker-invalid", !isValid);
							ele.toggleClass("lcp-datepicker-not-empty", !valueIsEmpty);
							ele.attr("aria-required", isRequired);
							// If the user enters a valid date (e.g., "05/19/1959") and then enters an invalid date
							// (e.g., adds an extra digit like "05/19/19599"), the model will retain the valid date,
							// so we need to remove the date from the model but preserve the invalid input:
							if (!isValid) {
								var valueCopy = angular.copy(value);
								ctrl.$value = null;
								ctrl.$modelValue = null;
								ctrl.$viewValue = null;
								input[0].value = valueCopy;
							}
						}, 0);
					}

					function onFocus(event) {
						input[0].classList.add("onFocus");
						input[0].classList.add("isFocused");
						var relatedTarget = event.relatedTarget,
							buttonClass = "md-datepicker-triangle-button",
							isFromTriangleButton = relatedTarget !== null && relatedTarget.classList.contains(buttonClass),
							inputValue = input.val(),
							tabCharExists = inputValue.length === 1 && inputValue.search(/\t/) === 0,
							isNgEmpty = ele.hasClass("ng-empty"),
							isNotEmptyInvalid = ele.hasClass("lcp-datepicker-not-empty") && ele.hasClass("lcp-datepicker-invalid"),
							hasInvalidValue = isNgEmpty && isNotEmptyInvalid,
							wasInvalid = tabCharExists && hasInvalidValue,
							doRestoreCachedValue = isFromTriangleButton || (tabCharExists && inputValueCached !== "") || wasInvalid;
						input.val(inputValue.replace(/\t+/g, ""));
						ele.addClass("md-datepicker-input-focused");
						that._$timeout(function () {
							if (doRestoreCachedValue) {
								restoreCachedValue();
								inputValueCached = "";
							}
							setCursor();
						});
					}

					function restoreCachedValue() {
						input[0].classList.add("cachedValueRestored");
						input[0].value = inputValueCached;
					}

					function setCursor() {
						var inputFocused = input[0].classList.contains("onFocus") && input[0].classList.contains("isFocused");
						if (inputFocused) {
							input[0].select();
						}
					}

					Object.keys(attr.$attr).forEach(function (key) {
						if (key !== "class" && key !== "id" && key !== "ngClass") {
							ele.removeAttr(attr.$attr[key]);
						}
					});

					if (opts.callback) {
						opts.callback.apply(_this, [ele, input, opts.id]);
					}
				};
				this._$timeout = $timeout;
				this._$window = $window;
				this._$document = $document;
				this._$mdUtil = $mdUtil;
				this._$log = $log;
				this.link = {
					post: this.postLinkFunc,
					pre: this.preLinkFunc
				};
			}

			DatePicker.instance = function ($timeout, $window, $document, $log, $mdUtil) {
				return new DatePicker($timeout, $window, $document, $log, $mdUtil);
			};
			DatePicker.$inject = ["$timeout", "$window", "$document", "$log", "$mdUtil"];
			return DatePicker;
		}());
		var DatePickerController = (function () {
			function DatePickerController($scope, $timeout) {
				var _this = this;
				this.date = false;
				this.open = function (event) {
					event.preventDefault();
					_this.date = !_this.date;
				};
				this.disabled = function (date, mode) {
					return (mode === "day" && (date.getDay() === 0 || date.getDay() === 6));
				};
				this.opts = {
					format: "MM/dd/yyyy",
					options: {
						formatMonth: "MMM",
						formatYear: "yyyy",
						showWeeks: false,
						startingDay: 0
					}
				};
			}

			DatePickerController.$inject = ["$scope", "$timeout"];
			return DatePickerController;
		}());
		angular.module("phx.lcpDatePicker", [])
			.directive("lcpDatePicker", ["$timeout", "$window", "$document", "$log", "$mdUtil", DatePicker.instance])
			.config(function ($mdDateLocaleProvider) {
				$mdDateLocaleProvider.formatDate = function (date) {
					return date ? moment(date).format('MM/DD/YYYY') : '';
				};

				$mdDateLocaleProvider.parseDate = function (dateString) {
					var m = moment(dateString, 'MM/DD/YYYY', true);
					return m.isValid() ? m.toDate() : new Date(NaN);
				};
			});
	})(directive = lcpDatePicker.directive || (lcpDatePicker.directive = {}));
})(lcpDatePicker || (lcpDatePicker = {}));
