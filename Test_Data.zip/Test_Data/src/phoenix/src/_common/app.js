module.exports = function () {
    'use strict';
    //CSS libraries
    require("./styles/styles.less");


	/**
	 * @ngdoc overview
	 * @name phxApp
	 *
	 * @description
	 * # Phoenix API Documentation
	 *
	 */

    //App modules
    var appModule = angular.module('phxApp', [
        require('./common.js').name,
        require('./authentication/authentication.js').name
    ]);

    //inject all of the phx routes application
    require('./routes.js')(appModule);
    // require('./electron.imports.js')(appModule);

    //additional modules
    require('./login/login.js')(appModule);
    require('./configs/configs.js')(appModule);

    //provider
    require('./provider/lazy-loader.provider')(appModule);
    require('./provider/phx-state.provider')(appModule);


    appModule.run(Run);


    Run.$inject = ['$rootScope', '$state', '$stateParams', 'authService', 'userService', '$log', '$location'];
    function Run($rootScope, $state, $stateParams, authService, userService, $log) {

        $rootScope.stateHistory = [];

        $rootScope.$on('$stateChangeStart', function (event, next, nextParams) {

            //console.log("$stateChangeStart.next: ", next, nextParams);

            // On each route change, we check if user is navigating to non-login screen
            // and make sure he is still logged in (profile exists in JS memory
            if (next.name !== 'login') {
                $log.log('not a login page ');

                //save original target before going to login
                //Move this to save allways new session location on route change
                authService.saveTargetState(next, nextParams);

                //As this is called for each route change, user's profile is checked only in JS memory.
                //If user's profile exist in JS memory, we are good. If user refreshed the screen, we would request new profile
                //using the SMSESSION cookie if exist, if not, user will be forced to go to login screen (handled by http-interceptor.js).

                //if not authN'd, get authN
                if (!authService.isAuthenticated(next)) {

                    //then get authN's
                    $log.log('saving $state target : ', next, nextParams);
                    //save original target before going to login
                    authService.saveTargetState(next, nextParams);

                    //TODO: kfw 150901 consider .then.catch notation
                    authService.restoreSession().then(function (status) {
                        //if not authZ'd, get authZ
                        userService.isAuthorized(next, true).then(function (isAuthZ) {
                            if (isAuthZ) {
                            } else {
                                event.preventDefault();
                                $state.go('dashboard');//TODO: where do we go if we fail
                            }
                        }).catch(function (error) {
                            event.preventDefault();
                            $state.go('dashboard');//TODO: where do we go if we fail
                        });

                    }).catch(function (status) {
                        event.preventDefault();
                        $log.log("SESSION RESTORE FAILED, need to login again: ", next, nextParams);
                        $state.go('login')//TODO: where do we go if we fail
                    });
                }

            } else {
                $log.log('its a login page ');
            }
        });

        $rootScope.$on('$stateChangeSuccess', function (event, next, nextParams, from, fromParams) {

            // save state to history
            $rootScope.stateHistory.push({ state: from, stateParams: fromParams });

        });


        $rootScope.$state = $state;
        $rootScope.$stateParams = $stateParams;

        $rootScope.$on('$stateChangeError', function (event) {
            console.log("$stateChangeError: ", arguments);
        });

        $rootScope.$on('$stateNotFound', function (event) {
            console.log("$stateNotFound: ", arguments);
        });

        $rootScope.$on('ocLazyLoad.moduleLoaded', function (e, module) {
            console.log('module loaded', module);
        });

    }


    return appModule;
}();

