/**
 * Created by ramor11 on 4/19/2016.
 */


module.exports = function (app) {
	"use strict";

	/**
	 * @ngdoc service
	 * @name phxApp
	 *
	 *
	 * @requires phxStateProvider
	 *
	 * @description
	 * identify routes for phxApp module injection
	 *
	 */


	app.config(RouteProvider)

	RouteProvider.$inject = ['phxStateProvider'];

	function RouteProvider(states) {

		/*******************************************************
		 *    to be remove once modules are created
		 *******************************************************/

		// states.permission({
		// 	"order": 1, //define the order of the module to display onto UI
		// 	"display": "Selling"//Module name to display to UI
		// });

		// states.permission({
		// 	"order": 2, //define the order of the module to display onto UI
		// 	"display": "Testing"//Module name to display to UI
		// });

		// states.permission({
		// 	"order": 3, //define the order of the module to display onto UI
		// 	"display": "Ordering"//Module name to display to UI
		// });

		// states.permission({
		// 	"order": 4, //define the order of the module to display onto UI
		// 	"display": "Reporting"//Module name to display to UI
		// });
	}

};
