var routes = [
	{
		name: 'root',
		abstract: true,
		views: {
			'topNavView@': {
				template: require('html!./partials/appHead.html'),
				controller: 'phxCommonTopNavigationController',
				controllerAs: 'ctrl'
			},
			'footerView@': {
				template: require('html!./partials/appFooter.html'),
				controller: 'phxCommonFooterController',
				controllerAs: 'footer'
			}
		}
	},
	// {
	// 	name: 'dashboard',
	// 	parent: 'root',
	// 	url: '/',
	// 	views: {
	// 		'appBody@': {
	// 			template: "",
	// 			controller: ['helpRouteService', function (helpRoute) {
	// 				helpRoute.init();
	// 			}]
	// 		}
	// 	}
	// },
	// {
	// 	name: 'app-messages',
	// 	parent: 'root',
	// 	url: 'app-messages/',
	// 	views: {
	// 		'appBody@': {
	// 			template: require('html!./partials/app_messages/app-errors.html'),
	// 			controller: 'common.ctrls.appMessagesCtrl',
	// 			controllerAs: 'appMessagesCtrl'
	// 		}
	// 	}
	// },


];


module.exports = routes;
