module.exports = function (app) {
	"use strict";

	/**
	 * @ngdoc object
	 * @name phxApp.COMMON_EVENTS
	 *
	 * @description
	 *
	 */

	app.constant('COMMON_EVENTS', {
		'viewPortChanged': 'browser.viewport.changed',
		'httpApiRequestInProgress': 'api.http.request.inprogress',
		'httpApiRequestCompleted': 'api.http.request.completed',
		'httpApiRequestFailed': 'api.http.request.failed'
	});

};
