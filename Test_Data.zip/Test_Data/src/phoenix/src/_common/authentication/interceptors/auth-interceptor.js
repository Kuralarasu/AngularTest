module.exports = function (app) {
    "use strict";


	/**
	 * @ngdoc service
	 * @name phx.authc.factory:httpAuthInterceptor
	 *
	 * @description
	 *
	 */


    app.factory('httpAuthInterceptor', httpAuthInterceptor);

    httpAuthInterceptor.$inject = [
        '$rootScope',
        '$q',
        'AUTH_EVENTS',
        'COMMON_EVENTS',
        'ERROR_MESSAGES',
        'phxCommonMessenger',
        'phxCommonUtilities',
        '$log',
        'MsgHistoryService',
        'RestUrlService',
        '$cookies',
        'uuid4',
        'bsLoadingOverlayService',
        '$timeout'
    ];

    function httpAuthInterceptor($rootScope,
        $q,
        AUTH_EVENTS,
        COMMON_EVENTS,
        errorMessages,
        lcdMessage,
        utilities,
        $log,
        _msgHistoryService,
        urlService,
        $cookies,
        uuid,
        bsLoadingOverlayService,
        $timeout) {

         function request(request) {
              bsLoadingOverlayService.start(); 
            return request; 
            
        }

        
        function response(response) {
            bsLoadingOverlayService.stop();
            return response;
        }

        

        function requestError(responseError) {
            bsLoadingOverlayService.stop();
            return responseError;
            
        }

		function responseError(rejection) {
            //lcdMessage.hide(); //hide the spinner
            bsLoadingOverlayService.stop();
            return rejection;

            
        }

        return {
            request: request,
            response: response,
            requestError: requestError,
            responseError: responseError
        };
    }


}
