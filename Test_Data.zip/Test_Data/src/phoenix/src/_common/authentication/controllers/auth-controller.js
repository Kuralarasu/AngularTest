module.exports = function (app) {
	'use strict';

	/**
	 * @ngdoc service
	 * @name phx.authc.phxCommonAuthController
	 *
	 * @description
	 *
	 */



	app.controller('phxCommonAuthController', AuthCtrl);

	function AuthCtrl(authService) {
		//authService.initiateLoginProcess();

	};

	AuthCtrl.$inject = ['authService'];


};
