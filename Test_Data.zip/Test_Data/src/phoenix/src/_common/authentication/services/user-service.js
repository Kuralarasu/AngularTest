module.exports = function (app) {

	"use strict";


	/**
	 * @ngdoc service
	 * @name phx.authc.factory:userService
	 *
	 * @description
	 *
	 */

	app.factory('userService', userService);


	userService.$inject = ['phxState', '$http', 'RestUrlService', '$q', '$state', '$log'];

	function userService(phxState, $http, urlService, $q, $state, $log) {

		/**********************************************************************************************************
		 * TODO: DWA-NFP - the following section is strictly for testing until the authZ service is available
		 ***********************************************************************************************************/
		//TODO: fix service/module pattern, use reveal pattern


		//Private Variables to store service state for user and state
		var _user = {},
			uiMap = phxState.uiResourceMap,
			uiResourceMap = {
				"TopNav": uiMap.TopNav,
				"SideNav": uiMap.SideNav
			},
			_appStatesMaps = uiMap._appStatesMaps,
			_permittedStates = ['dashboard', 'settings'];


		var singleton = {
			isKnown: function () {
				return (_user && ((_user.name && _user.name.length > 0) || (_user.permissions && Object.getOwnPropertyNames(_user.permissions).length > 0)));
			},

			reset: function () {
				_user = {};
			},

			setKnown: function (userdata) {
				if (userdata && typeof userdata == "object") {
					_user = {};
					var userProperties = Object.getOwnPropertyNames(userdata);
					if (userProperties && userProperties.length > 0) {
						userProperties.forEach(function (userProp) {
							_user[userProp] = userdata[userProp];
						});
					}
					//_user.name = username;
				}

			},

			//checks to see if user is authZ'd for a specific state
			isAuthorized: function (state, isAuthN) {
				var deferred = $q.defer();
				if (!state) {
					deferred.reject('route state not provided');
				} else {
					var self = this;
					//console.log(_user);
					if (!_user || !_user.permissions) {
						if (isAuthN) {
							//deferred.resolve(true);
							//console.log("HERE!");
							this.authorize(state).then(function (state) {
								//console.log("state");
								//console.log(state);

								//Up to here I got
								self._validateRouteAsync(state).then(function (isValid) {
									//deferred.resolve(true);
									deferred.resolve(isValid);
								}).catch(function (error) {
									//deferred.resolve(true);
									deferred.reject(error);
								});
							}).catch(function (error) {
								deferred.reject('not authorized for this feature or path');
							});
						} else {
							deferred.reject('not authenticated, please log in');
						}
					} else {
						this._validateRouteAsync(state).then(function (isValid) {
							deferred.resolve(isValid);
						}).catch(function (error) {
							deferred.reject(error);
						});
					}
				}

				return deferred.promise;

			},

			authorize: function (state) {
				var deferred = $q.defer(),
					topLevel = true;

				//console.log("state");
				//console.log(state);

				//$log.log('authorize 1: ', _user.permissions);
				if (!_user || !_user.permissions) {
					var that = this;
					this.getPermissions('TopNav')
						.then(function (permissions) {
							//console.log('TopNav.then: ', permissions);
							//console.log("PERMISSIONS");
							//console.log(permissions);
							deferred.resolve(state);
						})
						.catch(function (status) {
							//console.log('TopNav.catch: ', status);
							//deferred.resolve(state);
							deferred.reject(status);
						});

				}

				return deferred.promise;
			},

			getPermissions: function (resourceType) {

				$log.log('getPermissions: ', resourceType);
				var deferred = $q.defer();
				var self = this;
				if (!resourceType) {
					//$log.log('in !url');
					deferred.reject('no resourceType provided');
				}

				if (_user && _user.permissions && _user.permissions[resourceType]) {
					deferred.resolve();
				} else {
					var authZUrl = urlService.getUrl(urlService.AUTHZ_URL);
					$log.log('getPermissions.preHttp: ', authZUrl, (_user) ? _user.name : "no _user", {
						"elementEvalRequests": [{
							"type": "TopNav",
							"items": uiResourceMap.TopNav
						}]
					});
					//console.log("POST");
					//console.log(authZUrl);

					//console.log(uiResourceMap.SideNav);

					//Build permissions list of what is in the side nav

					var sideNavPermissions = new Array();

					uiResourceMap.SideNav.forEach(function (item) {

						var outcomeObject = {
							"id": item,
							"decision": "Permit"
						}

						sideNavPermissions.push(outcomeObject);

						//console.log("item");
						//console.log(item);
					});


					//TODO fix these permissions
					var someData = {
						"elementEvalResponses": [{
							"outcomes": [{
								"id": "ReferenceData",
								"decision": "Permit"
							},
							{
								"id": "errorManagement",
								"decision": "Permit"
								},
							{
								"id": "e2eTesting",
								"decision": "Permit"
							}],
							"type": "TopNav" }, {
								"outcomes": sideNavPermissions,
								"type": "SideNav" }] };

					if (_user.userName != "wtadmin") {

						someData.elementEvalResponses.forEach(function (item) {

							$log.log('data.elementEvalResponses.forEach', item);
							var resourceTypeMatch = false;
							var permissionResourceType = item.type;
							if (_user && _user.permissions) {
								var knownResourceTypes = Object.getOwnPropertyNames(_user.permissions);
								resourceTypeMatch = knownResourceTypes.some(function (knownItem) {
									return knownItem == permissionResourceType;
								});
							}

							if (!resourceTypeMatch) {
								if (!_user.permissions) {
									_user.permissions = {};
								}
								$log.log('!resourceTypeMatch', _user.permissions);
								_user.permissions[permissionResourceType] = {};
								var outcomes = item.outcomes;
								if (outcomes && Array.isArray(outcomes) || outcomes.length == 0) {
									outcomes.forEach(function (outcomeItem) {
										_user.permissions[permissionResourceType][outcomeItem.id] = outcomeItem.decision;
										self._applyPermissionToState(outcomeItem.id, outcomeItem.decision);
										//$log.log('_user.permissions[permissionResourceType][outcomeItem.id]', outcomeItem.decision, _user.permissions[permissionResourceType][outcomeItem.id], JSON.stringify(_user.permissions));
									});
								}

							}
						});

						deferred.resolve();

					} else {

						$http.post(authZUrl, {
							"elementEvalRequests": [{
								"type": resourceType,
								"items": uiResourceMap[resourceType]
							},
							{
								"type": 'SideNav',
								"items": uiResourceMap["SideNav"]
							}]
						}
						).then(function (data, status, headers, config) {
							var dataZ = data.data;

							//console.log("dataZ");
							//console.log(JSON.stringify(dataZ));
							//console.log(dataZ);

							//console.log('successfully retrieved authZ data');
							$log.log('successfully retrieved authZ data', dataZ, dataZ.elementEvalResponses);
							if (!dataZ || !dataZ.elementEvalResponses) {
								deferred.reject('no authorization returned');
							}

							if (!Array.isArray(dataZ.elementEvalResponses) || dataZ.elementEvalResponses.length == 0) {
								deferred.reject('returned authorization is empty');
							}

							dataZ.elementEvalResponses.forEach(function (item) {
								$log.log('data.elementEvalResponses.forEach', item);
								var resourceTypeMatch = false;
								var permissionResourceType = item.type;
								if (_user && _user.permissions) {
									//console.log("_user");
									//console.log(_user);
									var knownResourceTypes = Object.getOwnPropertyNames(_user.permissions);
									resourceTypeMatch = knownResourceTypes.some(function (knownItem) {
										return knownItem == permissionResourceType;
									});
								}

								if (!resourceTypeMatch) {
									if (!_user.permissions) {
										_user.permissions = {};
									}
									$log.log('!resourceTypeMatch', _user.permissions);
									_user.permissions[permissionResourceType] = {};
									var outcomes = item.outcomes;
									if (outcomes && Array.isArray(outcomes) || outcomes.length == 0) {
										outcomes.forEach(function (outcomeItem) {
											_user.permissions[permissionResourceType][outcomeItem.id] = outcomeItem.decision;
											self._applyPermissionToState(outcomeItem.id, outcomeItem.decision);
											//$log.log('_user.permissions[permissionResourceType][outcomeItem.id]', outcomeItem.decision, _user.permissions[permissionResourceType][outcomeItem.id], JSON.stringify(_user.permissions));
										});
									}

								}
							});
							deferred.resolve();

						}).catch(function (data, status, headers, config) {
							//console.log('failed to retrieve authZ data', data, status);
							$log.log('failed to retrieve authZ data', data, status);
							deferred.reject(status);
						});
					}
				}

				//TODO: we should get _user.email during authN, should we verify that we get it here?
				////get userprofile in background
				//if (!_user.email) {
				//	$http.get(urlService.getUrl(urlService.USER_PROFILE)).
				//		then(function(data, status, headers, config) {
				//			$log.log('profile success: ', data);
				//		}).
				//		catch(function(data, status, headers, config) {
				//			$log.error('profile error: ', data, status, headers, config);
				//		});
				//}


				return deferred.promise;
			},

			canAccess: function (resourceID) {
				if (!_user || !_user.permissions) {
					return '';
				}
				var routeIsValid = '';
				_appStatesMaps.forEach(function (item) {
					if (item.id == resourceID) {
						routeIsValid = (item.access == 'Permit') ? item.state : '';
					}
					;
				});
				return routeIsValid;
			},

			_applyPermissionToState: function (_id, action) {
				var state = '';
				_appStatesMaps.forEach(function (_item) {
					if (_item.id == _id) {
						_item.access = action;
						state = _item.state;

						if (action == 'Permit') {
							if (_permittedStates.indexOf(state) == -1)
								_permittedStates.push(state);
						}

					}
				});

				return state;
			},

			getEmail: function () {
				var deferred = $q.defer();

				//get userprofile in background
				if (_user.email) {
					deferred.resolve(_user.email);
				} else {
					$log.log('calling getemail -> userprofile');
					$http.get(urlService.getUrl(urlService.USER_PROFILE)).then(function (data, status, headers, config) {
						$log.log('profile success: ', data);
						if (data && data.data && data.data.email) {
							_user.email = data.data.email;
						}

						deferred.resolve(_user.email);
					}).catch(function (data, status, headers, config) {
						$log.error('profile error: ', data, status, headers, config);
						deferred.reject(status);
					});
				}

				return deferred.promise;
			},

			getUserName: function () {
				if (_user && _user.userName) {
					//$log.log('userService.getUsername, username found: ', _user);
					return _user.userName;
				}

				return 'unknown';
			},

			_validateRouteAsync: function (path) {
				var deferred = $q.defer();

				$log.log('_validateRouteAsync: ', path);
				if (this._validateRoute(path)) {
					deferred.resolve(true);
				} else {
					deferred.reject(false);
				}

				return deferred.promise;
			},

			_validateRoute: function (_state) {
				if (!_user || !_user.permissions) {
					return false;
				}

				var routeIsValid = true;
				if (_permittedStates.indexOf(_state.name) == -1) {
					routeIsValid = false;
				}
				;
				return routeIsValid;

			}

		};

		return singleton;
	}


}
