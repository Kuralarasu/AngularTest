module.exports = function (app) {
	"use strict";

	/**
	 * @ngdoc service
	 * @name phx.authc.factory:authService
	 *
	 * @description
	 *
	 */



	app.constant('useLocalStorage', false).service('phxAuthStorage', phxAuthStorage).factory('authService', authService);

	phxAuthStorage.$inject = ['Storage']

	function phxAuthStorage(Storage) {
		!function () {
			var db = Storage.db,
				key = 'phxAuthCollection';

			this.db = db;
			this.$collection = db.getCollection(key) || function () {
				var collection = db.addCollection(key, {
					autoupdate: true
				});
				db.saveDatabase();
				return collection;
			} ();

			this.insert = function (obj) {
				this.$collection.insert(obj);
				db.saveDatabase();
			}

		}.apply(this, []);
	}


	authService.$inject = ['$rootScope',
		'$http',
		'RestUrlService',
		'userService',
		'AUTH_EVENTS',
		'$q',
		'common.svcs.modalService',
		'$state',
		'$document',
		'$log',
		'lcpElectron',
		'$cookies',
		'$mdDialog',
		'phxAuthStorage',
		'useLocalStorage',
		'EnvironmentConstants'];


	function authService($rootScope,
		$http,
		urlService,
		userService,
		AUTH_EVENTS,
		$q,
		modalService,
		$state,
		$document,
		$log,
		lcpElectron,
		$cookies,
		$mdDialog,
		Storage,
		useLocalStorage,
		EnvironmentConstants) {
		//Private Variables to store service state for user and state
		var _targetState, _targetParams;
		var authUrl = EnvironmentConstants.host +  EnvironmentConstants.userAuthServiceport + "/api/User";
		var phxAuthUrl = urlService.AUTHC_URL,
			signoutUrl = urlService.AUTHC_SIGNOUT_URL;
		//_isSignedOut = false,
		//_secondAttempt = false;

		$rootScope.$on(AUTH_EVENTS.redirecttoroot, function (rejection) {
			//$log.log('LOGIN REQUIRED EVENT HANDLER', $state.current, $state.params);
			$state.go('dashboard');
		});

		$rootScope.$on(AUTH_EVENTS.loginrequired, function (rejection) {
			//$log.log('LOGIN REQUIRED EVENT HANDLER', $state.current, $state.params);
			singleton.onSessionTimeout();
		});

		//TODO This block of code may not be needed as login modal can handle failed login
		$rootScope.$on(AUTH_EVENTS.loginfailed, function () {
			//$log.log('LOGIN FAILED CAPTURED IN AUTH SERVICE');
			singleton.onSessionTimeout();
		});

		var singleton = {

			doLogout: function () {

				//_isSignedOut = true;
				// var deferred = $q.defer();
				$rootScope.$broadcast('LCP_SIGN_OUT_BROADCAST');


				var tomorrow = new Date(); //moment();
				tomorrow.setDate(tomorrow.getDate() + 1);

				// 160310 kfw: this doLogout function is called on timeout or when SignOut link is clicked. When
				//     this occurs, we write a cookie to represent this condition.  This cookie is used when the user
				//     tries to log back in.  If this cookie is set to 'loggedOut', a dummy auth request is made to
				//     prime the SMCHALLENGE header. Upon completion of a re-login request, or app start, the deAuth
				//     cookie will be removed.
				$cookies.remove('SMCHALLENGE');
				$cookies.put('deAuth', 'loggedOut', { expires: tomorrow });

				return $http({
					method: 'GET',
					url: signoutUrl
				}).then(angular.noop, function (data, status, headers, config) {
					//It's not expected that logout could fail at all, but just in case.
					$log.log('logging out failed.......', data, status, headers, config);
				}).finally(function () {
					userService.reset();
					//TODO don't redirect on logout
					$state.go('ReferenceData');
				});

				// return deferred.promise;
			},

			onSessionTimeout: function () {
				//$log.log("session logged out ...?>>>>>>>>>>>> show login window ");
				console.log("session logged out ...?>>>>>>>>>>>> show login window ");
				//_isSignedOut = true;
				this.initiateLoginProcess('timeout');
			},

			isAuthenticated: function (state) {
				if (userService.isKnown()) {
					//$log.log("User Profile available in JS memory", userService.isKnown());
					return true;
				}

				//$log.log("User Profile NOT available in JS memory");
				return false;
			},


			/**
			 * If user refresh the page and the SMSESSION cookie still valid,
			 * we need to restore user's profile (session) by calling rest API
			 *
			 * If API fails due to auth HTTP error, interceptor will take over the control
			 * @returns {*}
			 */
			initiateLoginProcess: function (reason) {
				//To avoid of modal clones when the user does not authenticate
				if (angular.element($document[0].querySelector('#AuthSignIn')).length) return;

				console.log('initiateLoginProcess: ', reason);

				//TODO probably remove these
				ctrl.user.username = "covance";
				ctrl.user.password = "covance";

				ctrl.infoMsg = 'Logging in...';
				ctrl.errorMsg = null;

				service.authenticate(ctrl.user.username, ctrl.user.password)
					//then(function (data, status, headers, config) {
					//	userService.setKnown(data);
					.then(function (data, status, headers, config) {
						$log.log("successful authentication", data, status);
						userService.setKnown(data);
						//userService.setKnown({username: ctrl.user.username});
						var savedState = service.getTargetState();
						if (!savedState.state) savedState = {
							state: { 'name': 'dashboard', 'url': '/' },
							stateParams: null
						};

						console.log('in auth.then: ', savedState, savedState.state, savedState.state.name);
						userService.isAuthorized(savedState.state, true).then(function (isAuthZ) {
							console.log('in isAuthZ.then: ', isAuthZ);
							if (isAuthZ) {
								$mdDialog.hide();
								console.log('in isAuthZ.then: ', savedState, savedState.state, savedState.state.name);
								$state.go(savedState.state.name, savedState.stateParams || {});
							} else {
								//$log.log("failed auth, ln 142: ", result);
								ctrl.errorMsg = 'User not authorized to view requested feature';
								ctrl.infoMsg = null;
								$state.go('dashboard');
							}
						}).catch(function (error) {
							//$log.log("failed auth, ln 148: ", result);
							ctrl.errorMsg = error;
							ctrl.infoMsg = null;
							$state.go('dashboard');
						});
					}, function (result) {

						// 160310 kfw: removed second attempt check, conflicted with false
						//     log in checks. Use a deAuth cookie to identify _isSignedOut
						userService.reset();
						ctrl.errorMsg = 'Login failed';
						ctrl.infoMsg = null;
						ctrl.user.password = null;
					});



				var service = this,
					// modalOptions = {},
					modalOptions = {
						hasBackdrop: true,
						//keyboard: true,
						//modalFade: true,
						controller: ['$mdDialog', function ($mdDialog) {
							var ctrl = this,
								$collection = Storage.$collection,
								db = Storage.db;

							this.user = {
								username: '',
								password: null
							};

							this.errorMsg = null;
							this.infoMsg = (reason == 'timeout') ? 'your session timed out' : '';


							this.submit = function () {

								ctrl.user.username = "covance";
								ctrl.user.password = "covance";


								ctrl.infoMsg = 'Logging in...';
								ctrl.errorMsg = null;

								service.authenticate(ctrl.user.username, ctrl.user.password)
									//then(function (data, status, headers, config) {
									//	userService.setKnown(data);
									.then(function (data, status, headers, config) {
										$log.log("successful authentication", data, status);
										userService.setKnown(data);
										//userService.setKnown({username: ctrl.user.username});
										var savedState = service.getTargetState();
										if (!savedState.state) savedState = {
											state: { 'name': 'dashboard', 'url': '/' },
											stateParams: null
										};

										console.log('in auth.then: ', savedState, savedState.state, savedState.state.name);
										userService.isAuthorized(savedState.state, true).then(function (isAuthZ) {
											console.log('in isAuthZ.then: ', isAuthZ);
											if (isAuthZ) {
												$mdDialog.hide();
												console.log('in isAuthZ.then: ', savedState, savedState.state, savedState.state.name);
												$state.go(savedState.state.name, savedState.stateParams || {});
											} else {
												//$log.log("failed auth, ln 142: ", result);
												ctrl.errorMsg = 'User not authorized to view requested feature';
												ctrl.infoMsg = null;
												$state.go('dashboard');
											}
										}).catch(function (error) {
											//$log.log("failed auth, ln 148: ", result);
											ctrl.errorMsg = error;
											ctrl.infoMsg = null;
											$state.go('dashboard');
										});
									}, function (result) {

										// 160310 kfw: removed second attempt check, conflicted with false
										//     log in checks. Use a deAuth cookie to identify _isSignedOut
										userService.reset();
										ctrl.errorMsg = 'Login failed';
										ctrl.infoMsg = null;
										ctrl.user.password = null;
									});


								if (ctrl.user) {
									if (!ctrl.user.username || !ctrl.user.password) {
										ctrl.errorMsg = 'Username and password required';
										ctrl.infoMsg = null;
										ctrl.user.password = null;
									} else {


										ctrl.infoMsg = 'Logging in...';
										ctrl.errorMsg = null;

										service.authenticate(ctrl.user.username, ctrl.user.password)
											//then(function (data, status, headers, config) {
											//	userService.setKnown(data);
											.then(function (data, status, headers, config) {
												$log.log("successful authentication", data, status);
												userService.setKnown(data);
												//userService.setKnown({username: ctrl.user.username});
												var savedState = service.getTargetState();
												if (!savedState.state) savedState = {
													state: { 'name': 'dashboard', 'url': '/' },
													stateParams: null
												};

												console.log('in auth.then: ', savedState, savedState.state, savedState.state.name);
												userService.isAuthorized(savedState.state, true).then(function (isAuthZ) {
													console.log('in isAuthZ.then: ', isAuthZ);
													if (isAuthZ) {
														$mdDialog.hide();
														console.log('in isAuthZ.then: ', savedState, savedState.state, savedState.state.name);
														$state.go(savedState.state.name, savedState.stateParams || {});
													} else {
														//$log.log("failed auth, ln 142: ", result);
														ctrl.errorMsg = 'User not authorized to view requested feature';
														ctrl.infoMsg = null;
														$state.go('dashboard');
													}
												}).catch(function (error) {
													//$log.log("failed auth, ln 148: ", result);
													ctrl.errorMsg = error;
													ctrl.infoMsg = null;
													$state.go('dashboard');
												});
											}, function (result) {

												// 160310 kfw: removed second attempt check, conflicted with false
												//     log in checks. Use a deAuth cookie to identify _isSignedOut
												userService.reset();
												ctrl.errorMsg = 'Login failed';
												ctrl.infoMsg = null;
												ctrl.user.password = null;
											});
									}

								}


							};
							this.cancel = function () {
								//$log.log("AuthCtrl.cancel: ", ctrl.user);
								$state.go('login');


								$rootScope.$broadcast('LCP_SIGN_OUT_BROADCAST');

								// //$modalInstance.dismiss();
								// /**
								//  * This is a message service to communicate, to parent container, used if
								//  * application is within iframe of parent.
								//  *
								//  */
								// lcpElectron(function(){
								// 	this.getCurrentWindow().close();
								// })

							}
						}],
						controllerAs: 'auth',
						template: require('html!../views/auth-modal.html')
					};

				console.log('should initiate login: ', modalOptions);
				//$mdDialog.show(modalOptions);
				console.log("did it load yet");
				modalService.showModal(modalOptions);
			},

			/**
			 * If user refresh the page and the SMSESSION cookie still valid,
			 * we need to restore user's profile (session) by calling rest API
			 *
			 * If API fails due to auth HTTP error, interceptor will take over the control
			 * @returns {*}
			 */
			restoreSession: function () {
				var service = this;
				var deferred = $q.defer();

				service.authenticate(null, null).then(function (data, status, headers, config) {
					userService.setKnown(data);
					userService.isAuthorized(service.getTargetState().state, true).then(function (authZUser) {
						deferred.resolve(authZUser);
					}).catch(function (error) {
						deferred.reject('not authorized');
					});
				}).catch(function (data, status, headers, config) {
					userService.reset();

					//We would reject only for 401 or 403
					//if Server failed other reason, its not a login issue.
					if (status === 401 || status === 403 || status === 500) {
						deferred.reject(status);
					} else {
						deferred.resolve(status);
					}
				});

				return deferred.promise;
			},

			saveTargetState: function (state, params) {
				if (state) {
					_targetState = state;
					_targetParams = params;
				}

				return true;
			},

			getTargetState: function () {
				return { state: _targetState, stateParams: _targetParams };
			},


			authenticate: function (username, password, successcb, failurecb) {

				//console.log(username);

				var authUrlHere = username === "wtadmin" ? phxAuthUrl : authUrl;

				var retries = 0,
					deferred = $q.defer(),
					handler = {
						method: 'GET',
						withCredentials: true,
						url: authUrlHere
					},
					successFunc = typeof successcb === 'function' ? successcb : function (data) {
						// $log.log("authService.authenticate => success: data", data, status, headers, config);
						//TODO: authorize user
						if (data.data && typeof data.data == "object") {
							$rootScope.$broadcast('userInfoDetails', data.data);
						}
						deferred.resolve(data.data, data.status);
					},
					failureFunc = typeof failurecb === 'function' ? failurecb : function (data) {
						// $log.log("authService.authenticate => failed : ", status);
						deferred.reject(data.data, data.status);
					};

				// 160310 kfw: if this authenticate function is called after timeout or after SignOut link is clicked, a 'deAuth'
				//     cookie should be present to represent this condition.  If present, we will inject an initial dummy
				//     dummy auth request to prime the SMCHALLENGE header. Upon completion of the re-login request, or app start, the deAuth
				//     cookie will be removed.  We only want to take this step, if a username and password are provided.  Otherwise, this is a
				//     dummy auth req. initiated by app start; let it flow.
				var deAuth = $cookies.get('deAuth');
				if (deAuth === 'loggedOut' && username && password) {
					$cookies.put('SMCHALLENGE', 'true'); //testing feature with workQ
					return $http(handler)
						.then(processAuthentication)
						.catch(processAuthentication);
				} else {
					processAuthentication();
				}

				function processAuthentication() {

					if (username === "wtadmin") {
						if (username && password) {
							var base64Credntls = "Basic " + btoa(username + ":" + password);
							handler.headers = {
								'Authorization': base64Credntls
							}
						}
					}

					function args(args) {
						var h = [];
						Object.keys(args).forEach(function (key) {
							h.push(args[key]);
						});
						return h;
					}

					$http(handler)
						.then(successFunc)
						.catch(failureFunc)
						.finally(function () {
							//pass or fail, remove the deAuth cookie
							var deAuthFinally = $cookies.get('deAuth');
							$cookies.remove('deAuth');
						});
				}

				return deferred.promise;
			}

		};


		function get_cookie(cookie_name) {
			// http://www.thesitewizard.com/javascripts/cookies.shtml
			var cookie_string = document.cookie;
			if (cookie_string.length != 0) {
				var cookie_value = cookie_string.match('(^|;)[\s]*' + cookie_name + '=([^;]*)');
				//$log.log(cookie_value)

			}
			return '';
		}

		return singleton;
	}


}
