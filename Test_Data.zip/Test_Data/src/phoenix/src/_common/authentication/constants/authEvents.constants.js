module.exports = function (app) {

	"use strict";

	/**
	 * @ngdoc object
	 * @name phx.authc.AUTH_EVENTS
	 *
	 * @description
	 *
	 */


	app.constant('AUTH_EVENTS', {

		'authenticated': 'auth.event.user.authenticated',
		'loginfailed': 'auth.event.user.loginfailed',
		'timedout': 'auth.event.user.session.timedout',
		'loginrequired': 'auth.event.user.session.loginrequired',
		'redirecttoroot': 'auth.event.user.session.redirecttoroot'

	});
};
