// require('./less/styles.less');

module.exports = function (app) {


	/**
	 * @ngdoc overview
	 * @name phx.authc
	 *
	 * @description
	 * # Phoenix Authentication Documentation
	 *
	 */

	var envConfig = require("../../../../../config/env-config")();
	var commonModule = require('_common/common.js'),
		authcModule = angular.module('phx.authc', [commonModule.name, envConfig.name]);


	require('./constants/authEvents.constants.js')(authcModule);
	require('./controllers/auth-controller.js')(authcModule);
	require('./services/auth-service.js')(authcModule);
	require('./services/user-service.js')(authcModule);
	//require('./interceptors/auth-interceptor.js')(authcModule);

	/**
	 * HTTP Config starts here
	 */

	/*authcModule.config(['$httpProvider', function ($httpProvider) {
		$httpProvider.interceptors.push('httpAuthInterceptor');
	}]);*/
	authcModule.run(function ($rootScope) {
		$rootScope.spinner = false;
		$rootScope.$on('loaderOn', function (event, data) {
			$rootScope.spinner = true;
		});
		$rootScope.$on('loaderOff', function (event, data) {
			$rootScope.spinner = false;
		});
	});

	authcModule.config(function ($httpProvider) {
		console.log('configuring');

		$httpProvider.interceptors.push(function ($rootScope, $q) {
			function request(request) {
				$rootScope.$broadcast('loaderOn', {});
				return request;
			}


			function response(response) {
				$rootScope.$broadcast("loaderOff", {});
				return response;
			}



			function requestError(requestError) {
				$rootScope.$broadcast("loaderOff", {});
				return requestError;

			}

			function responseError(rejection) {
				$rootScope.$broadcast("loaderOff", {});
				 return $q.reject(rejection);
			}

			return {
				request: request,
				response: response,
				requestError: requestError,
				responseError: responseError
			};
		});
	});


	return authcModule;

}();
