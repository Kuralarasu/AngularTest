var routes = [
	{
		name: 'authclayout',
		parent: 'root',
		abstract: true
	},
	{
		name: 'login',
		parent: 'authclayout',
		url: '/login',
		views: {
			'applicationContainer@': {
				template: require('html!./views/login-page.html'),
				controller: ['authService', function (authService) {
					authService.initiateLoginProcess();
				}],
				controllerAs: 'authCtrl'
			}
		}
	}
];

module.exports = routes;
