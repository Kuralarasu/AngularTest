/**
 * Created by ramor11 on 4/20/2016.
 *
 * This will load the SVG sprites into the document body to be used within the site,
 * the sprite needs to be loaded into the body, and chrome requires it need to be at the
 * top of the body.
 *
 * <https://css-tricks.com/svg-symbol-good-choice-icons/>
 * <https://css-tricks.com/using-svg/>
 *
 */

(function (angular) {
	var index = require('!!raw!./index.html');

	fetchSVG().finally(bootstrapApplication);


	function fetchSVG() {
		var initInjector = angular.injector(["ng"]),
			$http = initInjector.get("$http"),
			app = angular.module("phxApp");

		//temporary placeholder for testing
		app.constant("version", APP_INFORMATION)

		var phxRoot = document.querySelector('[phx-root], [data-phx-root]');


		/*phxRoot.setAttribute('lcp-droppable', '');
		phxRoot.setAttribute('lcp-observable', '');*/


		$(phxRoot).prepend(index);

		return $http.get("assets/svg-defs.svg").then(function (response) {
			var div = document.createElement("div");
			div.style.display = "none";
			div.innerHTML = response.data;
			document.body.insertBefore(div, document.body.childNodes[0]);
		})
	}

	function bootstrapApplication() {
		angular.bootstrap(document, ["phxApp"]);
	}

})(window.angular);
