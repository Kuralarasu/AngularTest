//simple XHR request in pure JavaScript


var $XMLHttpRequest = function () {

	var self = this;

	self.xhr;
	//callback functionality
	self.callback = function () {
	};

	if (typeof XMLHttpRequest !== 'undefined') self.xhr = new XMLHttpRequest();
	else {
		var versions = ["MSXML2.XmlHttp.5.0",
			"MSXML2.XmlHttp.4.0",
			"MSXML2.XmlHttp.3.0",
			"MSXML2.XmlHttp.2.0",
			"Microsoft.XmlHttp"]

		for (var i = 0, len = versions.length; i < len; i++) {
			try {
				self.xhr = new ActiveXObject(versions[i]);
				break;
			}
			catch (e) {
			}
		} // end for
	}

	self.xhr.addEventListener("readystatechange", function (e) {
		if (self.xhr.readyState < 4) {
			return;
		}

		if (self.xhr.status !== 200) {
			return;
		}

		// all is well
		if (self.xhr.readyState === 4) {
			var headers = ['Content-Type', 'Pragma', 'Cache-Control', 'Expires'],
				data = {
					"data": JSON.parse(self.xhr.responseText),
					"status": self.xhr.status,
					"config": {
						"headers": function () {
							var handler = {};
							headers.forEach(function (key) {
								handler[key] = self.xhr.getResponseHeader(key)
							});
							return handler;
						}()
					},
					"statusText": self.xhr.status === 200 ? "OK" : "FAILED"
				};

			self.callback(self.xhr, data);
		}

	}, false);

};


function _setRequestHeaders(config) {
	var _this = this;
	if (config && config.headers) {
		var headers = config.headers;
		Object.keys(headers).forEach(function (h) {
			_this.xhr.setRequestHeader(h, headers[h]);
		})
	}
}

function _setRequestParams(url, config) {

	var _this = this;
	if (config && config.params) {
		var params = config.params,
			urlEncode = [];
		Object.keys(params).forEach(function (key) {
			urlEncode.push([key, params[key]].join("="))
		});

		url += '?' + urlEncode.join('&');
		var nth = 0;
		url = url.replace(/\?/g, function (match, i, original) {
			nth++;
			return (nth === 2) ? "&" : match;
		});
	}


	return url;
}

$XMLHttpRequest.prototype.get = function (url, config, callback) {

	this.callback = function (xhr, data) {
		data.config.url = url;
		data.config.method = "GET";
		return callback(xhr.status, data);
	};

	this.xhr.open('GET', _setRequestParams.apply(this, [url, config]), true);
	_setRequestHeaders.apply(this, [config])


	this.xhr.send(null);

};


module.exports = function () {
	return new $XMLHttpRequest();
}();
