

module.exports = function(app) {

	'use strict';

	var Class = jsface.Class,
		extend = jsface.extend,
		BaseCtrl = common.ctrls.BaseCtrl,
		EventDispatcher = common.events.EventDispatcher;

	var EventBusCtrl = Class([BaseCtrl, EventDispatcher], {

		constructor: function(scope) {
			this.setScope(scope);
			this.$class.$super.apply(this, arguments);
		},

		defineScope: function() {

			this.logoutEventListener = this.onLogout.bind(this);
		},

		defineListeners : function() {
			this.$class.$superp.defineListeners.call(this);

			//this.addScopeEventListener('xyz', this.logoutEventListener);
		},

		onLogout : function(event, data) {
			document.location = 'login?reason=timeout';
		}

	});


	EventBusCtrl.$inject = ['$scope'];
	app.controller('common.ctrls.EventBusCtrl', EventBusCtrl);

};
