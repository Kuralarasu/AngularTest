'use strict';

var BaseCtrl = jsface.Class({

	/**
	 * Constructor can be used to get reference to global services and factories
	 * this.defineScope() method should be used to declare all methods and
	 * properties shared externally.
	 */
	constructor : function() {
		//console.log('super constructor');
		this.defineScope();
		this.defineListeners();
	},

	/**
	 * Declare every shared methods and properties here.
	 */
	defineScope : function() {
		//console.log('super defineScope');
		// OVERRIDE
	},

	/**
	 * Include all event listeners. Use .bind(this) for event listeners to be
	 * called with Controller scope. If the listeners need to be removed
	 * (unsubscribed), use scope bound listener reference.
	 * 
	 * Ex: in defineScope() { 
	 * this.boundEventListener = this.onClickEventHandler.bind(this); 
	 * } 
	 * <br/> To subscribe, in defineListeners(): 
	 * this.addScopeEventListener('click', this.boundEventListener); 
	 * 
	 * <br/> To unsubscribe:
	 * this.removeScopeEventListener('click', this.boundEventListener);
	 */
	defineListeners : function() {
		//console.log('super defineListeners');
		/*
		 * We dont want to force child Controllers to inject $scope If $scope is
		 * injected and used to defineListeners(), we plug-in cleanup event
		 * handler if (this.$scope is not NULL)
		 */
		if (this.$scope) {
			this.$scope.$on('$destroy', this.destroy.bind(this));
		}
	},

	/**
	 * This method gets called when the scope is destroyed/unloaded from page.
	 * Child controller to implement this method for cleanup activity
	 */
	destroy : function(event) {
		// OVERRIDE
	}

});

module.exports = namespace('common.ctrls').BaseCtrl = BaseCtrl;
