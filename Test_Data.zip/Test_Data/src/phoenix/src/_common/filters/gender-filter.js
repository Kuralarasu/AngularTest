var filter =  function () {
	return function (gen) {
		if (!gen) { return ''; }

		var val = '';
		if (gen == 'F') { val = 'Female'; }
		if (gen == 'M') { val = 'Male'; }
		if (gen == 'U') { val = 'Unknown'; }
		if (gen == 'Female') { val = 'F'; }
		if (gen == 'Male') { val = 'M'; }
		if (gen == 'Unknown') { val = 'U'; }

		return val;
	};
};


module.exports = function (app) {
	app.filter('gender', filter);
};
