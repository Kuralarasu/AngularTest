var filter = function() {

	return function(value, wordwise, wordDelimiter, max, tail) {

		if (!value)
			return '';

		max = parseInt(max, 10);
		var delimiter = wordDelimiter? wordDelimiter:' ';

		if (!max)
			return value;
		if (value.length <= max)
			return value;

		value = value.substr(0, max);
		if (wordwise) {
			var lastspace = value.lastIndexOf(delimiter);
			if (lastspace != -1) {
				value = value.substr(0, lastspace);
			}
		}

		return value + (tail || '...');
	};

};

module.exports = function(app) {
	app.filter('ellipsis', filter);
};
