module.exports = function (app) {
	"use strict";

	app.filter('bytes', function () {
		
		var units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
		
		return function (bytes, precision) {
		
			if (isNaN(parseFloat(bytes)) || !isFinite(bytes)) {
				return '';
			}

			if (angular.isUndefined(precision)) {
				precision = 1;
			}

			// determine which units to use 
			var number = Math.floor(Math.log(bytes) / Math.log(1024));
			
			// return formatted string
			return (bytes / Math.pow(1024, Math.floor(number))).toFixed(precision) + ' ' + units[number];
		}
	});
};