var filter =  function () {
    return function (tel) {
        if (!tel) { return ''; }
        return '('+ (tel.areaCode || ' ')  + ') ' + ( tel.prefix || ' ' ) + '-' + ( tel.lineNumber || ' ' );
    };
};


module.exports = function (app) {
	app.filter('telephone', filter);
};
