var filter = function() {
	return function(input) {
		var options = {
			"Weekly" : "Weekly",
			"Biweekly" : "Biweekly",
			"Monthly" : "Monthly",
			"Unknown" : "Unknown",
			"EndOfMonth" : "End Of Month"
		};

		var returnVal = '';
		if (input && options[input]) {
			returnVal = options[input];
		}

		return returnVal;
	}

};

module.exports = function(app) {
	app.filter('billingfrequency', filter);
}
