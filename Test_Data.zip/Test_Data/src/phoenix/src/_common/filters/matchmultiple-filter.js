// Select items based on multiple values
// For example, on the Eligibility Verification response (271), this filter
// is used to allow the user to filter column contents by selecting multiple terms.

// Arguments:
// "input" is provided
// "searchTerms" is an object containing the terms for each column
// "searchTermsBase" is the initial (empty) set of terms (used to compare searchTerms to see if it has changed)

var filter = function() {
	return function(input, searchTerms, searchTermsBase) {
		if (!input) {
			return;
		} else if (!searchTerms || searchTerms.length == 0 || angular.equals(searchTerms, searchTermsBase)) {
			return input;
		} else {
			var items = {
				searchTerms: {},
				searchTermProps: [],
				searchTermsLength: 0,
				matched: []
			};
			// Collect populated searchTerms fields in items.searchTerms:
			for ( var prop in searchTerms ) {
				if ( searchTerms.hasOwnProperty( prop ) && searchTerms[prop].length ) {
					items.searchTerms[prop] = searchTerms[prop];
					items.searchTermProps.push(prop);
					items.searchTermsLength++;
				}
			}

			//console.log('matchmultiple searchTerms', searchTerms);
			//console.log('matchmultiple items.searchTerms', items.searchTerms);
			//console.log('matchmultiple items.searchTermProps', items.searchTermProps);
			//console.log('matchmultiple items.searchTermsLength', items.searchTermsLength);
			//console.log('matchmultiple input length', input.length);

			// iterate over each input (e.g., a row in the 271 Benefits Info table):
			angular.forEach(input, function (value, key) {

				//console.group('matchmultiple input ' + key);
				//console.log('value', value);
				//console.log('key', key);

				var columnsMatched = 0;
				// iterate over each searchTerms item:
				for ( var i = 0; i < items.searchTermsLength; i++ ) { // searchTermsLength should equal searchTermProps.length
					var column = items.searchTermProps[i];
					var columnFilters = items.searchTerms[column];

					//console.group('searchTerms item ' + i);
					//console.log('column:', column);
					//console.log('columnFilters', columnFilters);
					//console.log('value[column]:', value[column]);

					// iterate over each term in the columnFilters item array:
					for ( var j = 0, columnFiltersLength = columnFilters.length; j < columnFiltersLength; j++ ) {
						//console.group('columnFilter ' + j);
						var matchFound = value[column].indexOf(columnFilters[j].name) > -1;

						//console.log('searching for term:', columnFilters[j].name);
						//console.log('matchFound:', matchFound);
						//console.groupEnd('columnFilter ' + j);

						if ( matchFound ) {
							columnsMatched++;
							if ( columnsMatched == items.searchTermsLength ) {
								items.matched.push(value);
							}
						}
					}
					//console.groupEnd('searchTerms item ' + i);
				}
				//console.groupEnd('matchmultiple input ' + key);
			}, items);

			return items.matched;
		}
	};
};

module.exports = function (app) {
	app.filter('matchmultiple', filter);
};
