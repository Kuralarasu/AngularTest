// Convert a date string from YYYY-MM-DD to MM/DD/YYYY

var filter = function() {
	return function (input) {
		if (!input) return "";
		var d = input.split('-');
		return d[1] + '/' + d[2] + '/' + d[0];
	};
}

module.exports = function (app) {
	app.filter('date2mmddyyyy', filter);
}
