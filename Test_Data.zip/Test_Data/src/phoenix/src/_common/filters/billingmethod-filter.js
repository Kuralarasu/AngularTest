var filter = function() {
	return function(input) {
		var options = {
            "Medicare" : "MC",
            "Client": "CM",
            "Medicaid" : "MD",
            "Patient" : "PT",
            "Private" : "PI"
		};

		var returnVal = '';
		if (input && options[input]) {
			returnVal = options[input];
		}

		return returnVal;
	}

};

module.exports = function(app) {
	app.filter('billingmethod', filter);
}
