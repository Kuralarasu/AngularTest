var filter = function() {
  return function(input) {
    
	var date = new Date(input);
    input = input || '';
    if(!input) throw 'Invalid Date ' + input;
    
    var _utc = new Date(date.getUTCFullYear(), date.getUTCMonth(), 
    		date.getUTCDate(),  date.getUTCHours(), 
    		date.getUTCMinutes(), date.getUTCSeconds());

    return _utc;
};

module.exports = function(app) {
	app.filter('date2utc', filter);
}
  
  
   