module.exports = namespace('common.events').EventDispatcher = function () {
	'use strict';

	var Class = jsface.Class;

	return Class(function () {

		/**
		 * Private method to be re-used within this class.
		 * Removes listener from array of namedListeners
		 *
		 * listener should be of the same reference as it was used to subscribe,
		 * otherwise, it will not be removed from the list.
		 */
		var _removeEventListener = function (listeners, name, listener) {
			if (listeners) {
				var index = listeners.indexOf(listener);
				if (index !== -1) {
					listeners.splice(index, 1);
				}
			}
		};

		return {

			setScope: function (scope) {
				this.$scope = scope;
			},

			setRootScope: function (rootScope) {
				this.$rootScope = rootScope;
			},

			/**
			 * Add a listener on the object
			 *
			 * @param type : Event name
			 * @param listener : Listener callback
			 *
			 * returns cleanUpFunction -- call fn() to unsubscribe
			 */
			addScopeEventListener: function (name, listener) {
				this.$scope.$on(name, listener);
			},

			/**
			 * Remove a listener on the object
			 *
			 * @param type : Event name
			 * @param listener : Listener callback
			 */
			removeScopeEventListener: function (name, listener) {
				var namedListeners = this.$scope.$$listeners[name];
				_removeEventListener(namedListeners, name, listener);
			},

			broadcastScopeEvent: function (name, config) {
				this.$rootScope.$broadcast(name, config);
			},

			emitScopeEvent: function (name, config) {
				this.$rootScope.$emit(name, config);
			},

			addRootScopeEventListener: function (name, listener) {
				this.$rootScope.$on(name, listener);
			},

			removeRootScopeEventListener: function (name, listener) {
				var namedListeners = this.$rootScope.$$listeners[name];
				_removeEventListener(namedListeners, name, listener);
			},

			broadcastRootScopeEvent: function (name, config) {
				this.$rootScope.$broadcast(name, config);
			},

			emitRootScopeEvent: function (name, config) {
				this.$rootScope.$emit(name, config);
			}

		};

	});
}();
