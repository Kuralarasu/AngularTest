/**
 * Refer: http://taoofcode.net/studying-the-angular-injector-loading-modules/
 * Refer: https://github.com/packetloop/angular-webpack
 *
 *
 * @param phxApp
 *
 */

module.exports = function (phxApp) {
	'use strict';


	/**
	 * @ngdoc service
	 * @name phxApp.provider:lcpLazyLoaderProvider
	 *
	 * @description
	 *
	 * Lazy Loads Angular modules and its components when the JS file is downloaded to the browser.
	 * Each JS file downloaded, on-demand is expected to be an AngularJS module. Any components (contrller, service, etc)
	 * would need to be added into an angular module and delivered to the UI.
	 *
	 * phxApp.register will be called during 'resolve' method of 'ui-router' state to initialize the module into phxApp
	 * main module.
	 *
	 */






	phxApp.run(['lcpLazyLoader', function (lcpLazyLoader) {
		return lcpLazyLoader;
	}]).provider('lcpLazyLoader', LazyLoaderConfig);

	function LazyLoaderConfig() {
		phxApp.register = angular.noop;




		this.currentModule = null;

		/**
		 * @ngdoc service
		 * @name phxApp.lcpLazyLoader
		 *
		 * @requires $document
		 * @requires $ocLazyLoad
		 *
		 * @description
		 *
		 * Lazy Loads Angular modules and its components when the JS file is downloaded to the browser.
		 * Each JS file downloaded, on-demand is expected to be an AngularJS module. Any components (contrller, service, etc)
		 * would need to be added into an angular module and delivered to the UI.
		 *
		 * phxApp.register will be called during 'resolve' method of 'ui-router' state to initialize the module into phxApp
		 * main module.
		 *
		 */


		this.$get = ['$document', '$ocLazyLoad', function ($document, $ocLazyLoad) {

			var getClass = function (state, name) {
				if (!name)return;
				setTimeout(function () {
					var body = angular.element($document[0].body),
						_class = name.replace(/\./g, '_');


					body[state](_class);
				})
			};

			/**
			 * @ngdoc function
			 * @name phxApp.lcpLazyLoader#register
			 * @methodOf phxApp.lcpLazyLoader
			 *
			 * @description
			 *
			 *
			 */


			phxApp.register = function (module) {

				var _this = this;


				getClass.apply(_this, ['removeClass', _this.currentModule])

				//if the module has dependencies, recursively include those dependencies
				module.requires.forEach(function (moduleName) {
					// Skip if the module is already registered.
					// AngularJS throws an error otherwise
					if (!(phxApp.requires.indexOf(moduleName) > -1)) {
						$ocLazyLoad.inject(moduleName);
						// phxApp.register(angular.module(moduleName));
					} else {
						console.log('module:', moduleName, 'found in phxApp, skipping.... ');
					}

				});

				console.log('module._invokeQueue ---- ',
					module._invokeQueue.map(function (ary) {
						return ary[2][0]
					}));


				return $ocLazyLoad.load({name: module.name}).finally(function () {
					_this.currentModule = module.name;
					getClass.apply(_this, ['addClass', _this.currentModule]);
				})
			};

			return angular.noop;
		}];

	}
};
