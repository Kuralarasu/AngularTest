### WORKING PROGRESS

Adding different environment files to be used during development but ignore on webpack build and replace with production file.
