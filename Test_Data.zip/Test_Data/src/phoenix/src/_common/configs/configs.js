module.exports = function (app) {
	'use strict';



	app.config(appConfig);


	appConfig.$inject = ['hotkeysProvider', '$mdThemingProvider', '$provide'];

	function appConfig(hotkeysProvider, $mdThemingProvider, $provide) {
		hotkeysProvider.includeCheatSheet = false;
		hotkeysProvider.useNgRoute = false;


		var debug = eval(location.search.split('debug=')[1] || location.hash.split('debug=')[1]),
			loggingEnabled = typeof(debug) === 'boolean' ? debug : (typeof(debug) === 'undefined' ? (typeof PRODUCTION_ENVIRONMENT === 'undefined' ? true : false) : debug);


		var customPrimary = {
			'50': '#a1d9e4',
			'100': '#8dd1df',
			'200': '#7ac9d9',
			'300': '#66c1d3',
			'400': '#52b9ce',
			'500': '#3eb1c8',
			'600': '#34a2b8',
			'700': '#2f91a4',
			'800': '#297f90',
			'900': '#236e7d',
			'A100': '#b5e1ea',
			'A200': '#c9e9f0',
			'A400': '#ddf1f5',
			'A700': '#1e5c69'
		};


		$mdThemingProvider.definePalette('customPrimary', customPrimary);
		$mdThemingProvider.theme('default').primaryPalette('customPrimary');

		/**
		 * This is a decorator to disable $log in production.
		 * The user can display $log if query string ?debug=true
		 */
		$provide.decorator('$log', ["$delegate", function ($delegate) {
			var events = ['log', 'info', 'warn', 'error', 'debug'],
				// console = window.console || {},
				//Save the original $log[type]()
				$Fn = function () {
					var h = [];
					events.forEach(function (e) {
						h[e] = $delegate[e];
					});
					return h;
				}();

			events.forEach(function (e) {
				$delegate[e] = function () {
					var args = !loggingEnabled ? null : [].slice.call(arguments);
					$Fn[e].apply(null, args)
				};
				//only in production
				// if(!loggingEnabled)console[e] = angular.noop;
			});

			return $delegate;
		}]);


	}

};
