module.exports = function (app) {
	"use strict";

	/**
	 * @ngdoc service
	 * @name phx.common.phxCommonUtilities
	 *
	 *
	 * @requires $rootScope
	 *
	 * @description
	 *
	 */

	app.factory('phxCommonUtilities', UtilitiesFactory);

	UtilitiesFactory.$inject = ['$rootScope'];

	function UtilitiesFactory($rootScope) {

		var utilities = {};


		String.prototype.capitalize = function () {
			return this.replace(/(?:^|\s)\S/g, function (a) {
				return a.toUpperCase();
			});
		};


		utilities.addEvent = function (elem, type, eventHandle) {
			if (elem == null || typeof(elem) == 'undefined') return;
			if (elem.addEventListener) {
				elem.addEventListener(type, eventHandle, false);
			} else if (elem.attachEvent) {
				elem.attachEvent("on" + type, eventHandle);
			} else {
				elem["on" + type] = eventHandle;
			}
		}

		utilities.upTo = function (el, tagName) {
			tagName = tagName.toLowerCase();
			while (el && el.parentNode) {
				el = el.parentNode;
				if (el.tagName && el.tagName.toLowerCase().indexOf(tagName) > -1) {
					return el;
				}
			}
			return null;
		}


		utilities.scrub = function (obj) {
			Object.keys(obj).forEach(function (key) {
				if (typeof obj[key] === 'object')
					scrub(obj[key])
				if (utilities.empty(obj[key]))
					delete obj[key];
			});
			return obj;
		}

		utilities.grep = function (elems, callback, invert) {
			var callbackInverse,
				matches = [],
				i = 0,
				length = elems.length,
				callbackExpect = !invert;

			// Go through the array, only saving the items
			// that pass the validator function
			for (; i < length; i++) {
				callbackInverse = !callback(elems[i], i);
				if (callbackInverse !== callbackExpect) {
					matches.push(elems[i]);
				}
			}

			return matches;
		}

		utilities.safeApply = function (fn) {
			var phase = $rootScope.$root.$$phase;
			if (phase == '$apply' || phase == '$digest') {
				if (fn && (typeof(fn) === 'function')) {
					fn();
				}
			} else {
				$rootScope.$apply(fn);
			}
		};

		/**
		 * Merge parameterized strings and arguments. Used on EV271 and possibly parameterized server messages
		 * Example
		 *   var arg1 = 'first value';
		 *   var arg2 = 'second value';
		 *   var string2 = sprintf('this string replaces %s and %s.', arg1, arg2);
		 *   --> string2 will equal: 'this string replaces first value and second value.'
		 *
		 *   @param array : first element is parameterized string, remaining elements are args in order of use
		 */
		utilities.sprintf = function (format) {
			if (!format) {
				return;
			}

			//var format = args[0];
			for (var i = 1; i < arguments.length; i++) {
				format = format.replace(/%s/, arguments[i]);
			}

			return format;
		};

		/*
		 * Remove parameter tags from parameterized messages.
		 *
		 * @param string
		 */
		utilities.parseMsgText = function (msgText) {
			return msgText.replace(/(\{[\d]{1,3}\})/g, '');
		};

		/**
		 * Test the validity of an object key in reference
		 * Example
		 * old way of doing things
		 * if(obj.key.exist)
		 *
		 * new way : getObjData(obj, 'key.exist'); return boolean
		 *
		 * @param obj
		 * @param string
		 * @returns {boolean}
		 */
		utilities.getObjData = function (obj, string) {

			if(typeof string !== 'string')return false;

			var re = /\[|\]|\./g,
				jsonParts = string.trim().split(re),
				result = "";

			jsonParts = jsonParts.filter(function (v) {
				return v !== ''
			});


			if (obj && jsonParts.length > 0 && obj.hasOwnProperty(jsonParts[0])) {
				result = obj[jsonParts[0]];
				jsonParts.splice(0, 1);
				if (jsonParts.length > 0)
					result = utilities.getObjData(result, jsonParts.join('.'));
			}

			return result;
		}

		utilities.getPosition = function (ele, parent) {
			var rect = ele[0] ? ele[0].getBoundingClientRect() : ele.getBoundingClientRect(),
				prect = parent ? (parent[0] ? parent[0].getBoundingClientRect() : parent.getBoundingClientRect()) : null;

			if (!parent) {
				prect.top = document.documentElement.clientTop;
				prect.left = document.documentElement.clientLeft;
			}

			var rectTop = rect.top + window.pageYOffset - prect.top;
			var rectLeft = rect.left + window.pageXOffset - prect.left;

			return {top: rectTop, left: rectLeft};

		}


		utilities.getDocumentHeight = function () {
			if (document.viewport && document.viewport.getHeight() > 0) {
				return document.viewport.getHeight();
			}
			if (document.all) {
				return document.body.offsetHeight;
			}
			if (document.layers) {
				return window.innerHeight;
			}
			if (document.getElementById) {
				return window.innerHeight;
			}
			return 0;
		}

		utilities.getDocumentWidth = function () {
			if (document.viewport && document.viewport.getWidth() > 0) {
				return document.viewport.getWidth();
			}
			if (document.all) {
				return document.body.offsetWidth;
			}
			if (document.layers) {
				return window.innerWidth;
			}
			if (document.getElementById) {
				return window.innerWidth;
			}
			return 0;
		}

		utilities.isIE8orlower = function () {

			var msg = "0";
			var ver = this.getInternetExplorerVersion();
			if (ver > -1) {
				if (ver >= 9.0)
					msg = 0
				else
					msg = 1;
			}
			return msg;
			// alert(msg);
		}
		/**
		 * @ngdoc function
		 * @name phxCommonUtilities#getBoolean
		 * @methodOf phx.common.phxCommonUtilities
		 * @kind function
		 *
		 * @description
		 * Return configSetting from init request call
		 *
		 * @param {Object} value to test
		 * @returns {boolean} return a true or false
		 *
		 */
		utilities.getBoolean = function (value) {
			if (typeof value === 'undefined' || value === null) {
				value = false;
			}

			if (typeof value != 'boolean') {
				switch (value.toString().toLowerCase()) {
					case 'true':
					case 'yes':
					case 'ok':
					case '1':
						value = true;
						break;

					case 'false':
					case 'no':
					case 'failed':
					case '0':
						value = false;
						break;

					default:
						value = new Boolean(value).valueOf();
						break
				}
			}
			return value;
		}
		/**
		 * @ngdoc function
		 * @name phxCommonUtilities#arrayUnique
		 * @methodOf phx.common.phxCommonUtilities
		 *
		 * @description
		 * Send a mix array of values to get unique array by key
		 *
		 * @param {Object|Array} array todo more notes
		 * @returns {Object|Array} array todo more notes
		 */
		utilities.arrayUnique = function (array) {
			var a = array.concat();
			for (var i = 0; i < a.length; ++i) {
				for (var j = i + 1; j < a.length; ++j) {
					if (a[i] === a[j]) {
						a.splice(j--, 1);
					}
				}
			}
			return a;
		}
		/**
		 * @ngdoc function
		 * @name phxCommonUtilities#arrayIntersection
		 * @methodOf phx.common.phxCommonUtilities
		 *
		 * @description
		 * Merge two array into one
		 *
		 * @param {ArrayObject|Array} x todo more notes
		 * @param {ArrayObject|Array} y todo more notes
		 * @returns {ArrayObject|Array} get one array
		 */
		utilities.arrayIntersection = function (x, y) {
			var ret = [];
			for (var i = 0; i < x.length; i++) {
				for (var z = 0; z < y.length; z++) {
					if (x[i] == y[z]) {
						ret.push(i);
						break;
					}
				}
			}
			return ret;
		}
		/**
		 * @ngdoc function
		 * @name phxCommonUtilities#isEmpty
		 * @methodOf phx.common.phxCommonUtilities
		 *
		 * @description
		 * This function checks if an object is empty
		 *
		 * EXAMPLE USES:
		 * isEmpty("") // True
		 * isEmpty([]) // True
		 * isEmpty({}) // True
		 * isEmpty({length: 0, custom_property: []}) // True
		 * isEmpty("Hello") // False
		 * isEmpty([1,2,3]) // False
		 * isEmpty({test: 1}) // False
		 * isEmpty({length: 3, custom_property: [1,2,3]}) // False
		 *
		 * @returns {boolean} boolean
		 */
		utilities.empty = function (mixed_var) {
			//  discuss at: http://phpjs.org/functions/empty/
			// original by: Philippe Baumann
			//    input by: Onno Marsman
			//    input by: LH
			//    input by: Stoyan Kyosev (http://www.svest.org/)
			// bugfixed by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
			// improved by: Onno Marsman
			// improved by: Francesco
			// improved by: Marc Jansen
			// improved by: Rafal Kukawski
			//   example 1: empty(null);
			//   returns 1: true
			//   example 2: empty(undefined);
			//   returns 2: true
			//   example 3: empty([]);
			//   returns 3: true
			//   example 4: empty({});
			//   returns 4: true
			//   example 5: empty({'aFunc' : function () { alert('humpty'); } });
			//   returns 5: false

			var undef, key, i, len;
			var emptyValues = [undef, null, false, 0, '', '0'];

			for (i = 0, len = emptyValues.length; i < len; i++) {
				if (mixed_var === emptyValues[i]) {
					return true;
				}
			}

			if (typeof mixed_var === 'object') {
				for (key in mixed_var) {
					// TODO: should we check for own properties only?
					//if (mixed_var.hasOwnProperty(key)) {
					return false;
					//}
				}
				return true;
			}

			return false;
		}
		/**
		 * @ngdoc function
		 * @name phxCommonUtilities#isValidEmail
		 * @methodOf phx.common.phxCommonUtilities
		 *
		 * @description
		 * Test if email send passes regular expression if its a valid email
		 *
		 * @returns {boolean} boolean
		 */
		utilities.isValidEmail = function (email) {
			var re =
				/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			return re.test(email);
		}
		/**
		 * This function is here to deal with an issue that
		 *
		 TEMPORARY FIX, angular.copy() is supposed to strip out the hashKey values, but currently is not.
		 There is a pull request,
		 https://github.com/angular/angular.js/pull/2423
		 https://github.com/angular/angular.js/pull/2382
		 *
		 */
		function isWindow(obj) {
			return obj && obj.document && obj.location && obj.alert && obj.setInterval;
		}

		function isScope(obj) {
			return obj && obj.$evalAsync && obj.$watch;
		}

		/**
		 * @ngdoc function
		 * @name phxCommonUtilities#preventDefault
		 * @methodOf phx.common.phxCommonUtilities
		 *
		 * @description
		 * Stops event.stopPropagation() for the passing element
		 *
		 * @param {element} event todo more notes
		 */
		utilities.preventDefault = function (event) {

			event.preventDefault();

			if (event && event.stopPropagation) {
				event.stopPropagation();
			} else {
				event = window.event;
				event.cancelBubble = true;
			}
		}

		utilities.str_replace = function (search, replace, subject, count) {
			//  discuss at: http://phpjs.org/functions/str_replace/
			// original by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
			// improved by: Gabriel Paderni
			// improved by: Philip Peterson
			// improved by: Simon Willison (http://simonwillison.net)
			// improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
			// improved by: Onno Marsman
			// improved by: Brett Zamir (http://brett-zamir.me)
			//  revised by: Jonas Raoni Soares Silva (http://www.jsfromhell.com)
			// bugfixed by: Anton Ongson
			// bugfixed by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
			// bugfixed by: Oleg Eremeev
			//    input by: Onno Marsman
			//    input by: Brett Zamir (http://brett-zamir.me)
			//    input by: Oleg Eremeev
			//        note: The count parameter must be passed as a string in order
			//        note: to find a global variable in which the result will be given
			//   example 1: str_replace(' ', '.', 'Kevin van Zonneveld');
			//   returns 1: 'Kevin.van.Zonneveld'
			//   example 2: str_replace(['{name}', 'l'], ['hello', 'm'], '{name}, lars');
			//   returns 2: 'hemmo, mars'
			// bugfixed by: Glen Arason (http://CanadianDomainRegistry.ca)
			//   example 3: str_replace(Array('S','F'),'x','ASDFASDF');
			//   returns 3: 'AxDxAxDx'
			// bugfixed by: Glen Arason (http://CanadianDomainRegistry.ca) Corrected count
			//   example 4: str_replace(['A','D'], ['x','y'] , 'ASDFASDF' , 'cnt');
			//   returns 4: 'xSyFxSyF' // cnt = 0 (incorrect before fix)
			//   returns 4: 'xSyFxSyF' // cnt = 4 (correct after fix)

			var i = 0,
				j = 0,
				temp = '',
				repl = '',
				sl = 0,
				fl = 0,
				f = [].concat(search),
				r = [].concat(replace),
				s = subject,
				ra = Object.prototype.toString.call(r) === '[object Array]',
				sa = Object.prototype.toString.call(s) === '[object Array]';
			s = [].concat(s);

			if (typeof(search) === 'object' && typeof(replace) === 'string') {
				temp = replace;
				replace = new Array();
				for (i = 0; i < search.length; i += 1) {
					replace[i] = temp;
				}
				temp = '';
				r = [].concat(replace);
				ra = Object.prototype.toString.call(r) === '[object Array]';
			}

			if (count) {
				this.window[count] = 0;
			}

			for (i = 0, sl = s.length; i < sl; i++) {
				if (s[i] === '') {
					continue;
				}
				for (j = 0, fl = f.length; j < fl; j++) {
					temp = s[i] + '';
					repl = ra ? (r[j] !== undefined ? r[j] : '') : r[0];
					s[i] = (temp).split(f[j]).join(repl);
					if (count) {
						this.window[count] += ((temp.split(f[j])).length - 1);
					}
				}
			}
			return sa ? s : s[0];
		}

		utilities.basename = function (path, suffix) {
			//  discuss at: http://phpjs.org/functions/basename/
			// original by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
			// improved by: Ash Searle (http://hexmen.com/blog/)
			// improved by: Lincoln Ramsay
			// improved by: djmix
			// improved by: Dmitry Gorelenkov
			//   example 1: basename('/www/site/home.htm', '.htm');
			//   returns 1: 'home'
			//   example 2: basename('ecra.php?p=1');
			//   returns 2: 'ecra.php?p=1'
			//   example 3: basename('/some/path/');
			//   returns 3: 'path'
			//   example 4: basename('/some/path_ext.ext/','.ext');
			//   returns 4: 'path_ext'

			var b = path;
			var lastChar = b.charAt(b.length - 1);

			if (lastChar === '/' || lastChar === '\\') {
				b = b.slice(0, -1);
			}

			b = b.replace(/^.*[\/\\]/g, '');

			if (typeof suffix === 'string' && b.substr(b.length - suffix.length) ==
				suffix) {
				b = b.substr(0, b.length - suffix.length);
			}

			return b;
		}

		utilities.pathinfo = function (path, options) {
			//  discuss at: http://phpjs.org/functions/pathinfo/
			// original by: Nate
			//  revised by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
			// improved by: Brett Zamir (http://brett-zamir.me)
			// improved by: Dmitry Gorelenkov
			//    input by: Timo
			//        note: Inspired by actual PHP source: php5-5.2.6/ext/standard/string.c line #1559
			//        note: The way the bitwise arguments are handled allows for greater flexibility
			//        note: & compatability. We might even standardize this code and use a similar approach for
			//        note: other bitwise PHP functions
			//        note: php.js tries very hard to stay away from a core.js file with global dependencies, because we like
			//        note: that you can just take a couple of functions and be on your way.
			//        note: But by way we implemented this function, if you want you can still declare the PATHINFO_*
			//        note: yourself, and then you can use: pathinfo('/www/index.html', PATHINFO_BASENAME | PATHINFO_EXTENSION);
			//        note: which makes it fully compliant with PHP syntax.
			//  depends on: basename
			//   example 1: pathinfo('/www/htdocs/index.html', 1);
			//   returns 1: '/www/htdocs'
			//   example 2: pathinfo('/www/htdocs/index.html', 'PATHINFO_BASENAME');
			//   returns 2: 'index.html'
			//   example 3: pathinfo('/www/htdocs/index.html', 'PATHINFO_EXTENSION');
			//   returns 3: 'html'
			//   example 4: pathinfo('/www/htdocs/index.html', 'PATHINFO_FILENAME');
			//   returns 4: 'index'
			//   example 5: pathinfo('/www/htdocs/index.html', 2 | 4);
			//   returns 5: {basename: 'index.html', extension: 'html'}
			//   example 6: pathinfo('/www/htdocs/index.html', 'PATHINFO_ALL');
			//   returns 6: {dirname: '/www/htdocs', basename: 'index.html', extension: 'html', filename: 'index'}
			//   example 7: pathinfo('/www/htdocs/index.html');
			//   returns 7: {dirname: '/www/htdocs', basename: 'index.html', extension: 'html', filename: 'index'}

			var opt = '',
				real_opt = '',
				optName = '',
				optTemp = 0,
				tmp_arr = {},
				cnt = 0,
				i = 0;
			var have_basename = false,
				have_extension = false,
				have_filename = false;

			// Input defaulting & sanitation
			if (!path) {
				return false;
			}
			if (!options) {
				options = 'PATHINFO_ALL';
			}

			// Initialize binary arguments. Both the string & integer (constant) input is
			// allowed
			var OPTS = {
				'PATHINFO_DIRNAME': 1,
				'PATHINFO_BASENAME': 2,
				'PATHINFO_EXTENSION': 4,
				'PATHINFO_FILENAME': 8,
				'PATHINFO_ALL': 0
			};
			// PATHINFO_ALL sums up all previously defined PATHINFOs (could just pre-calculate)
			for (optName in OPTS) {
				if (OPTS.hasOwnProperty(optName)) {
					OPTS.PATHINFO_ALL = OPTS.PATHINFO_ALL | OPTS[optName];
				}
			}
			if (typeof options !== 'number') {
				// Allow for a single string or an array of string flags
				options = [].concat(options);
				for (i = 0; i < options.length; i++) {
					// Resolve string input to bitwise e.g. 'PATHINFO_EXTENSION' becomes 4
					if (OPTS[options[i]]) {
						optTemp = optTemp | OPTS[options[i]];
					}
				}
				options = optTemp;
			}

			// Internal Functions
			var __getExt = function (path) {
				var str = path + '';
				var dotP = str.lastIndexOf('.') + 1;
				return !dotP ? false : dotP !== str.length ? str.substr(dotP) : '';
			};

			// Gather path infos
			if (options & OPTS.PATHINFO_DIRNAME) {
				var dirName = path.replace(/\\/g, '/')
					.replace(/\/[^\/]*\/?$/, ''); // dirname
				tmp_arr.dirname = dirName === path ? '.' : dirName;
			}

			if (options & OPTS.PATHINFO_BASENAME) {
				if (false === have_basename) {
					have_basename = this.basename(path);
				}
				tmp_arr.basename = have_basename;
			}

			if (options & OPTS.PATHINFO_EXTENSION) {
				if (false === have_basename) {
					have_basename = this.basename(path);
				}
				if (false === have_extension) {
					have_extension = __getExt(have_basename);
				}
				if (false !== have_extension) {
					tmp_arr.extension = have_extension;
				}
			}

			if (options & OPTS.PATHINFO_FILENAME) {
				if (false === have_basename) {
					have_basename = this.basename(path);
				}
				if (false === have_extension) {
					have_extension = __getExt(have_basename);
				}
				if (false === have_filename) {
					have_filename = have_basename.slice(0, have_basename.length - (
							have_extension ? have_extension.length + 1 :
								have_extension === false ? 0 : 1));
				}

				tmp_arr.filename = have_filename;
			}

			// If array contains only 1 element: return string
			cnt = 0;
			for (opt in tmp_arr) {
				if (tmp_arr.hasOwnProperty(opt)) {
					cnt++;
					real_opt = opt;
				}
			}
			if (cnt === 1) {
				return tmp_arr[real_opt];
			}

			// Return full-blown array
			return tmp_arr;
		}

		/**
		 * Date Related Functions
		 */

		/**
		 * @ngdoc function
		 * @name phxCommonUtilities#getCondensedDateString
		 *
		 * @description
		 * converts date to YYYYMMDD format for use as Url parameter
		 *
		 * @param {Date} date to be converted
		 * @returns {string} 'YYYYMMDD'
		 */
		utilities.getCondensedDateString = function (date) {
			var d = new Date(date);
			var year = d.getFullYear().toString();
			var month = (d.getMonth() + 1).toString();
			month = month[1] ? month : "0" + month;
			var day = d.getDate().toString();
			day = day[1] ? day : "0" + day;
			return year + month + day;
		}

		/**
		 * @ngdoc function
		 * @name phxCommonUtilities#dateString
		 *
		 * @description
		 * converts date to MM/DD/YYYY format for use as string
		 *
		 * @param {Date} date to be converted
		 * @returns {string} 'MM/DD/YYYY'
		 */
		utilities.dateString = function (date) {
			return (date.getMonth() + 1) + '/' + date.getDate() + '/' + date.getFullYear();
		}

		/**
		 * @ngdoc function
		 * @name phxCommonUtilities#objectifyDate
		 *
		 * @description
		 * converts 'YYYYMMDD' string to date. Intended for deserializing Url parameter
		 *
		 * @param {string=} date 'YYYYMMDD'
		 * @returns {object=} new Data object
		 */

		utilities.objectifyDate = function (date) {
			if (typeof date === 'string') {
				var dateMatch = date.match(/(.{4})(.{2})(.{2})/);
				return new Date(parseInt(dateMatch[1]), parseInt(dateMatch[2] - 1), parseInt(dateMatch[3]));
			}

			return;
		}

		/**
		 * @ngdoc function
		 * @name phxCommonUtilities#compareDate
		 *
		 * @description
		 * compares two dates. returns 1 if date1 < date2, returns -1 if date1 > date2, and returns 0 if they are equal.
		 *
		 * @param {Date} first date for comparison
		 * @param {Date} second date for comparison
		 * @returns {Integer} -1, 0, or 1
		 */
		utilities.compareDate = function (date1, date2) {
			if (typeof date1 === 'string') {
				var dateMatch = date1.match(/(.{4})(.{2})(.{2})/);
				date1 = new Date(parseInt(dateMatch[1]), parseInt(dateMatch[2] - 1), parseInt(dateMatch[3]));
			}
			if (typeof date2 === 'string') {
				dateMatch = date2.match(/(.{4})(.{2})(.{2})/);
				date2 = new Date(parseInt(dateMatch[1]), parseInt(dateMatch[2] - 1), parseInt(dateMatch[3]));
			}

			if (date1 < date2) {
				return 1;
			}
			if (date1 > date2) {
				return -1;
			}

			return 0;
		}

		return utilities;

	}


}
