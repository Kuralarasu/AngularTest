module.exports = function () {
	"use strict";

	/**
	 * @ngdoc overview
	 * @name phx.common
	 *
	 * @description
	 * # Phoenix Common API Documentation
	 *
	 */


		//Common module has to be independent of other modules.
		//If any other module is being a dependency that needs to extracted out and added as sub module to 'common' module
	var commonModule = angular.module('phx.common', [
			'cfp.hotkeys' //needed for karma test injection dependencies
			, 'ngAnimate'
			, 'ngCookies'
			, 'ui.router'
			, 'ngResource'
			, 'cfp.hotkeys'
			, 'ngAnimate'
			, 'ngSanitize'
			, 'ngMessages'
			, 'ngMaterial'
			, 'uuid4'
			, 'oc.lazyLoad'
			, 'angular.filter'
			,'angularUtils.directives.uiBreadcrumbs'
			,'bsLoadingOverlay',
			'treasure-overlay-spinner'


			//phxModules
			, 'phxuilib.lcpInputText'
			, 'phxuilib.jarvisMenu'
		]);

	//Base Classes
	require('./configs/event-dispatcher.js');
	require('./controllers/base-controller.js');

	//TEMPLATES
	require('./templates/templates.html.js')(commonModule);

	//CONSTANTS
	require('./constants/commonEvents.constants.js')(commonModule);
	require('./constants/errorMessages.constants.js')(commonModule);


	//partials
	require('./partials/leftNavListView.controller')(commonModule);
	require('./partials/appHead.controller.js')(commonModule);
	require('./partials/app_messages/appmsg-controller.js')(commonModule);
	require('./partials/appFooter.controller.js')(commonModule);

	//filters
	require('./filters/billingfrequency-filter.js')(commonModule);
	require('./filters/billingmethod-filter.js')(commonModule);
	require('./filters/ellipsis-filter.js')(commonModule);
	require('./filters/date2mmddyyyy-filter.js')(commonModule);
	require('./filters/matchmultiple-filter.js')(commonModule);
	require('./filters/phone-number.js')(commonModule);
	require('./filters/bytes.js')(commonModule);
	require('./filters/gender-filter.js')(commonModule);

	//directives
	require('./directives/lcp-selectbox-directive.js')(commonModule);
	require('./directives/lcp-file-upload.js')(commonModule);
	require('./directives/showall-tabs-directive.js')(commonModule);
	require('./directives/progressbar-directive.js')(commonModule);
	require('./directives/logout-link-directive.js')(commonModule);
	require('./directives/lcp-click-upload.js')(commonModule);
	require('./directives/lcp-regex-replace-pattern.js')(commonModule);
	require('./directives/lcp-pattern-replace.js')(commonModule);
	require('./directives/lcp-email-pattern-directive.js')(commonModule);
	require('./directives/lcp-scroll-container-directive.js')(commonModule);
	require('./directives/jrv-sidebar.js')(commonModule);
	require('./directives/wh-offset.js')(commonModule);

	//form components directive
	//for interceptor for validation
	require('./directives/lcp-form.js')(commonModule);
	require('./directives/lcp-form-submit-directive.js')(commonModule);
	//required template injector
	require('./directives/lcp-numbers-only.js')(commonModule);

	//Rules editor specific drowdowns
	require('./directives/dropdowns/lcp-combo-box.js')(commonModule);
	require('./directives/dropdowns/lca-dropdown-directive.js')(commonModule);

	//services
	require('./services/help-route-service.js')(commonModule);
	require('./services/spinner-service.js')(commonModule);
	require('./services/loading/loading-service.js')(commonModule);
	require('./services/modal-service.js')(commonModule);
	require('./services/lcp-dragger.js')(commonModule);
	require('./services/lcp-transformer.js')(commonModule);
	require('./services/ui-manager-service.js')(commonModule);
	require('./services/rest-url-service.js')(commonModule);
	require('./services/electron/electron.provider.js')(commonModule);
	require('./services/msg-history-service.js')(commonModule);
	require('./services/state-service.js')(commonModule);
	require('./services/sidebar-service.js')(commonModule);
	//INJECT ELECTRON BRIDGE CONTROLLERS
	require('./services/electron/angular.electron.bridge.js')(commonModule);
	require('./services/loki.service')(commonModule);

	//provider
	require('./provider/message-service/message-service.js')(commonModule);
	//require('./provider/session-interval/session-interval.js')(commonModule);
	require('./provider/WebWorker$http.provider.js')(commonModule);

	//factory
	require('./factory/utilities.js')(commonModule);
	commonModule.run(['$templateCache', function ($templateCache) {
		$templateCache.put('loading-overlay-template.html', 
		'<div style="position: absolute; width: 100%; height: 100%; top: 0; left: 0; background-color: rgba(255,255,255,0.7);" class="ng-scope">'
		+'<div id="floatingCirclesG">'
        +'<div class="f_circleG" id="frotateG_01"></div>'
        +'<div class="f_circleG" id="frotateG_02"></div>'
        +'<div class="f_circleG" id="frotateG_03"></div>'
        +'<div class="f_circleG" id="frotateG_04"></div>'
        +'<div class="f_circleG" id="frotateG_05"></div>'
        +'<div class="f_circleG" id="frotateG_06"></div>'
        +'<div class="f_circleG" id="frotateG_07"></div>'
        +'<div class="f_circleG" id="frotateG_08"></div>'
    	+'</div>'
		+'</div>'
		)
	}]);
	
	commonModule.run(function (bsLoadingOverlayService) {
		bsLoadingOverlayService.setGlobalConfig({
			delay: 0, // Minimal delay to hide loading overlay in ms.
			templateUrl: 'loading-overlay-template.html'
    });
});

	return commonModule;

}();
