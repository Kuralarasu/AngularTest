module.exports = function (app) {

	require("./login.less");


	'use strict';


	app.controller('LoginCtrl', LoginCtrl);

	LoginCtrl.$inject = ['$document'];

	function LoginCtrl($document) {

		console.log("logIn controller");

		var self = this;

		self.loginForm = {
			formPostUrl: '',
			USER: 'user',
			PASSWORD: 'user',
			TARGET: '/web-ui/',
			SMENC: 'iso-8859-1',
			SMAUTHREASON: "0"
		};

		self.loginResponse = {};


		self.doLogin = function () {
			$document[0].forms["login-form"].submit();
			alert('this is do login ');
		};


		self.onLoginFormLoad = function () {
			
			var _msgObj;
			if (location.search) {

				var params = location.search.replace('?', '');
				var tokens = params.split('&');
				var paramsMap = {};
				angular.forEach(tokens, function (token) {
					var keyVal = token.split('=');
					paramsMap[keyVal[0] || ''] = keyVal[1] || '';
				});

				if (paramsMap['reason'] && paramsMap['reason'] === 'logout') {
					_msgObj = {error: 'You have successfully logged out. Please provide your credentials to log in.'};
				}

				if (paramsMap['reason'] && paramsMap['reason'] === 'timeout') {
					_msgObj = {error: 'Your session timed out. Please provide your credentials to log in.'};
				}
			}

			self.loginResponse = _msgObj;
		};

		self.onLoginFormLoad();

	}


};


