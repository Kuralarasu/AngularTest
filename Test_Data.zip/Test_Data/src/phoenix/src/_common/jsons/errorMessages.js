var errorMessages = {
	"271-AAA-2000A-04": {
		"message":"Authorized Quantity Exceeded: issue has been reported"
	},
	"271-AAA-INFOSRC-04": {
		"message":"Authorized Quantity Exceeded: issue has been reported"
	},
	"PHX-003": {
		"message":"error code no longer used"
	},
	"GTW-999": {
		"message":"{0}  (Indicates IIB failure of some kind): issue has been reported"
	},
	"271-AAA-SUBBNFT-AO": {
		"message":"Additional Patient Condition Information Required: RCM Eligibility Support has been notified"
	},
	"271-AAA-DEPBNFT-AO": {
		"message":"Additional Patient Condition Information Required: RCM Eligibility Support has been notified"
	},
	"PHX-008": {
		"message":"Address is invalid."
	},
	"271-AAA-SUBBNFT-AA": {
		"message":"Authorization Number Not Found: RCM Eligibility Support has been notified"
	},
	"271-AAA-DEPBNFT-AA": {
		"message":"Authorization Number Not Found: RCM Eligibility Support has been notified"
	},
	"271-AAA-INFORCVR-41": {
		"message":"Authorization/Access Restrictions: RCM Eligibility Support has been notified"
	},
	"271-AAA-INFOSRC-41": {
		"message":"Authorization/Access Restrictions: RCM Eligibility Support has been notified"
	},
	"271-AAA-2000A-41": {
		"message":"Authorization/Access Restrictions: RCM Eligibility Support has been notified"
	},
	"271-AAA-SUBBNFT-CI": {
		"message":"Certification Information Does Not Match Patient"
	},
	"271-AAA-DEPBNFT-CI": {
		"message":"Certification Information Does Not Match Patient"
	},
	"PHX-009": {
		"message":"Country code is non-numeric or invalid. {0}"
	},
	"PHX-800": {
		"message":"Database error: issue has been reported"
	},
	"271-AAA-SUBSCR-60": {
		"message":"Date of Birth Follows Date(s) of Service"
	},
	"271-AAA-SUBBNFT-60": {
		"message":"Date of Birth Follows Date(s) of Service"
	},
	"271-AAA-DEPNDT-60": {
		"message":"Date of Birth Follows Date(s) of Service"
	},
	"271-AAA-DEPBNFT-60": {
		"message":"Date of Birth Follows Date(s) of Service"
	},
	"271-AAA-SUBSCR-61": {
		"message":"Date of Death Precedes Date(s) of Service"
	},
	"271-AAA-SUBBNFT-61": {
		"message":"Date of Death Precedes Date(s) of Service"
	},
	"271-AAA-DEPNDT-61": {
		"message":"Date of Death Precedes Date(s) of Service"
	},
	"271-AAA-DEPBNFT-61": {
		"message":"Date of Death Precedes Date(s) of Service"
	},
	"271-AAA-SUBSCR-63": {
		"message":"Date of Service in Future"
	},
	"271-AAA-SUBBNFT-63": {
		"message":"Date of Service in Future"
	},
	"271-AAA-DEPNDT-63": {
		"message":"Date of Service in Future"
	},
	"271-AAA-DEPBNFT-63": {
		"message":"Date of Service in Future"
	},
	"271-AAA-SUBSCR-62": {
		"message":"Date of Service Not Within Allowable Inquiry Period"
	},
	"271-AAA-SUBBNFT-62": {
		"message":"Date of Service Not Within Allowable Inquiry Period"
	},
	"271-AAA-DEPNDT-62": {
		"message":"Date of Service Not Within Allowable Inquiry Period"
	},
	"271-AAA-DEPBNFT-62": {
		"message":"Date of Service Not Within Allowable Inquiry Period"
	},
	"271-AAA-DEPNDT-68": {
		"message":"Duplicate Patient ID Number"
	},
	"271-AAA-SUBSCR-76": {
		"message":"Duplicate Subscriber/Insured ID Number"
	},
	"271-AAA-SUBBNFT-98": {
		"message":"Experimental Service or Procedure"
	},
	"271-AAA-DEPBNFT-98": {
		"message":"Experimental Service or Procedure"
	},
	"PHX-501": {
		"message":"External Service failed.: issue has been reported"
	},
	"271-AAA-SUBSCR-56": {
		"message":"Inappropriate Date: issue has been reported"
	},
	"271-AAA-SUBBNFT-56": {
		"message":"Inappropriate Date: issue has been reported"
	},
	"271-AAA-DEPNDT-56": {
		"message":"Inappropriate Date: issue has been reported"
	},
	"271-AAA-DEPBNFT-56": {
		"message":"Inappropriate Date: issue has been reported"
	},
	"271-AAA-SUBBNFT-55": {
		"message":"Inappropriate Product/Service ID: issue has been reported"
	},
	"271-AAA-DEPBNFT-55": {
		"message":"Inappropriate Product/Service ID: issue has been reported"
	},
	"271-AAA-SUBBNFT-54": {
		"message":"Inappropriate Product/Service ID Qualifier: issue has been reported"
	},
	"271-AAA-DEPBNFT-54": {
		"message":"Inappropriate Product/Service ID Qualifier: issue has been reported"
	},
	"271-AAA-SUBBNFT-69": {
		"message":"Inconsistent with Patient's Age"
	},
	"271-AAA-DEPBNFT-69": {
		"message":"Inconsistent with Patient's Age"
	},
	"271-AAA-SUBBNFT-70": {
		"message":"Inconsistent with Patient's Gender"
	},
	"271-AAA-DEPBNFT-70": {
		"message":"Inconsistent with Patient's Gender"
	},
	"271-AAA-SUBBNFT-53": {
		"message":"Inquired Benefit Inconsistent with Provider Type: issue has been reported"
	},
	"271-AAA-DEPBNFT-53": {
		"message":"Inquired Benefit Inconsistent with Provider Type: issue has been reported"
	},
	"271-AAA-SUBBNFT-IA": {
		"message":"Invalid Authorization Number Format: issue has been reported"
	},
	"271-AAA-DEPBNFT-IA": {
		"message":"Invalid Authorization Number Format: issue has been reported"
	},
	"271-AAA-INFORCVR-97": {
		"message":"Invalid or Missing Provider Address: issue has been reported"
	},
	"271-AAA-2000A-79": {
		"message":"Invalid Participant Identification"
	},
	"271-AAA-INFOSRC-79": {
		"message":"Invalid Participant Identification"
	},
	"271-AAA-INFORCVR-79": {
		"message":"Invalid Participant Identification"
	},
	"PAT-110": {
		"message":"Invalid search combination, {0}"
	},
	"PHY-110": {
		"message":"Invalid search combination, {0}"
	},
	"271-AAA-SUBSCR-57": {
		"message":"Invalid/Missing Date(s) of Service: issue has been reported"
	},
	"271-AAA-SUBBNFT-57": {
		"message":"Invalid/Missing Date(s) of Service: issue has been reported"
	},
	"271-AAA-DEPNDT-57": {
		"message":"Invalid/Missing Date(s) of Service: issue has been reported"
	},
	"271-AAA-DEPBNFT-57": {
		"message":"Invalid/Missing Date(s) of Service: issue has been reported"
	},
	"271-AAA-SUBSCR-58": {
		"message":"Invalid/Missing Date-of-Birth: issue has been reported"
	},
	"271-AAA-DEPNDT-58": {
		"message":"Invalid/Missing Date-of-Birth: issue has been reported"
	},
	"271-AAA-SUBBNFT-AF": {
		"message":"Invalid/Missing Diagnosis Code(s): issue has been reported"
	},
	"271-AAA-DEPBNFT-AF": {
		"message":"Invalid/Missing Diagnosis Code(s): issue has been reported"
	},
	"271-AAA-DEPNDT-66": {
		"message":"Invalid/Missing Patient Gender Code: issue has been reported"
	},
	"271-AAA-DEPNDT-64": {
		"message":"Invalid/Missing Patient ID: issue has been reported"
	},
	"271-AAA-DEPNDT-65": {
		"message":"Invalid/Missing Patient Name: issue has been reported"
	},
	"271-AAA-SUBBNFT-AG": {
		"message":"Invalid/Missing Procedure Code(s): issue has been reported"
	},
	"271-AAA-DEPBNFT-AG": {
		"message":"Invalid/Missing Procedure Code(s): issue has been reported"
	},
	"271-AAA-INFORCVR-43": {
		"message":"Invalid/Missing Provider Identification: issue has been reported"
	},
	"271-AAA-SUBSCR-43": {
		"message":"Invalid/Missing Provider Identification: issue has been reported"
	},
	"271-AAA-DEPNDT-43": {
		"message":"Invalid/Missing Provider Identification: issue has been reported"
	},
	"271-AAA-INFORCVR-44": {
		"message":"Invalid/Missing Provider Name: issue has been reported"
	},
	"271-AAA-INFORCVR-46": {
		"message":"Invalid/Missing Provider Phone Number: issue has been reported"
	},
	"271-AAA-SUBSCR-45": {
		"message":"Invalid/Missing Provider Specialty: issue has been reported"
	},
	"271-AAA-DEPNDT-45": {
		"message":"Invalid/Missing Provider Specialty: issue has been reported"
	},
	"271-AAA-INFORCVR-45": {
		"message":"Invalid/Missing Provider Specialty: issue has been reported"
	},
	"271-AAA-SUBSCR-47": {
		"message":"Invalid/Missing Provider State: issue has been reported"
	},
	"271-AAA-DEPNDT-47": {
		"message":"Invalid/Missing Provider State: issue has been reported"
	},
	"271-AAA-INFORCVR-47": {
		"message":"Invalid/Missing Provider State: issue has been reported"
	},
	"271-AAA-SUBSCR-48": {
		"message":"Invalid/Missing Referring Provider Identification Number: issue has been reported"
	},
	"271-AAA-DEPNDT-48": {
		"message":"Invalid/Missing Referring Provider Identification Number: issue has been reported"
	},
	"271-AAA-INFORCVR-48": {
		"message":"Invalid/Missing Referring Provider Identification Number: issue has been reported"
	},
	"271-AAA-SUBSCR-74": {
		"message":"Invalid/Missing Subscriber/Insured Gender Code"
	},
	"271-AAA-SUBSCR-72": {
		"message":"Invalid/Missing Subscriber/Insured ID. Correct and resubmit"
	},
	"271-AAA-SUBSCR-73": {
		"message":"Invalid/Missing Subscriber/Insured Name. Correct and resubmit"
	},
	"PAT-111": {
		"message":"MDM Search Patient Call failed with unknown reason code(s): {0}: issue has been reported"
	},
	"PAT-100": {
		"message":"Minimum search criteria not met.  {0} is required"
	},
	"271-AAA-SUBBNFT-MA": {
		"message":"Missing Authorization Number: issue has been reported"
	},
	"271-AAA-DEPBNFT-MA": {
		"message":"Missing Authorization Number: issue has been reported"
	},
	"EGV-121": {
		"message":null
	},
	"EGV-203": {
		"message":"No endpoint-payer-code is mapped for the given endpoint ID.: RCM Eligibility Support has been notified"
	},
	"BEV-001": {
		"message":"No file attachment found"
	},
	"271-AAA-INFOSRC-80": {
		"message":"No Response received - Transaction Terminated: RCM Eligibility Support has been notified"
	},
	"BEV-001": {
		"message":"No valid email provided"
	},
	"EGV-201": {
		"message":"None of the vendor endpoints were successful: RCM Eligibility Support has been notified"
	},
	"PHX-007": {
		"message":"NPI is invalid, correct and resubmit"
	},
	"271-AAA-SUBSCR-35": {
		"message":"Out of Network"
	},
	"271-AAA-DEPNDT-35": {
		"message":"Out of Network"
	},
	"271-AAA-SUBSCR-71": {
		"message":"Patient Birth Date does not match that for Patient on the Database. Correct and resubmit."
	},
	"271-AAA-DEPNDT-71": {
		"message":"Patient Birth Date does not match that for Patient on the Database. Correct and resubmit."
	},
	"271-AAA-DEPNDT-67": {
		"message":"Patient Not Found. Resubmit with additional search criteria and resubmit"
	},
	"EGV-122": {
		"message":"Payer Code is required."
	},
	"271-AAA-INFOSRC-T4": {
		"message":"Payer Name or Identifier Missing: issue has been reported"
	},
	"271-AAA-INFORCVR-T4": {
		"message":"Payer Name or Identifier Missing: issue has been reported"
	},
	"EGV-200": {
		"message":"Payer Code {0} is not mapped for any Endpoint.: RCM Eligibility Support has been notified"
	},
	"PHX-100": {
		"message":"Phoenix Database System Down.: issue has been reported"
	},
	"PHX-005": {
		"message":"Phone number is invalid, {0}"
	},
	"271-AAA-INFORCVR-50": {
		"message":"Provider Ineligible for Inquiries: RCM Eligibility Support has been notified"
	},
	"271-AAA-SUBSCR-49": {
		"message":"Provider is Not Primary Care Physician: issue has been reported"
	},
	"271-AAA-DEPNDT-49": {
		"message":"Provider is Not Primary Care Physician: issue has been reported"
	},
	"271-AAA-INFORCVR-51": {
		"message":"Provider Not on File: RCM Eligibility Support has been notified"
	},
	"271-AAA-SUBSCR-51": {
		"message":"Provider Not on File: RCM Eligibility Support has been notified"
	},
	"271-AAA-DEPNDT-51": {
		"message":"Provider Not on File: RCM Eligibility Support has been notified"
	},
	"271-AAA-SUBSCR-15": {
		"message":"Required application data missing: issue has been reported"
	},
	"271-AAA-INFORCVR-15": {
		"message":"Required application data missing: issue has been reported"
	},
	"271-AAA-SUBBNFT-15": {
		"message":"Required application data missing: issue has been reported"
	},
	"271-AAA-DEPNDT-15": {
		"message":"Required application data missing: issue has been reported"
	},
	"271-AAA-DEPBNFT-15": {
		"message":"Required application data missing: issue has been reported"
	},
	"271-AAA-SUBBNFT-E8": {
		"message":"Requires Medical Review: RCM Eligibility Support has been notified"
	},
	"271-AAA-DEPBNFT-E8": {
		"message":"Requires Medical Review: RCM Eligibility Support has been notified"
	},
	"271-AAA-SUBBNFT-AE": {
		"message":"Requires Primary Care Physician Authorization: RCM Eligibility Support has been notified"
	},
	"271-AAA-DEPBNFT-AE": {
		"message":"Requires Primary Care Physician Authorization: RCM Eligibility Support has been notified"
	},
	"PHX-404": {
		"message":"Resource Not Found.: issue has been reported"
	},
	"271-AAA-SUBSCR-52": {
		"message":"Service Dates Not Within Provider Plan Enrollment: RCM Eligibility Support has been notified"
	},
	"271-AAA-SUBBNFT-52": {
		"message":"Service Dates Not Within Provider Plan Enrollment: RCM Eligibility Support has been notified"
	},
	"271-AAA-DEPNDT-52": {
		"message":"Service Dates Not Within Provider Plan Enrollment: RCM Eligibility Support has been notified"
	},
	"271-AAA-DEPBNFT-52": {
		"message":"Service Dates Not Within Provider Plan Enrollment: RCM Eligibility Support has been notified"
	},
	"PHX-006": {
		"message":"Social Security Number is invalid. Correct or remove."
	},
	"271-AAA-DEPNDT-77": {
		"message":"Subscriber Found"
	},
	"EGV-120": {
		"message":"Subscriber or Dependent input is expected."
	},
	"271-AAA-SUBSCR-75": {
		"message":"Subscriber/Insured Not Found. Correct and resubmit."
	},
	"271-AAA-SUBSCR-78": {
		"message":"Subscriber/Insured Not in Group/Plan Identified, add additional search criteria and resubmit."
	},
	"EGV-204": {
		"message":"The endpoint rejected the request.: RCM Eligibility Support has been notified"
	},
	"PHY-111": {
		"message":"The vendor returned duplicate physicians for the given NPI: RCM Eligibility Support has been notified"
	},
	"271-AAA-INFOSRC-42": {
		"message":"Unable to Respond at Current Time: RCM Eligibility Support has been notified"
	},
	"271-AAA-SUBSCR-42": {
		"message":"Unable to Respond at Current Time: RCM Eligibility Support has been notified"
	},
	"271-AAA-DEPNDT-42": {
		"message":"Unable to Respond at Current Time: RCM Eligibility Support has been notified"
	},
	"271-AAA-2000A-42": {
		"message":"Unable to Respond at Current Time: RCM Eligibility Support has been notified"
	},
	"PHX-502": {
		"message":"Unexpected data received from external service.: issue has been reported"
	},
	"271-AAA-UNKNOWN-99": {
		"message":"Unknown Error code in AAA segment.: RCM Eligibility Support has been notified"
	},
	"PHX-999": {
		"message":"Unknown/Unexpected failure.: issue has been reported"
	},
	"PHX-012": {
		"message":"LabCorp Test Number is invalid. Please provide valid labcorp test numbers."
	},
	"PHX-011": {
		"message":"Account Number is invalid. Please provide a valid account number."
	},
	"PHX-013": {
		"message":"CPT Code is invalid. Please provide a valid CPT Code."
	},
	"PHX-014": {
		"message":"Diagnosis Code is invalid. Please provide a valid diagnosis code."
	},
	"PHX-015": {
		"message":"LabCorp Payer Code is invalid. Please provide a valid LabCorp payer code."
	}
};

module.exports = errorMessages;
