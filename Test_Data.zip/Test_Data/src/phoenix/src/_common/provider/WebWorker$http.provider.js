/**
 * Created by ramor11 on 6/23/2016.
 */

module.exports = function (app) {
	"use strict";

	/**
	 * @ngdoc service
	 * @name phx.common.provider:WebWorker$httpProvider
	 *
	 *
	 *
	 *
	 * @description
	 * TO do later
	 *
	 */


	app.provider('WebWorker$http', WebWorker$http);


	function WebWorker$http() {

		/**
		 * @ngdoc service
		 * @name phx.common.WebWorker$http
		 *
		 *
		 * @requires $q
		 *
		 * @description
		 * WebWorker to make $http request without the need of using current DOM thread, it will open a new thread
		 * to make request
		 *
		 * Currently support request:
		 *
		 *
		 */




		this.$get = ['$q', function ($q) {

			var self = this,
				//Worker = require("worker!_common/worker/$http.js"),
				worker = new Worker,
				service = {},
				currentCallbackId = 0, // Create a unique callback ID to map requests to responses
				onmessage = [];

			function request(method, url, config) {

				var defer = $q.defer(),
					callback_id = getCallbackId(),
					data = {
						eventType: method.toUpperCase(),
						promise: callback_id,
						msg: url,
						config: config
					};

				//set the caller
				onmessage[callback_id] = {
					time: new Date(),
					cb: {
						resolve: defer.resolve,
						reject: defer.reject
					}
				};


				worker.postMessage(data);

				return defer.promise;

			}




			/**
			 * @ngdoc function
			 * @name phx.common.WebWorker$http#get
			 * @methodOf phx.common.WebWorker$http
			 *
			 * @description
			 *
			 * $http service to get request parameter,
			 *
			 * @
			 * ```js
			 * $WebWorker$http.get(url: myUrl, {
   			 *		headers: {}
   			 * });
			 * ```
			 *
			 *
			 *
			 * @param {string=} url Url to send the request
			 * @param {object=} config Optional parameters for header.
			 *
			 * @return {object=}  $q.promise
			 *
			 **/
			service.get = function (url, config) {
				return request('GET', url, config || {});
			};


			worker.addEventListener('message', onMessage, false);


			/**
			 * This creates a new callback ID for a request
			 */
			function getCallbackId() {
				currentCallbackId += 1;
				//reset callback id
				if (currentCallbackId > 10000) {
					currentCallbackId = 0;
				}
				return currentCallbackId;
			}

			/**
			 * Will check if promise has been sent to return back to
			 * defer.promise() message
			 */
			function listening() {
				if (onmessage.hasOwnProperty(this.promise)) {
					onmessage[this.promise].cb.resolve(this.msg)
					delete onmessage[this.promise];
					delete this.promise;
				}
			}

			function onMessage(e) {
				listening.apply(e.data)
			}


			return service;
		}]


	}

}
