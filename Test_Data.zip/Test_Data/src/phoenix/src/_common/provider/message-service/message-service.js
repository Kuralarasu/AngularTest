module.exports = function (app) {

	app.directive('lcdGrowlMessages', GrowlMessagesDirective).provider('phxCommonMessenger', Messenger);

	GrowlMessagesDirective.$inject = ['$timeout', '$document', '$animate', '$compile', '$rootScope'];


	function GrowlMessagesDirective($timeout, $document, $animate, $compile, $rootScope) {
		return {
			restrict: 'A',
			replace: true,
			scope: {
				growlOpts: '=lcdGrowlMessages'
			},
			controller: ['$scope', function ($scope) {


				var self = this,
					ele = null,
					destroyTimeout = null;

				self.close = function (event) {

					ele = $(event.target).parents().closest('li');
					//ele.addClass('fade-out'); //lets not remove this for now
					ele.remove();
					// In case the browser don't have any of the transition events
					// destroyTimeout = $timeout(function () {
					// 	slide();
					// }, 500)

				}

				self.destroyParent = function () {

					var listItems = $('[growl-message-container]').find('li').remove();

					// angular.forEach(listItems, function (li) {
					// 	var liEle = angular.element(li)
					// 	liEle.addClass('fade-out');
					// 	$timeout(function () {
					// 		$animate.leave(liEle);
					// 	}, 500)

					// })


				}

				function slide() {

					$timeout.cancel(destroyTimeout); //not needed if already destroyed
					//ele.addClass('slide-up');
					ele.on("webkitTransitionEnd transitionend oTransitionEnd", function () {
						destroy();
					});

					// In case the browser don't have any of the transition events
					destroyTimeout = $timeout(function () {
						destroy();
					}, 1000)
				}

				function destroy() {
					$timeout.cancel(destroyTimeout); //not needed if already destroyed

					if (ele[0].clientHeight === 0)
						$animate.leave(ele);
				}

			}],
			controllerAs: '_lcpGrowl',
			template: [
				'<div growl-message-container class="top-growl">',
				'<ul class="inner-container"></ul>',
				'</div>'
			].join(""),
			link: linkFunc
		};


		function linkFunc(scope, ele, attr, ctl) {

			if (!scope.growlOpts) return;

			if (!scope.growlOpts.hasOwnProperty("showx")) {
				scope.growlOpts["showx"] = 'true';
			}

			var opts = angular.extend({}, {limit: 99}, scope.growlOpts, {}),
				$parent = $($document[0].querySelector(opts.parent)),
				growlContainer = getGrowContainer(),
				liEle = angular.element(['<li lcp-msg-container="" class="' + opts.class + ' ">',
					'<div ng-if="' + opts.showx + '"><span class="msg-close" ng-click="_lcpGrowl.close($event)" ><span class="close-thin"></span></span></div>',
					'<div lcp-msg-text="" class="msg-text">' + opts.message + '</div>',
					'</li>'].join(''));

			if (!growlContainer.length && $parent.length)
				$animate.enter(ele, $parent, angular.element($parent[0].lastChild));

			var ulEle = angular.element(getGrowContainer().find('ul')),
				children = null;
			ulEle.prepend($compile(liEle)(scope.$new()));
			//set the children
			children = ulEle.children();
			//set the timeoutEvent to terminate
			$rootScope.$on('$stateChangeStart', function () {
				ctl.destroyParent();
			});

			$rootScope.$on('notifications:remove-all', function () {
				ctl.destroyParent();
			})

			if (opts.setTimeOut)
				$timeout(function () {
					$(liEle).find('span.msg-close')[0].click()
				}, opts.setTimeOut);

			angular.forEach(children, function (ele, index) {
				if (index > opts.limit - 1) {
					$timeout(function () {
						$(ulEle.children()[children.length - (index + 1)]).find('span.msg-close')[0].click()
					}, 100)
				}
			});

			function getGrowContainer() {
				return $parent.find('div[growl-message-container].top-growl')
			}


		}
	}


	function Messenger() {
		var self = this;

		self.parentSelector = '[name="appBody"]';
		self.opts = {
			parent: self.parentSelector,
			//setTimeOut: 10000,
			class: 'error',
			message: null,
			info: null
		};

		self.$get = ['$injector', '$document', '$timeout', '$q', '$rootScope', '$parse', getProvider]

		function getProvider($injector, $document, $timeout, $q, $rootScope, $parse) {

			var $animate,
				$compile,
				completeTimeout,
				error = false,
				GrowlBigMessageContainer,
				GrowlMessageContainer,
				destroyTimeout,
				opts = angular.copy(angular.extend({}, self.opts)),
				loaderService = $injector.get('phxCommonLoaderService', 'phxCommonMessenger');
			// spinnerStarted = false,
			// spinner = angular.element($templateCache.get('/phxCommon/loading-bar.html'));


			function animateCompile() {
				if (!$animate || !$compile) {
					$animate = $injector.get('$animate', 'phxCommonMessenger');
					$compile = $injector.get('$compile', 'phxCommonMessenger');
				}
			}


			function _growl(options) {
				animateCompile();
				opts = angular.copy(angular.extend({}, self.opts, options || {}));
				if (opts.class) {
					var sClass = String(opts.class).trim();
					switch (sClass) {
						case 'error':
							opts.setTimeOut = options.setTimeOut || false;
							break;
						default:
							break;
					}
				}

				$parse('growlGrowlOpts').assign($rootScope, opts);
				GrowlMessageContainer = $compile(angular.element('<div></div>').attr('lcd-growl-messages', 'growlGrowlOpts'))($rootScope);
				$timeout(function () {
					//no longer needed
					delete $rootScope['growlGrowlOpts'];
				}, 1)

			}


			/**
			 * Display the error message
			 * @param message
			 * @param info
			 * @param options
			 * @private
			 */
			function _error(message, info, options) {

				//lets route to _growl for now
				_growl({class: 'error', message: message});

				// opts = angular.copy(angular.extend({}, self.opts, {
				// 	message: typeof(message) === 'object'?JSON.stringify(message):message,
				// 	info: info,
				// 	setTimeOut: false,
				// 	class: 'error',
				// }, options || {}));


				// setMessages(opts)

			}

			/**
			 * Display the sucess message
			 * @param message
			 * @param info
			 * @param options
			 * @private
			 */
			function _success(message, info, options) {

				opts = angular.copy(angular.extend({}, self.opts, {
					message: message,
					info: info,
					class: 'success',
				}, options || {}));


				setMessages(opts)
			}

			function setMessages(options) {
				$timeout.cancel(completeTimeout);
				$timeout.cancel(destroyTimeout);

				//there is already an error
				if (error) {
					_slideDown(GrowlBigMessageContainer, 1).then(function () {
						_error(options.message, options.info, options);
					});
					return;
				}

				animateCompile();
				$parse('growlBigMessageOpts').assign($rootScope, options);
				GrowlBigMessageContainer = $compile(angular.element('<div></div>').attr('lcd-growl-big-message', 'growlBigMessageOpts'))($rootScope);
				error = true;
				$timeout(function () {
					delete $rootScope['growlBigMessageOpts'];
				}, 1)

			}

			function _slideDown(element, timeout) {
				if (!error || !timeout) return;

				var defer = $q.defer();

				$timeout.cancel(completeTimeout);
				$timeout.cancel(destroyTimeout);

				error = false;

				var clientHeight = element[0].clientHeight;

				element.css({bottom: Number(clientHeight * -1) + 'px'});
				element.on("webkitTransitionEnd transitionend oTransitionEnd", function () {
					$timeout.cancel(destroyTimeout);
					_destroy(element, defer);
				})

				// In case the browser don't have any of the transition events
				destroyTimeout = $timeout(function () {
					_destroy(element, defer);
				}, timeout + 100)

				return defer.promise;
			}

			function _destroy(element, defer) {

				$timeout.cancel(destroyTimeout); //not needed if already destroyed
				$animate.leave(element);
				error = false;

				delete $rootScope['growlBigMessageOpts'];
				delete $rootScope['growlGrowlOpts'];

				return defer.resolve();
			}

			function _hideSpinner(boolean) {
				// spinnerStarted = boolean;
				// loaderService.hide()
			}


			/**
			 * Spinner show
			 * @private
			 */
			function _show() {
				loaderService.start({
					target: $('section.app-body')
				});
			}


			function _removeAll() {
				$rootScope.$broadcast('notifications:remove-all');
			}


			return {
				error: _error,
				success: _success,
				growl: _growl,
				hideSpinner: _hideSpinner,
				/**
				 * @ngdoc function
				 * @name phxCommonMessenger#show
				 * @module phxCommon
				 * @kind function
				 *
				 * @param {object=} object with parameters
				 *
				 * @description
				 * Enters the animation and add the element to the DOM
				 *
				 * @example
				 *
				 * ```js
				 * var options = {
			 	 *      spinnerTemplate :'<div></div>'
             	 * },
				 *
				 * service.start(options);
				 *
				 * ```
				 */
				show: _show,
				/**
				 * @ngdoc function
				 * @name phxCommonMessenger#hide
				 * @module phxCommon
				 * @kind function
				 *
				 *
				 * @description
				 * Runs the leave animation operation and, upon completion, removes the element from the DOM
				 *
				 */
				hide: loaderService.hide,
				removeAll: _removeAll
			};

		}

	};


}
