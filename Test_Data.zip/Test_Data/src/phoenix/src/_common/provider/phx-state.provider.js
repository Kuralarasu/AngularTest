module.exports = function (app) {
	'use strict';


	app.run(['phxState', '$document', function (State, $document) {
		var _class = [];

		State.OnStateChangeStart(function (to, from) {
			var body = angular.element($document[0].body),
				_cName = to.name.replace(/\.?([A-Z])/g, function (x, y) {
					return "-" + y.toLowerCase()
				}).replace(/\./g, '-');

			_class.forEach(function (_c) {
				body.removeClass(_c);
			});

			//remove all class
			_class.splice(0, _class.length);
			//replace whats in memory
			_class.push(_cName);
			body.addClass(_cName); //body[0] !== document.body

		});

	}]).config(['phxStateProvider', function (State) {
		State.inject(require('../authentication/authentication-routes.js'));
		State.inject(require('../common-routes.js'));
	}])


	/**
	 * @ngdoc service
	 * @name phxApp.provider:phxStateProvider
	 *
	 *
	 * @description
	 *
	 * Use `phxStateProvider` to inject|permission into phxApp during config

	 *
	 *
	 */
		.provider('phxState', routeInjector);

	routeInjector.$inject = ['$injector'];

	function routeInjector($injector) {

		var uiResourceMap = {
				TopNav: [],
				SideNav: [],
				DisplayName: [],
				_appStatesMaps: [],
				_applicationBranding: false
			},
			state = null,
			r = [],
			$stateProvider = $injector.get('$stateProvider', 'routeInjector'),
			$urlRouterProvider = $injector.get('$urlRouterProvider', 'routeInjector');

		/**
		 * @ngdoc function
		 * @name phxApp.provider:phxStateProvider#inject
		 * @methodOf phxApp.provider:phxStateProvider
		 *
		 *
		 * @param {Array=} routes to inject for module
		 *
		 * @description
		 * Inject routes bases on uiRouter object tree
		 * @example

		 ```js
		 var routes = [
		 {
             name: 'billinglayout',
             parent: 'dashboard',
             abstract: true,
             views: {
                 //code ...
             },
             resolve: {
                 jsBundleBilling: ['jsBundleResolver', function (jsBundleResolver) {
					//LazyLoad the necessary dependencies for billing.js module
                     return jsBundleResolver(function(app, resolve){
                         require.ensure([], function () {
                             app.register(require('./billing.js'));
                             resolve();
                         });
                     });
                 }]
             }
         }];

		 module.exports = routes;

		 ```
		 *
		 */
		this.inject = function (routes) {
			angular.forEach(routes, function (route) {
				var views = route.views || {};

				Object.keys(views).forEach(function (key) {
					var tem = views[key].templateUrl;
					if (tem) {
						views[key].templateUrl = angular.isArray(tem) ? tem.join('/').replace(/\/\//g, '/') : tem;
					}
				});

				route.data = Object.assign({}, route.data, {
					debug: location.search.split('debug=')[1] || location.hash.split('debug=')[1]
				});


				r.push(route)
				$stateProvider.state(route);
			});
		};

		/**
		 * @ngdoc function
		 * @name phxApp.provider:phxStateProvider#permission
		 * @methodOf phxApp.provider:phxStateProvider
		 *
		 *
		 * @description
		 * Inject permission bases on Axiomatic structure, this will also define the position of the application module
		 * injection within the phxApp templates.
		 * @example
		 *
		 ```js
		 module.exports = {
				"order": 5, //define the order of the module to display onto UI
				"position": 'secondary', //position of the order, default secondary, primary is reserved for topmost nav bar
				"display": "myModule",//Module name to display to UI
				//Siteminder Authorization ID name
	 			"auth": ["myModule"],
				"maps": [
				//Object reference for authz route from siteminder
					{id:"myModule", state: 'myModule'},
					//Needs to be added if you want it to route to url on refresh, otherwise unrecognized routes will default to root
					{id:"myModule.Worker", state: 'WebWorker'},
					{id:"myModule.IPC", state: 'IPC'},
					{id:"myModule.Storage", state: 'storage'},
				]
			};
		 ```
		 *
		 */
		this.permission = function (opts) {
			var _default = {
					"order": 1, //define the order of the module to display onto UI
					"position": "secondary", //position of the order, default secondary
					"display": "",//Module name to display to UI
					"auth": [],
					"maps": []
				},
				obj = angular.extend({}, angular.copy(_default), opts);

			uiResourceMap.DisplayName.push({
				order: obj.order,
				name: obj.display,
				position: obj.position,
				source: opts
			});

			if (obj.auth[0])uiResourceMap.TopNav.push(obj.auth[0])

			if (obj.maps.length)
				uiResourceMap._appStatesMaps = uiResourceMap._appStatesMaps.concat(obj.maps)

			angular.forEach(obj.maps, function (o) {
				if (obj.auth[0] !== o.id)
					uiResourceMap.SideNav.push(o.id)
			});


		};

		/**
		 * @ngdoc function
		 * @name phxApp.provider:phxStateProvider#branding
		 * @methodOf phxApp.provider:phxStateProvider
		 *
		 *
		 * @param {string} template for new branding html reference
		 *
		 * @description
		 * Customize the branding of the application header
		 * @example
		 *
		 ```js
		 phxState.branding(['<span class="app-logo"></span>',
		 '<span class="app-title">',
		 '    <span class="brand-title">Phoenix</span>',
		 '   <span class="trade-mark">®</span>',
		 '</span>'].join(" "))
		 ```
		 *
		 */
		this.branding = function (string) {
			uiResourceMap._applicationBranding = string;
		};


		/**
		 * @ngdoc service
		 * @name phxApp.provider:phxState
		 *
		 * @requires $rootScope
		 * @requires $document
		 *
		 * @description
		 * Defines the state of the application rules and views
		 *
		 *
		 * @return {Object|Array} Reference to phxStateProvider injection and permission states
		 *
		 *
		 */

		this.$get = ['$rootScope', '$document', '$timeout', function ($rootScope, $document, $timeout) {
			var dashboard = r.filter(function (obj) {
					return obj.name === 'dashboard'
				})[0] || function (arr) {
					var route = {
						name: 'dashboard',
						parent: 'root',
						url: '/',
						views: {
							'appBody@': {
								template: "",
								controller: ['helpRouteService', function (helpRoute) {
									helpRoute.init();
								}]
							}
						}
					};
					$stateProvider.state(route);
					arr.push(route)
				}(r);


			$urlRouterProvider.otherwise(function ($injector) {
				$injector.get('$state').transitionTo('dashboard');
			});


			return {
				uiResourceMap: uiResourceMap,
				OnStateChangeStart: function (fn) {
					var func = typeof fn === 'function' ? fn : angular.noop;
					$rootScope.$on('$stateChangeSuccess', function (e, toState, toParams, fromState, fromParams) {
						func(toState, toParams, fromState, fromParams)
					});
				}
			};
		}];

	}
};
