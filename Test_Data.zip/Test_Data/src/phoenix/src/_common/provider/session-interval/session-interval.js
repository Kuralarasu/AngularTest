/**
 * TODO: //investigate to better perform this action in a web workers.
 */
var moment = require('moment');

module.exports = function (app) {

	app.provider('sessionInterval', SessionInterval);

	function SessionInterval() {
		var self = this,
			timeStamp = moment().unix(),
			timeoutMinutes = 15.25, //set the timer which the session will timeout
			offSetMinutes = 3, //set a limit for the alert to appear
			warningSeconds = 60,
			userSessionTimeStamp,
			countDownInterval,
			authService;

		self.$get = ['$injector', '$document', '$interval', '$rootScope', getProvider];

		function getProvider($injector, $document, $interval, $rootScope) {
			var modalService;

			angular.element(window).on('click', function () {
				//for every document interaction we should set the timer
				timeStamp = moment().unix();
			});

			$rootScope.$on('$stateChangeStart', function (event, next) {
				if (next.url === '/login') {
					$interval.cancel(countDownInterval);
					$interval.cancel(userSessionTimeStamp);
				}
			});


			$rootScope.$on('LCP_SIGN_OUT_BROADCAST', function () {
				$interval.cancel(countDownInterval);
				$interval.cancel(userSessionTimeStamp);

			});

			/**
			 * Countdown in seconds
			 * @param duration
			 */
			function countdown(duration) {

				modalService = $injector.get('common.svcs.modalService', 'sessionInterval');
				authService = $injector.get('authService', 'sessionInterval');

				//console.log('START COUNTDOWN', duration)
				//To avoid of modal clones when the user does not authenticate
				if (angular.element($document[0].querySelector('#SessionDialog')).length)return;

				var modalOptions = {
					hasBackdrop: true,
					controller: ['$mdDialog', '$state', function ($mdDialog, $state) {
						var ctrl = this;
						ctrl.counter = "  :  ";
						ctrl.warning = false;
						// PHXREL-1935: If the modal is displayed after the duration has elapsed,
						// set the timer to 0 to log out the user:
						var modalDisplayTimeDiff = (moment().unix() - showModalTime) / 60;
						var DiffGreaterThanOffsetMinutes = modalDisplayTimeDiff > offSetMinutes;
						var onLoginPage = $document[0].body.classList.contains('login');

						var timer = DiffGreaterThanOffsetMinutes || onLoginPage ? 0 : duration,
							minutes,
							seconds;

						function countdownFn() {
							minutes = parseInt(timer / 60, 10);
							seconds = parseInt(timer % 60, 10);

							minutes = minutes < 10 ? "0" + minutes : minutes;
							seconds = seconds < 10 ? "0" + seconds : seconds;

							ctrl.counter = minutes + ":" + seconds;
							if (--timer < 0) {
								$interval.cancel(countDownInterval);
								$interval.cancel(userSessionTimeStamp);

								authService.doLogout();
								$mdDialog.hide();

							} else if (timer < warningSeconds) {
								ctrl.warning = true;
							}
						}
						countdownFn();
						countDownInterval = $interval(countdownFn, 1000);


						ctrl.continue = function () {
							$interval.cancel(countDownInterval);
							ping();
							$mdDialog.hide();
						};

						ctrl.cancel = function () {
							$mdDialog.hide();
							$interval.cancel(userSessionTimeStamp);
							$interval.cancel(countDownInterval);

							authService.doLogout();
							setTimeout(ping, 1)

						}

					}],
					controllerAs: 'ctrl',
					template: require('html!./session-interval.html'),
					windowClass: "ping-window"
				};

				var showModalTime = moment().unix();
				modalService.showModal(modalOptions);
			}

			function ping() {
				console.log('ping');
				//We are just gonna ping the server to keep the cookie session alive with
				//siteminder
				var urlService = $injector.get('RestUrlService', 'sessionInterval'),
					lcdMessage = $injector.get('phxCommonMessenger', 'sessionInterval'),
					$http = $injector.get('$http', 'sessionInterval');

				// lcdMessage.hideSpinner(true); //lets hide the spinner since we want this to be silent to the UI
				$interval.cancel(userSessionTimeStamp);

				return $http.get(urlService.AUTHC_URL).finally(function () {
					lcdMessage.hide(); //hide the spinner
				});
			}

			function session(minutes) {

				$interval.cancel(userSessionTimeStamp);

				userSessionTimeStamp = $interval(function () {

					var now = moment().unix(),
						diff = (now - moment(timeStamp)) / 60;
					if (diff < minutes) {
						ping();
					} else if (diff > timeoutMinutes) {
						// PHXREL-1935: If the timer is interrupted for more time than "timeoutMinutes",
						// e.g., the machine is put to sleep overnight and awakened, log-out immediately:
						countdown(0);
					} else {
						countdown(offSetMinutes * 60);
					}

				}, minutes * 60 * 1000)
			}


			function _set(timestamp) {
				$interval.cancel(userSessionTimeStamp);
				timeStamp = Number(moment(timestamp).format('X')) || moment().unix();
				session(timeoutMinutes - offSetMinutes);
			}


			return {
				set: _set,
				countdown: countdown
			};

		}

	}

};
