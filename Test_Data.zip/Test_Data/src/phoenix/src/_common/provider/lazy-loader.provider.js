/**
 * Refer: http://taoofcode.net/studying-the-angular-injector-loading-modules/
 * Refer: https://github.com/packetloop/angular-webpack
 *
 *
 * @param phxApp
 *
 */

module.exports = function (phxApp) {
    'use strict';

    phxApp
        .run(['lcpLazyLoader', '$document', function (Loader, $document) {
            var _class = [];

            Loader.OnStateChangeStart(function (module, to, from) {
                var body = angular.element($document[0].body),
                    setClass = function (state, name) {
                        if (!name) return;
                        var _name = name.replace(/\./g, '_');
                        _class.push(_name);
                        body[state](_name);

                    };

                _class.forEach(function (_c) {
                    body.removeClass(_c);
                });

                //remove all class
                _class.splice(0, _class.length);
                setClass('addClass', module);

            });
        }])
		/**
		 * @ngdoc service
		 * @name phxApp.provider:lcpLazyLoaderProvider
		 *
		 * @description
		 *
		 * Lazy Loads Angular modules and its components when the JS file is downloaded to the browser.
		 * Each JS file downloaded, on-demand is expected to be an AngularJS module. Any components (contrller, service, etc)
		 * would need to be added into an angular module and delivered to the UI.
		 *
		 * phxApp.register will be called during 'resolve' method of 'ui-router' state to initialize the module into phxApp
		 * main module.
		 *
		 */


        .provider('lcpLazyLoader', LazyLoaderConfig)

		/**
		 * @ngdoc service
		 * @name phxApp.provider:jsBundleResolverProvider
		 *
		 * @description
		 *
		 * Lazy Loads Angular modules and its components when the JS file is downloaded to the browser.
		 * Each JS file downloaded, on-demand is expected to be an AngularJS module. Any components (contrller, service, etc)
		 * would need to be added into an angular module and delivered to the UI.
		 *
		 * phxApp.register will be called during 'resolve' method of 'ui-router' state to initialize the module into phxApp
		 * main module.
		 *
		 */

        .provider('jsBundleResolver', BundleResolver);


    function LazyLoaderConfig() {
        phxApp.register = angular.noop;


        this.currentModule = null;

		/**
		 * @ngdoc service
		 * @name phxApp.lcpLazyLoader
		 *
		 * @requires $document
		 * @requires $ocLazyLoad
		 *
		 * @description
		 *
		 * Lazy Loads Angular modules and its components when the JS file is downloaded to the browser.
		 * Each JS file downloaded, on-demand is expected to be an AngularJS module. Any components (contrller, service, etc)
		 * would need to be added into an angular module and delivered to the UI.
		 *
		 * phxApp.register will be called during 'resolve' method of 'ui-router' state to initialize the module into phxApp
		 * main module.
		 *
		 */


        this.$get = ['$document', '$ocLazyLoad', '$rootScope', function ($document, $ocLazyLoad, $rootScope) {

            var _this = this;

			/**
			 * @ngdoc function
			 * @name phxApp.lcpLazyLoader#register
			 * @methodOf phxApp.lcpLazyLoader
			 *
			 * @description
			 *
			 *
			 */


            phxApp.register = function (module) {


                //if the module has dependencies, recursively include those dependencies
                module.requires.forEach(function (moduleName) {
                    // Skip if the module is already registered.
                    // AngularJS throws an error otherwise
                    if (!(phxApp.requires.indexOf(moduleName) > -1)) {
                        $ocLazyLoad.inject(moduleName);
                        // phxApp.register(angular.module(moduleName));
                    } else {
                        console.log('module:', moduleName, 'found in phxApp, skipping.... ');
                    }

                });

                // console.log('module._invokeQueue ---- ',
                // 	module._invokeQueue.map(function (ary) {
                // 		return ary[2][0]
                // 	}));
                module._invokeQueue.map(function (ary) {
                    return ary[2][0]
                });

                return $ocLazyLoad.load({ name: module.name }).finally(function () {
                    _this.currentModule = module.name;
                })
            };

            return {
                OnStateChangeStart: function (fn) {
                    var func = typeof fn === 'function' ? fn : angular.noop;
                    $rootScope.$on('$stateChangeSuccess', function (e, toState, toParams, fromState, fromParams) {
                        func(_this.currentModule, toState, toParams, fromState, fromParams)
                    });
                }
            };
        }];

    }


    function BundleResolver() {


		/**
		 * @ngdoc service
		 * @name phxApp.provider:jsBundleResolver
		 *
		 * @requires $q
		 *
		 *
		 * @description
		 *
		 * Lazy Loads Angular modules and its components when the JS file is downloaded to the browser.
		 * Each JS file downloaded, on-demand is expected to be an AngularJS module. Any components (contrller, service, etc)
		 * would need to be added into an angular module and delivered to the UI.
		 *
		 * phxApp.register will be called during 'resolve' method of 'ui-router' state to initialize the module into phxApp
		 * main module.
		 *
		 * @example

		 ```js
		 var routes = [
		 {
             name: 'billinglayout',
             parent: 'dashboard',
             abstract: true,
             views: {
                 //code ...
             },
             resolve: {
                 jsBundleBilling: ['jsBundleResolver', function (jsBundleResolver) {
					//LazyLoad the necessary dependencies for billing.js module
                     return jsBundleResolver(function(app, resolve){
                         require.ensure([], function () {
                             app.register(require('./billing.js'));
                             resolve();
                         });
                     });
                 }]
             }
         }];

		 module.exports = routes;

		 ```
		 *
		 */


        this.$get = ['$q', function ($q) {


            var Bundler = function (callback) {
                var defer = $q.defer(),
                    func = angular.isFunction(callback) ? callback : angular.noop;

                func.apply(this, [phxApp, defer.resolve]);


                return defer.promise;

            };


            return Bundler;
        }];


    }
};
