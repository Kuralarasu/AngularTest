/**
 * Created by ramor11 on 6/16/2016.
 *
 * Load application dependencies which will be compiled in vendor.js
 *
 * Module Directories are defined within webpack.config.js where it will search for necessary paths
 * ['.tmp', 'node_modules', 'bower_components', 'src', 'components']
 *
 *
 */

/**
 * Libraries needed for the core files
 */
//angular libraries
require('angular/angular');
require('angular-ui-router/release/angular-ui-router');
require('angular-resource/angular-resource');
require('angular-cookies/angular-cookies');
require('angular-uuid4/angular-uuid4');
require('angular-sanitize/angular-sanitize');
//dependencies for ngMaterial
require('angular-aria/angular-aria');
require('angular-animate/angular-animate');
require('angular-messages/angular-messages');
require('angular-material/angular-material');
//dependent libraries
require('angular-filter/dist/angular-filter');
require('angular-hotkeys/build/hotkeys');
require('angular-utils-ui-breadcrumbs/index');
require('angular-loading-overlay/dist/angular-loading-overlay');
require('bootstrap/dist/js/bootstrap');

require('moment/moment');
require('oclazyload/dist/ocLazyLoad');

require('_vendor/oop/namespace');

//PHX-UI-LIB COMPONENTS
// phxuilib.lcpInputText
require('../lcpInputText');
require('../jarvisMenu');

