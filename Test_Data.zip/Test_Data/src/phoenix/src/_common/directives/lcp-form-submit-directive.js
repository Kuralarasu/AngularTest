module.exports = function (app) {

	app.directive('lcpFormSubmit', directive);

	directive.$inject = ['$parse', '$q'];

	function directive($parse, $q) {

		var LOADING_ATTR_NAME = 'loading-text';

		return {
			restrict: 'A',
			require: 'form',
			link: function (scope, element, attributes, formCtrl) {

				var $element = angular.element(element);

				// Add novalidate to the form element.
				attributes.$set('novalidate', 'novalidate');

				$element.bind('submit', function (e) {
					e.preventDefault();

					var elemToBeUpdated = $($element).find('button[' + LOADING_ATTR_NAME + ']');
					angular.forEach(elemToBeUpdated, function (elem) {
						var _elem = angular.element(elem);
						var normalVal = _elem.text(),
							loadingVal = _elem.attr(LOADING_ATTR_NAME);
						_elem.attr(LOADING_ATTR_NAME, normalVal);
						_elem.text(loadingVal);
						_elem.prop('disabled', true);
					});

					// Remove the class pristine from all form elements.
					$element.find('.ng-pristine').removeClass('ng-pristine');

					// Set all the fields to dirty and apply the changes on the scope so that
					// validation errors are shown on submit only.
					angular.forEach(formCtrl, function (formElement, fieldName) {
						// If the fieldname starts with a '$' sign, it means it's an Angular
						// property or function. Skip those items.
						if (fieldName[0] === '$') return;

						formElement.$pristine = false;
						formElement.$dirty = true;
					});

					// Do not continue if the form is invalid.
					if (formCtrl.$invalid) {
						// Focus on the first field that is invalid.
						$element[0].querySelector('.ng-invalid').focus();
						return false;
					}

					// From this point and below, we can assume that the form is valid.
					var submitFn = $parse(attributes.lcpFormSubmit);
					var deferred = $q.defer();
					submitFn(scope, {$promise: deferred});

					deferred.promise.then(function () {
						angular.forEach(elemToBeUpdated, function (elem) {
							var _elem = angular.element(elem);
							var loadingVal = _elem.text(),
								normalValue = _elem.attr(LOADING_ATTR_NAME);
							_elem.attr(LOADING_ATTR_NAME, loadingVal);
							_elem.text(normalValue);
							_elem.prop('disabled', false);
						});
					});

					scope.$apply();
				});
			}
		};
	};

};

