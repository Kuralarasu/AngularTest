module.exports = function (app) {
	"use strict";

	app.directive('lcpScrollContainer', lcpScrollContainer);

	lcpScrollContainer.$inject = ['$window', '$timeout', '$document']

	function lcpScrollContainer($window, $timeout, $document) {

		var directive = {
			restrict: 'A',
			link: funcLink
		};

		function funcLink(scope, element, attr) {

			var _elmHeight = $(element).innerHeight(),
				_scrollable = $(element)[0].scrollHeight;

			$timeout(function () {

				//when any of the childs are not scrollable
				var scrollableChilds = $(element).find('[lcp-scroll-container]');
				if (scrollableChilds.length == 0) {
					$(document).off('keydown').on("keydown", function (e) {

						switch (e.which) {

							case 38: //up
								var test = $(element).scrollTop() - 20;
								$(element).scrollTop(test);
								break;

							case 40: //down
								var test = $(element).scrollTop() + 20;
								$(element).scrollTop(test);
								break;

							default:
								return;
						}

					});
				}

			});


		}


		return directive;
	}


}
