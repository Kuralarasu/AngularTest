module.exports = function (app) {
	"use strict";
	/**
	 * @ngdoc directive
	 * @name phxApp.lcpShowallTabs
	 *
	 * @description
	 * Directive for Bootstrap Tab control. Add this directive on 'Show All' <li> tag
	 *
	 */

	app.directive('lcpShowallTabs', showAllDirective);

	function showAllDirective() {

		var directive = {};
		directive.restrict = 'A';
		/* restrict this directive to elements */
		directive.compile = function (tabsetElem, attrs) {

			return function (scope, element, attr, ctrls) {

				var ulNode = $(element).closest('ul'),
					tabContent = ulNode.siblings('.tab-content');

				$('li', ulNode).not(element).click(function () {
					//console.log("not a show all ");
					tabContent.removeClass('showsall');
				});

				$(element).click(function () {
					$('li', ulNode).removeClass('active');
					$(element).addClass('active');
					tabContent.addClass('showsall');

					$('.tab-pane', tabContent).each(function (idx, item) {
						$(item).addClass('active');
					});
				});

			}
		};

		return directive;
	};


}

