module.exports = function (app) {
	"use strict";

	app.directive('lcpSelectbox', selectBox);
	selectBox.$inject = ['$timeout'];

	function selectBox($timeout) {
		var directive = {};

		directive.restrict = 'E';
		/* restrict this directive to elements */

		directive.scope = {
			name: "@name",
			label: "@label",
			id: "@id",
			placeholder: "@placeholder",
			type: "@type",
			options: '=options',
			selected: '=ngModel'
		};

		directive.template = [
			'<div class="lcpSelectbox dropdown">',
			'	<div class="comboTxtbox">',
			'    	<lcp-input-text ng-model="selected" class="{{ngdirty}}" ></lcp-input-text>',
			'	</div>',
			'    <a class="trigger"><span class="arrow" aria-hidden="true"></span></a>',
			'    <ul class="dropdown-menu lcpSelectMenu columns-select">',
			'        <li ng-class="{\'active\' : selected === option}"  ng-repeat="option in options" ng-click="onSelection(option, $event)"><a ng-bind="option"></a></li>',
			'    </ul>',
			'</div>'
		].join('');

		directive.link = function ($scope, iElement) {

			var comboTxtbox = $('.comboTxtbox input', iElement);
			var triggerIcon = $('a.trigger', iElement);

			//TODO - Compare based on Key=Value instead
			//TODO - Mark field dirty when user changes
			$scope.onSelection = function (selected, $event) {
				if ($scope.selected !== selected) {
					comboTxtbox.addClass('ng-dirty');
				}

				$scope.selected = selected;

			};

			triggerIcon.click(function () {
				$(iElement).find('.dropdown').toggleClass('open');
				comboTxtbox.focus();
			});

			comboTxtbox.focusin(function () {
				if (!$(".dropdown-menu:visible", iElement).size()) {
					$(iElement).find('.dropdown').addClass('open');
				}
			});

			comboTxtbox.focusout(function () {
				$timeout(function () {
					$(iElement).find('.dropdown').removeClass('open');
				}, 100);

			});

		};

		return directive;
	};



};


