module.exports = function (app) {

	/**
	 * @ngdoc directive
	 * @name phxApp.lcpClickUpload
	 *
	 * @description
	 *
	 */

	app.run(['$templateCache', function ($templateCache) {
		$templateCache.put('/lcp/lcpClickUpload/lcpClickUpload.html', [
				'<div class="dropzone">',
				'<span class="dz-image">' +
				'<i class="svg-upload-cloud"></i>' +
				'</span>',
				'<span class="dz-message">Click To Upload File</span></div>',
			].join('')
		)

	}]).directive('lcpClickUpload', lcpClickUpload)

	lcpClickUpload.$inject = ['$parse'];
	function lcpClickUpload($parse) {
		var directive = {
			restrict: 'A',
			link: linkFunc
		};

		function linkFunc(scope, element, attr) {

			var files = [],
				STATUS = {
					ADDED: "added",
					QUEUED: "queued",
					ACCEPTED: "accepted",
					UPLOADING: "uploading",
					PROCESSING: "processing",
					CANCELED: "canceled",
					ERROR: "error",
					SUCCESS: "success"
				},
				defaults = {
					mediaTypes: [
						'image/jpeg',
						'image/gif',
						'image/pjpeg',
						'image/png',
						'image/tiff'
					],
					allowedExtensions: [],
					onError: function () {
					},
					onDrop: function () {
					},
					onClick: function () {
					}

				};

			var opts = angular.extend({}, defaults, $parse(attr.lcpClickUpload)(scope));

			/**
			 * Receive array of files
			 */
			function handleFiles(files) {
				var file,
					_results = [],
					files = files[0] ? files : [files];
				for (var i = 0; i < files.length; i++) {
					file = files[i];
					_results.push(addFile(file));
				}
				return _results;
			};


			function isFileType(file) {

				var fileType = false,
					ext = String(file.name.substr((~-file.name.lastIndexOf(".") >>> 0) + 2)).toLowerCase();

				if (opts.mediaTypes.indexOf(file.type) !== -1)
					fileType = true;

				if (opts.allowedExtensions.length) {
					fileType = false;

					if (opts.allowedExtensions.indexOf(ext) !== -1) {
						fileType = true;
					}
				}

				if (!fileType) {
					opts.onError({
						error: "Incorrect File Type"
					});
				}

				return fileType;

			}


			function addFile(file) {
				//check if file size was not rejected
				if (isFileType(file)) {

					file.timeStamp = Math.round((new Date()).getTime() / 1000);
					file.status = STATUS.ADDED;
					files.push(file);
					return opts.onDrop([file]);
				}
			};


			element.on('click', function () {
				opts.onClick();
				angular.element(document.querySelector('#hiddenDropZone')).remove();
				var hiddenInput = angular.element('<input />')
					.attr({
						//multiple: true,
						type: 'file',
						id: 'hiddenDropZone'
					})
					.css({visibility: "hidden"})
					.on("change", function () {
						var _this = angular.element(this),
							f = _this[0].files;
						if (f.length) {
							handleFiles(f);
						}
						_this.remove();
					});

				angular.element(document.querySelector('body')).append(hiddenInput);
				return hiddenInput[0].click();
			});


			scope.$on('$destroy', function () {
				angular.element(document.querySelector('#hiddenDropZone')).remove();
			});


		}

		return directive;
	}


};
