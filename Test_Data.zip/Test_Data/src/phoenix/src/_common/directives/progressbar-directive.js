module.exports = function (app) {
	'use strict';


	app.directive('progressBarAlert', autoCloser);

	autoCloser.$inject = ['$rootScope', 'COMMON_EVENTS', '$timeout'];

	function autoCloser($rootScope, COMMON_EVENTS, $timeout) {
		var directive = {};

		directive.restrict = 'E';
		/* restrict this directive to Attribute */
		directive.template = '<div></div>';
		directive.compile = function (element, attributes) {

			element.removeClass();

			$rootScope.$on(COMMON_EVENTS.httpApiRequestInProgress, function () {
				element.removeClass('progress-active progress-done progress-failed');
				element.text('Please wait... ');
				element.css('display', 'block');
				element.addClass('progress-active');
			});

			$rootScope.$on(COMMON_EVENTS.httpApiRequestCompleted, function () {

				element.removeClass('progress-active progress-done progress-failed');
				element.text('Completed');
				element.css('display', 'block');
				element.addClass('progress-done');

				$timeout(function () {
					element.css('display', 'none');
				}, 1000);
			});

			$rootScope.$on(COMMON_EVENTS.httpApiRequestFailed, function () {

				element.removeClass('progress-active progress-done progress-failed');
				element.text('Failed');
				element.css('display', 'block');
				element.addClass('progress-failed');

				$timeout(function () {
					element.css('display', 'none');
				}, 1000);
			});
		}

		return directive;
	}

};
