/*
 *
 * THIS CODE DOES NOT RESIDE WITHIN THIS FILE ***********************************************************
 * The code originates within lcp-date-picker for module dependency simplicity
 * This file has been added for documentation and API reference.
 *
 *
 */
/**
 * @ngdoc directive
 * @name lcpDateFormat
 *
 * @description
 * lcpDateFormat will only accept numbers within the format of MM/dd/yyyy, it will setValidity to the
 * ngModel if this fails
 *
 * @element A , restricted to attribute to accept additional parameter on directive attribute
 *
 *
 * @params {expression} lcpDatePicker {@link object/expression} to evaluates options upon compile
 *
 * lcpDatePicker additional accepted attributes.
 * @params {placeholder, ngRequired, minDate, maxDate, ngModel} Insert the class on parent container
 *
 * @example
 *  <example>
 * <file name="index.html">
 * ```html
 * <input type="tel"  ng-model="ctrl.value" lcp-date-format' />
 * ```
 * </file>
 *
 * </example>
 *
 * A collection of attributes that allows creation of custom event handlers that are defined as
 * angular expressions and are compiled and executed within the current scope.
 *
 */

