module.exports = function (app) {


	/**
	 * @ngdoc directive
	 * @name lcpEmailRegex
	 * @restrict A
	 *
	 * @description
	 * This will take two attributes to change the ngModel to a new pattern
	 *
	 *
	 * @example
	 * <example>
	 * <file name="index.html">
	 * ```html
	 * <lcp-input-text autocomplete="off" label="Email"
	 *        lcp-regex="/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/"

	 *        ng-model="ctrl.respPatient.emails[1].emailAddress"></lcp-input-text>
	 * ```
	 * </file>
	 *
	 * The example takes the input on keyUp and evaluates the regex given, and replaces the ngModel with lcpRegexReplace
	 *
	 */

	app.directive('lcpEmailRegex', lcpEmailRegex);

	lcpEmailRegex.$inject = ['phxCommonUtilities'];

	function lcpEmailRegex(utilities) {


		var directive = {
			priority: 0,
			restrict: 'A',
			require: 'ngModel',
			link: linkFunc

		};

		function linkFunc(scope, element, attr) {
			//if (!attr.lcpEmailRegex) {
			//	console.log('got nowhere');
			//	return;
			//}


			var input = element.find('input')[0] ? element.find('input') : element,
				ngModel = input.controller('ngModel');

			input.on("blur keyup", function (event) {


				event.keyCode = event.charCode || event.keyCode;

				if (event.keyCode >= 37 && event.keyCode <= 40)
					return;
				ngModel.$setValidity('email', true);

				if (!this.value) return;

				var status = utilities.isValidEmail(this.value);
				console.log('status >>  ', status);
				ngModel.$setValidity('email', status);
				ngModel.$setViewValue(this.value);
				ngModel.$render();
			})
		}

		return directive;
	}


};

