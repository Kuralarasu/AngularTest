module.exports = function (app) {

	"use strict";


	/**
	 * @ngdoc directive
	 * @name phxApp.lcpNumbersOnly
	 *
	 * @description
	 * It will automatically limit the input field to only accept numbers. When lcp-input-text is used, and type=numbers
	 * it will automatically implement the lcp-number-only directive
	 *
	 *
	 * @element A , restricted to attribute to accept additional parameter on directive attribute
	 *
	 * @example
	 *     <example>
	 *     <file name="index.html">
	 *     ```html
	 *
	 *     <!-- It will automatically implement number only if the type=numbers -->
	 *     <lcp-input-text autocomplete="off" label="Provider NPI" type="number" ng-model="ctrl.verifyEntry.providerNpi"></lcp-input-text>
	 *
	 *     <!-- if you want to set specifically to accept only numbers if type is otherwise. -->
	 *     <input type="text" lcp-numbers-only />
	 *
	 *     ```
	 *     </file>
	 *     </example>
	 *
	 */
	app.directive('lcpNumbersOnly', NumbersOnly);

	function NumbersOnly() {
		var directive = {
			priority: 2,
			restrict: 'A',
			//require : '?ngModel',
			link: linkFunc

		};

		function linkFunc(scope, ele, attrs) {

			if (attrs.lcpNumbersOnly === 'false')return;

			ele.bind('keyup', function (event) {
				var replacedValue = event.target.value.replace(/\D/g, '')
				if (event.target.value != replacedValue) {
					event.target.value = replacedValue
				}
				scope.$apply()
			})
			ele.bind('keypress', function (event) {
					//event.keyCode = event.charCode || event.keyCode

					if (event.shiftKey						 // disallow Shift
						|| ( event.keyCode < 48			 // disallow non-numbers
						|| event.keyCode > 57)
						&& event.keyCode != 46			 // allow delete
						&& event.keyCode != 8				 // allow backspace
						&& event.keyCode != 9				 // allow not tab
						&& event.keyCode != 27			 // allow escape
						&& event.keyCode != 13			 // allow enter
						&& event.keyCode != 39			 // allow right arrow
						&& event.keyCode != 40			 // allow left arrow
						&& !( event.keyCode == 65		 // allow CTRL+A
						&& event.ctrlKey === true)
						&& !( event.keyCode == 67		 // allow CTRL+C
						&& event.ctrlKey === true)
						&& !( event.keyCode == 80		 // allow CTRL+P
						&& event.ctrlKey === true)
					) {
						event.preventDefault()
						scope.$apply()
					}
				}
			)
		}

		return directive;
	};


}
