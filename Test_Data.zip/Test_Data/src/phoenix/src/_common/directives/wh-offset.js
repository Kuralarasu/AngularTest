/**
 * Created by ramor11 on 3/9/2016.
 */


module.exports = function (app) {
	'use strict';

	/**
	 * @ngdoc overview
	 * @name phx.common.whOffset
	 *
	 *
	 * @description
	 *
	 * Set the height of the element based on the window height, if numberic value is passed,
	 * it will substract the offset height.
	 * Leaving the element to its browser default prefix definitions.
	 *
	 *
	 */
	app.directive('whOffset', setHeight)

	setHeight.$inject = ['$window']
	/**
	 * @ngdoc object
	 *
	 * @name phx.common.directive:whOffset
	 * @restrict AE
	 *
	 * @description
	 * Set the height of the element to window.height
	 *
	 * To apply your own custom context menu, apply the directive to the object where you want to build the context menu.
	 *
	 *
	 * @example
	 *
	 * ```html
	 <header class="app-header md-whiteframe-3dp" ui-view name="appHead"></header>
	 Directive appOffset will set style="height: [windowHeight]", by adding a numberic value to the
	 attribute it will offset the windowHeight - offset.

	 header = 67px
	 section = windowHeight - 92
	 footer = 25px

	 <section class="app-body" ui-view name="appBody" data-wh-offset="92"></section>
	 <footer class="app-footer" ui-view name="appFooter"></footer>
	 *```
	 */
	function setHeight($window) {

		var directive = {
			scope: {
				opts: '=whOffset'
			},
			link: funcLink
		};


		function funcLink(scope, element, attr) {

			var resize = function () {
				var opts = {
						offset: 0,
						property: "height"
					},
					offset = opts.offset,
					wh = $window.innerHeight;

				if (Number(scope.opts)) {
					offset = Number(scope.opts) * -1
				}

				if (typeof (scope.opts) === "object") {
					opts = angular.extend({}, opts, scope.opts);
					offset = Number(opts.offset) * -1
				}

				element.css(opts.property, (wh + offset) + 'px');

				if (opts.callback)
					opts.callback.apply(this, element)

			}


			resize();

			$($window).on("resize", resize)

		}


		return directive;
	}


};
