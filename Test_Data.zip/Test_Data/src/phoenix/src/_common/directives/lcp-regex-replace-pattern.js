module.exports = function (app) {
	"use strict";

	/**
	 * @ngdoc directive
	 * @name phxApp.lcpRegex
	 *
	 * @description
	 * This will take two attributes to change the ngModel to a new pattern
	 *
	 *
	 * @example
	 * <example>
	 * <file name="index.html">
	 * ```html
	 * <lcp-input-text autocomplete="off" label="SSN"
	 *        lcp-regex="(\d{3})-?(\d{2})-?(\d{0,})"
	 *        lcp-regex-replace="$1-$2-$3"
	 *        ng-maxlength="11"
	 *        ng-model="ctrl.patientInfo.ssn"></lcp-input-text>
	 * ```
	 * </file>
	 *
	 *
	 * ```
	 * //regex formula for phone numbers
	 * lcp-regex="\(?(\d{3})\)?(\d{3})-?(\d{0,})"
	 * lcp-regex-replace="($1)$2-$3"
	 * ```
	 *
	 *
	 * The example takes the input on keyUp and evaluates the regex given, and replaces the ngModel with lcpRegexReplace
	 *
	 */


	app.directive('lcpRegex', lcpRegex);
	function lcpRegex() {


		var directive = {
			priority: 0,
			restrict: 'A',
			require: 'ngModel',
			link: linkFunc

		};

		function linkFunc(scope, element, attr) {
			if (!attr.lcpRegex || !attr.lcpRegexReplace)
				return;

			var input = element.find('input')[0] ? element.find('input') : element,
				ngModel = input.controller('ngModel');

			input.on("keyup", function (event) {
				var keyCode = event.charCode || event.keyCode;

				if (keyCode === 8 || keyCode >= 37 && keyCode <= 40)
					return;

				if (!this.value) return;

				var re = new RegExp(attr.lcpRegex),
					array = re.exec(this.value),
					result = String(this.value).replace(re, attr.lcpRegexReplace);

				ngModel.$setValidity('lcpRegex', this.value ? (array ? true : false) : true);
				ngModel.$setValidity('pattern', array ? true : false);

				ngModel.$setViewValue(result);
				ngModel.$render();

			})


		}

		return directive;
	}


}

