/**
 * Created by ramor11 on 3/17/2016.
 */

module.exports = function (app) {
	'use strict';


	/**
	 * @ngdoc overview
	 * @name phx.common.jsrSidebar
	 *
	 *
	 * @description
	 *
	 *
	 */
	app.directive('jrvSidebar', JarvisSidebar)

	JarvisSidebar.$inject = ['$timeout', '$document']
	/**
	 * @ngdoc object
	 *
	 * @name phx.common.directive:jrvSidebar
	 * @restrict A
	 *
	 * @description
	 *
	 * @example
	 */
	function JarvisSidebar($timeout, $document) {

		var tk = null,
			directive = {
				restrict: 'A',
				link: funcLink
			};

		function _e(e) {
			return angular.element(e)
		}

		function isNumeric(num) {
			return !isNaN(num) ? Number(num) : 0;
		};

		function delay(callback, event) {
			$timeout.cancel(tk);
			tk = $timeout(function () {
				callback.apply(this, [event]);
			}, 100);
		}

		//taken from jarvisMenu directive
		function $slideup(ele) {
			if ($(ele).find("ul").size() != 0) {
				var ul = $(ele).find("ul");
				$(ul).slideUp(self.jarvisMenu.speed, function () {
					$(this).parent("li").find("b:first").html(self.jarvisMenu.closedSign);
				});
			}
		}

		//taken from jarvisMenu directive
		function $slidedown(ele) {
			if ($(ele).find("ul").size() != 0) {
				var ul = $(ele).find("ul");
				$(ul).slideDown(self.jarvisMenu.speed, function () {
					$(this).parent("li").find("b:first").delay(self.jarvisMenu.speed).html(self.jarvisMenu.openedSign);
				});
			}
		}

		function funcLink(scope, ele, attr) {

			var resize = function () {

				var opts = {
					offset: isNumeric(attr.jrvSidebar),
					target: _e($document[0].querySelector(attr.jrvTarget)),
					tClass: attr.jrvTclass
				};

				function slide(bool) {
					var isClose = opts.target.hasClass(opts.tClass),
						list = ele[0].querySelectorAll('.jarvis-menu.open');

					if (isClose)
						angular.forEach(list, function (el) {
							el[bool ? '$slidedown' : '$slideup'](function () {
								angular.element(el).addClass('open')
							});
						});
				}

				ele.on("webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend", function (e) {
					var isClose = opts.target.hasClass(opts.tClass);
					opts.target[isClose ? 'addClass' : 'removeClass']('animation-end');

				});


				ele.on('mouseenter', function (e) {
					delay(function () {
						var isClose = opts.target.hasClass(opts.tClass);
						if (isClose) {
							opts.target.addClass('aside-mouse-enter');
							slide(isClose);
						}
					}, e);
				}).on('mouseleave', function (e) {
					delay(function () {
						// var top = e.pageY,
						// 	right = document.body.clientWidth - e.pageX,
						// 	bottom = document.body.clientHeight - e.pageY,
						// 	left = e.pageX;
						//
						// if (top < 10 || right < 20 || bottom < 10 || left < 10) {
						// 	//console.log('Mouse has moved out of window');
						// } else {
						opts.target.removeClass('aside-mouse-enter');
						slide(false);
						// }
					}, e);
				})
			};


			resize();

			//$($window).on("resize", resize)

		}


		return directive;
	}


};
