module.exports = function (app) {

	/**
	 * @ngdoc directive
	 * @name phxApp.lcpForm
	 *
	 * @description
	 * It will intercept any form submit functionality within the element.
	 * If the form element contains a button type=submit it will intercept the function and validate the form, before proceeding
	 * as long that the form has required fields.
	 *
	 * If no required fields are present this will not inject and it will not intercept the form.
	 *
	 *
	 * @element A , restricted to attribute to accept additional parameter on directive attribute
	 * @params {function} interceptor function to override lcpForm validator, return true to override
	 *
	 * @example
	 *  <example>
	 * <file name="index.html">
	 * ```html
	 *
	 * <form lcp-form name="evForm270">
	 *  <button type="submit" ng-click="sendToService()">Submit</button>
	 *  </form>
	 * OR
	 *  <form lcp-form name="evForm270" ng-submit="sendToService()">
	 *  <button type="button" >Submit</button>
	 *  </form>
	 *
	 *  ```
	 *  </file>
	 *  </example>
	 *
	 */

	app.directive('lcpForm', LabCorpForm);

	LabCorpForm.$inject = ['$parse', 'phxCommonMessenger', '$rootScope', '$log'];
	function LabCorpForm($parse, lcdMessage, $rootScope, $log) {
		var directive = {
			priority: 0,
			restrict: 'A',
			require: 'form'
		};

		//directive.controller = function(scope, ele, attrs) {
		//	scope.$on('clearForm', function() {
		//		$log.log('ctrl.clearForm event heard');
		//	});
		//	scope.$on('clearForm', function(e, adjustment) {
		//		scope.$apply();
		//		$log.log('ctrl.clearForm event heard, event handler', e, adjustment);
		//	});
		//	scope.$on('clearForm2', function() {
		//		$log.log('ctrl.clearForm2 event heard');
		//	});
		//	scope.$on('clearForm2', function(e, adjustment) {
		//		scope.$apply();
		//		$log.log('ctrl.clearForm2 event heard, event handler', e, adjustment);
		//	});
		//};
		directive.link = {
			pre: function (scope, ele, attrs, ctrl) {
				attrs.$set('novalidate', 'novalidate');
				scope.$on('clearForm', function () {
					$log.log('clearForm event heard');
				});
				scope.$on('clearForm', function (e, adjustment) {
					scope.$apply();
					$log.log('clearForm event heard, event handler', e, adjustment);
				});
				scope.$on('clearForm2', function () {
					$log.log('clearForm2 event heard');
				});
				scope.$on('clearForm2', function (e, adjustment) {
					scope.$apply();
					$log.log('clearForm2 event heard, event handler', e, adjustment);
				});
			},
			post: function (scope, ele, attrs, ctrl) {
				$log.log('lcpForm.ctrl', ctrl, scope);

				if (!attrs.name) {
					throw ('MUST HAVE ATTRIBUTE NAME');
					return;
				}

				var required = ele[0].querySelectorAll('[required]'),
					eventsListeners = 'click submit'.split(' '),
					forceAsyncEvents = {
						'blur': true,
						'focus': true
					},
					submitButton = angular.element(ele[0].querySelectorAll('button[type="submit"]')),
					element = submitButton,
					clearButton = angular.element(ele[0].querySelector('.page-action-btn .phx-btn-flat:not([type="submit"])'));

				Object.keys(attrs).forEach(function (key) {
					for (var i in eventsListeners)
						if (String(key).toLocaleLowerCase().indexOf(eventsListeners[i]) !== -1) {
							element = attrs[key] ? ele : submitButton;
						}
				});

				function resetDatepickers() {
					var dateInputs = ele[0].querySelectorAll('.md-datepicker-input');
					// We have to iterate over each input to check if has a default date value
					// assigned by its form controller, e.g., Service Date on the EV 270 form:
					angular.forEach(dateInputs, function(item) {
						item = angular.element(item);
						if (!item.scope().ctrl.date) {
							item.val('');
						}
						item.triggerHandler('input');
					});
				}

				clearButton.on('click', resetDatepickers);


				if (element[0]) {
					angular.forEach(element[0].attributes, function (key) {
						for (var i in eventsListeners) {
							if (key.nodeName.indexOf(eventsListeners[i]) !== -1) {
								//We expose the powerful $event object on the scope that provides access to the Window,
								//etc. that isn't protected by the fast paths in $parse.  We explicitly request better
								//checks at the cost of speed since event handler expressions are not executed as
								//frequently as regular change detection.
								var fn = $parse(element.attr(key.nodeName), /* interceptorFunction */ null, /* expensiveChecks */ true),
									isFunc = typeof($parse(attrs.lcpForm)) === 'function';

								element.unbind(eventsListeners[i]).on(eventsListeners[i], function (event) {

									function oFuncCb() {
										ctrl.$submitted = true;

										var oFunc = $parse(attrs.lcpForm, null, true)(scope, {$event: event});

										return typeof oFunc === "undefined" && isFunc ? true : oFunc;

									}


									function overrideFormController(callback) {
										scope[forceAsyncEvents[eventsListeners[i]] && $rootScope.$$phase ? '$evalAsync' : '$apply'](callback);
									}

									function lcpFormAttr() {
										if (attrs['lcpForm']) {
											if (oFuncCb()) {
												overrideFormController(callback);
											}
										}
									}

									function callback() {
										fn(scope, {$event: event});
									}

									// The main section of code is here. We will call this after a delay (via $timeout)
									// if one or more datepickers is present, to give them time to update their validity:
									function processForm() {
										// if the form is not valid
										if (ctrl.$invalid) {
											$log.log('lcpForm.$error', ctrl.$error);
											if (ctrl.$error.required) {
												lcdMessage.error('Required fields missing');
											}
											if (ctrl.$error.valid) {
												angular.forEach(ctrl.$error.valid, function (item) {
													if (item.$name) {
														var datepicker = angular.element(ele[0].querySelector('[name="' + item.$name + '"]'));
														var label = datepicker.parent().find('label').text();
														// Don't show an invalid error message if the datepicker's INPUT is not empty:
														if (datepicker.find('input').val()) {
															lcdMessage.growl({
																// Add custom class names for detection in view controllers:
																class: 'error error-invalid error-invalid-' + item.$name,
																message: (label ? label : 'A field') + ' is invalid'
															});
														}
													}
												});
											}
											lcpFormAttr();
											return false;
										} else {
											if (attrs['lcpForm']) {
												if (oFuncCb()) {
													overrideFormController(callback);
												}
											} else {
												overrideFormController(callback);
											}
										}
									}

									lcdMessage.removeAll();
									var dateInputs = ele[0].querySelectorAll('.md-datepicker-input');
									if (dateInputs.length) {
										angular.element(dateInputs).triggerHandler('input');
										$timeout(processForm, 300); // allow the datepickers to set their validity
									} else {
										processForm();
									}
								});
							}
						}
					});
				}
			}//end of post
		}

		return directive;
	};


}
