module.exports = function (app) {

	"use strict";

	/**
	 * @ngdoc directive
	 * @name lcpPatternReplace
	 * @restrict A
	 *
	 * @description
	 * This will take the model and change the chars based on the mask pattern, while keeping in tack the original
	 * model value.
	 *
	 * The input mask will only apply on blur. While on focus it will return the original model value.
	 *
	 *
	 * @example
	 * <example>
	 * <file name="index.html">
	 * ```html
	 * <lcp-input-text autocomplete="off" label="SSN"
	 *        lcp-pattern-replace="***-**"
	 *        ng-maxlength="11"
	 *        ng-model="ctrl.patientInfo.ssn"></lcp-input-text>
	 * ```
	 * </file>
	 *
	 */


	app.directive('lcpPatternReplace', lcpPatternReplace);
	lcpPatternReplace.$inject = ['$compile', '$timeout']

	function lcpPatternReplace($compile, $timeout) {

		var directive = {
			priority: 8,
			restrict: 'A',
			require: ['ngModel', '^form'],
			scope: false
		};

		directive.link = function (scope, element, attr, ctrl) {
			var //ngModel = element.controller('ngModel'),
				pattern = attr.lcpPatternReplace,
				input = element.find('input'),
				ngModel = ctrl[0];

			var notAllowedAttr = ['ngModel', 'lcpPatternReplace', 'label']

			//element.append(inputClone)
			$timeout(function () {

				var inputClone = input.clone(),
					unique = Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1) + Date.now().toString();

				inputClone[0].removeAttribute(attr.$attr.ngModel)
				inputClone.attr(attr.$attr.ngModel, 'lcpPatternReplace[\'' + unique + '\']')
				Object.keys(attr.$attr).forEach(function (key) {
					//console.log(attr.$attr[key], attr[key])
					if (notAllowedAttr.indexOf(key) === -1)
						inputClone.attr(attr.$attr[key], attr[key])
				});

				$compile(inputClone)(scope);
				input.replaceWith(inputClone);
				var cloneNgModel = inputClone.controller('ngModel');

				inputClone.on("blur", function (event) {
					var string = angular.copy(this.value),
						newString = "";

					inputClone[string !== "" ? 'addClass' : 'removeClass']('ng-not-empty');


					for (var i in string) {
						if (!isNaN(i))
							!function (i) {
								newString += i < pattern.length ? pattern[i] : string[i];

							}(i)
					}

					this.value = newString;

					if (Object.keys(cloneNgModel.$error).length) {
						angular.forEach(cloneNgModel.$error, function (key, val) {
							console.log('cloneNgModel', val, !key)

							ngModel.$setValidity(val, !key);
						});
					} else {
						angular.forEach(ngModel.$error, function (key, val) {
							console.log('ngModel', val, key)

							ngModel.$setValidity(val, key);
						});
					}

					//if there is a form, update the validity
					if (ctrl[1]) {
						ctrl[1][ngModel.$name] = ngModel;
					}

					ngModel.$setViewValue(string);
					ngModel.$render();

				}).on('focus', function (event) {
					this.value = ngModel.$modelValue;
				})


			}, 0, false)

		}

		return directive;
	}


}

