/**
 * @ngdoc directive
 * @name lcpSelectbox
 *
 * @description
 * It will automatically create the elements needed to create a custom dropdown base on LabCorp Style Guide.
 * The lcpSelectbox directive allows you to specify custom behaviour when element is clicked.
 *
 * It will accept numerous different element set as attributes or objects.
 *
 *
 * @element EA
 *
 *
 * @params {expression} lcpSelectbox {@link object/expression} to evaluates options upon
 *
 * lcpSelectbox additional accepted attributes.
 * @params {class, name, label, id, placeholder, options, selected} Insert the class on parent container
 *
 * @example
 <example>
 // <file name="controller.js">
 // ```js
 // $scope.lcpSelectboxOpts = {
	// 	placeholder: 'Service Types',
	// 	options: self.ServiceType, //it can be an array of strings, or array of objects {name:'string', value: 'string', selected:'{optional:boolean}'}
	// 	//selected:defaultValueDropDown, //this is not binded which it will depend on callback onSelected change
	// 	//'class':'', //add a custom class to ul element container
	// 	name: "serviceTypes",
	// 	id: "serviceTypes",
	// 	column:0; //its a class referent of the column, default is 3, where it will add the class associated
	// 	search:true, //allow filtering default false
	// 	//Will be trigger on drop down selected
	// 	onSelected: function () {
	// 		//callback function to perform other stuff,
	// 		//returns arguments
	// 		//self.verifyEntry.serviceTypeId = arguments[0].value;
	// 	}
 // 	}
 // ```
 // </file>


 <file name="index.html">
 // ```html
 //
 // <lcp-select-box lcp-select-box-opts="ctrl.serviceTypesOpts" ng-model="ctrl.verifyEntry.serviceTypeId"></lcp-select-box>
 //
 // //Either options will load the necessary variables into lcpSelectbox directive
 //
 // <lcp-selectbox id="serviceTypes" name="serviceTypes" options="ctrl.ServiceType" placeholder="Service Types"
 // ng-model="ctrl.verifyEntry.serviceType"></lcp-selectbox>

 ```
 </file>
 </example>
 *
 * A collection of attributes that allows creation of custom event handlers that are defined as
 * angular expressions and are compiled and executed within the current scope.
 *
 */

 require('./lca-dropdown.less');

Dropdown.$inject = ['$timeout', '$compile', '$window'];

function Dropdown($timeout, $compile, $window) {
	var directive = {
			restrict: 'E',
			scope: {
				placeholder: "@",
				textField: '@',
				options: '=options',
				ngModel: '=ngModel'
			},
			bindToController: true,
			controllerAs: 'lcadd',
			controller: ['$scope', controllerFunc],
			template: ['<div class="lcpSelectBoxContainer">',
							'<div class="lcpSelectbox dropdown ">',
								'<a class="trigger dropdown-toggle" data-toggle="dropdown"><span class="arrow"></span></a>',
								'<div class="dropdown-menu" >',
									'<ul class="lcpSelectMenu">',
										'<li ng-repeat="option in lcadd.options" ng-click="lcadd.optionClick($event)" ng-class="{active: lcadd.ngModel == option[lcadd.textField]}">',
											'<a class="truncate" title="{{option[lcadd.textField]}}">{{option[lcadd.textField]}}</a>',
										'</li>',
									'</ul>',
								'</div>',
								'<div class="lcpInputTxtGrp">',
									'<input type="text" name="ruleActions" placeholder="Select" ng-model="lcadd.ngModel" class="truncate lca-dd-input" title="{{lcadd.ngModel}}">',
								'</div>',
							'</div>',
						'</div>'].join(''),
			replace: true,
			link: linkFunc
		};


	function controllerFunc(scope) {
		this.selection = this.ngModel;
		if(!this.textField) {
			this.textField = 'value';
		}
		this.optionClick = function(e) {
			var selection = e.target.text;
			e.stopPropagation();
			var openParent = this.getParentWithClass($(e.target), 'dropdown');
			if (openParent) {
				var trigger = $(openParent).find('a');
				var inputElem = $(openParent).find('input');
				trigger.removeClass('open');
				scope.hideDropDown();
				this.ngModel = selection;
				//this.selection = selection;
			} else {
				console.log('no openParent found');
			}
		}


		this.getParentWithClass = function(elem, targetClass) {
			if (elem.parent()[0].className && elem.parent()[0].className.length > 0) {
				var classList = elem.parent()[0].className.split(/\s+/);
				if (classList.indexOf(targetClass) > -1) {
					return elem.parent();
				}
			}
			return this.getParentWithClass(elem.parent(), targetClass);
		}

		// scope.$watch('lcadd.ngModel', function(nval, oldval){
		// 	if(nval != oldval && nval){
		// 		scope.lcadd.selection = nval;
		// 	}
		// })


	}

	function linkFunc(scope, ele, attr, _lsb) {

		//console.log("link entry.ngModel: ",scope.inputValue, this.inputValue, scope);
		var trigger = ele.find('a');
		var inputElem = ele.find('input');
		if (trigger.length > 1) {
			trigger.forEach(function(el) {
				//console.log('trigger element: ', el);
			})
		} else {
			//console.log('dropdown: single trigger element: ', trigger, ele);
		}
		trigger.on('click', onFocus);

		function onFocus(event) {
			//console.log('dd1.onFocus: ', event, trigger, inputElem);
			event.stopPropagation();
			event.preventDefault();
			//console.log('dd.onFocus: ', event, trigger, inputElem);
			if (!trigger.hasClass('open')) {
				trigger.addClass('open');
				$('.dropdown-menu', ele).show();
			}
		}


		$('.lcpSelectbox.dropdown', ele).on('hide.bs.dropdown', function () {
		    	scope.hideDropDown();
		});


		scope.hideDropDown = function(){
			 $('.dropdown-menu', ele).hide();
		     $('a', ele).removeClass('open');
		}




	}

	return directive;
};


module.exports = function (app) {
	app.directive('lcaDropdown', Dropdown).filter('lcpSelectBoxSearch', function () {
		return function (input, model) {

			var handler = [], refused = [], index;

			if (model) {
				for (var i in input) {
					if (String(input[i].name).toLowerCase().indexOf(model.toLowerCase()) !== -1 || String(input[i].value).toLowerCase().indexOf(model.toLowerCase()) !== -1) {
						handler.push(input[i])
						index = i;
					} else {
						refused.push(input[i]);
						delete input[i].selected;
					}
				}

				if (handler.length === 1) {
					if (input[index])
						input[index].selected = true;
					handler = input;
				}
			} else {
				for (var i in input) {
					delete input[i].selected;
				}
			}
			if (!handler.length) {
				handler = input;
			}

			if (handler.length < input.length) {
				handler = handler.concat(refused)
			}

			return handler;
		};
	});
};

