/**
 * @ngdoc directive
 * @name lcpSelectbox
 *
 * @description
 * It will automatically create the elements needed to create a custom dropdown base on LabCorp Style Guide.
 * The lcpSelectbox directive allows you to specify custom behaviour when element is clicked.
 *
 * It will accept numerous different element set as attributes or objects.
 *
 *
 * @element EA
 *
 *
 * @params {expression} lcpSelectbox {@link object/expression} to evaluates options upon
 *
 * lcpSelectbox additional accepted attributes.
 * @params {class, name, label, id, placeholder, options, selected} Insert the class on parent container
 *
 * @example
 <example>
 <file name="controller.js">
 ```js
 $scope.lcpSelectboxOpts = {
		placeholder: 'Service Types',
		options: self.ServiceType, //it can be an array of strings, or array of objects {name:'string', value: 'string', selected:'{optional:boolean}'}
		selected: 30, //set the default value, if its a boolean it will be empty
		name: "serviceTypes",
		id: "serviceTypes",
		column:1; //its a class referent of the column, default is 3, where it will add the class associated
		search:true, //allow filtering default true
		//Will be trigger on drop down selected
		onSelected: function () {
			//callback function to perform other stuff,
			//returns arguments
			//self.verifyEntry.serviceTypeId = arguments[0].value;
		}
 	}
 ```
 </file>


 // <file name="index.html">
 // ```html
 //
 // <lcp-select-box lcp-select-box-opts="ctrl.serviceTypesOpts" ng-model="ctrl.verifyEntry.serviceTypeId"></lcp-select-box>
 //
 // //Either options will load the necessary variables into lcpSelectbox directive
 //
 // <lcp-selectbox id="serviceTypes" name="serviceTypes" options="ctrl.ServiceType" placeholder="Service Types"
 // ng-model="ctrl.verifyEntry.serviceType"></lcp-selectbox>
 //
 // ```
 </file>
 </example>
 *
 * A collection of attributes that allows creation of custom event handlers that are defined as
 * angular expressions and are compiled and executed within the current scope.
 *
 */

ComboBox.$inject = ['$timeout'];
function ComboBox($timeout) {
	var directive = {
		restrict        : 'E', /*It can be either one, if its an attribute it is expected to have an object for its parameters */
		priority        : 10,
		scope           : {
			placeholder: '@',
			name	: '@',
			column	: '@',
			id		: '@',
			options : '=?', //an array of items to pass into the select dropdowns
			selected: '=?ngModel',
			opts    : '=?lcpSelectBox' //if this object exist, it will override the existing attributes in the element
		},
		controller      : ctrlFunc,
		controllerAs    : 'ctrl',
		bindToController: true,
		template	    : require('html!./lcp-combo-box.html'), //'/lcp/dropdown/lcpDropdown.html',
		replace         : true,
		link            : linkFunc
	};

	function ctrlFunc($scope) {
		console.log('combo ctrl');

		var self = this;
		//	element = false,
		//	optionsCopy = []; //store pending keyevents
        //
		//self.inputValue = {};
		//console.log('ctrl options: ', self.options, $scope.options);
		////self.options = []; //array to contain all the options
		//self.open = false;
		//self.pending = null;
        //
		////set for watch
		//$scope.options = self.options;
		//console.log("options: ", self.options);
        //
		////lets watch for changes
		//$scope.$watchGroup([function () {
		//	console.log('watch1: ', self.opts.options);
		//	return self.opts.options || false
		//}, 'options', function () {
		//	console.log('watch2: ', self.opts.selected);
		//	return self.opts.selected
		//}], function (opts) {
		//	console.log('watch3: ', opts);
		//	var options = opts[0] || opts[1];
        //
		//	if (!options || !options.length)return;
		//	self.buildDropDowns(options);
        //
		//}.bind(self));
        //
		//self.setModel = function (obj) {
		//	for (var i in self.options) {
		//		delete self.options[i].selected
		//		if (obj) {
		//			if (obj && obj.value === self.options[i].value) {
		//				obj.selected = true;
		//				self.options[i].selected = true;
		//				self.inputValue = angular.copy(obj);
		//				self.selected = obj.value;
		//				self.opts.selected = obj.value;
		//			}
		//			self.open = false;
        //
		//		} else {
		//			self.opts.selected = "";
		//			self.selected = "";
		//			self.inputValue = {};
		//		}
		//	}
        //
		//}
        //
		///**
		// * Function that takes the object and builds the UL.LI from the object
		// * Must have the following keys
		// * @param obj - {name:'', value:''}
		// */
		//self.buildDropDowns = function (objs) {
		//	self.options = [];
		//	element = arguments[1] ? arguments[1] : element;
		//	var selectedObject = null;
        //
		//	if (!objs)return;
		//	var arr = angular.isArray(objs) ? objs : [objs];
		//	angular.forEach(arr, function (obj) {
		//		if (!obj.hasOwnProperty('value') && typeof obj === 'string') {
		//			obj = {
		//				name : String(obj).trim(),
		//				value: String(obj).trim()
		//			};
		//		}
        //
		//		if (typeof (self.opts.selected) === "boolean")
		//			delete obj.selected;
        //
		//		if (!selectedObject && obj.selected) {
		//			selectedObject = obj;
		//		}
        //
		//		if (self.opts.selected === obj.value) {
		//			selectedObject = obj;
		//		}
        //
		//		self.options.push(obj)
		//	})
        //
        //
		//	optionsCopy = angular.copy(self.options);
		//	self.setModel(selectedObject)
		//	setColumnsWidth();
		//};
        //
		///**
		// * Function to set the widths of the columns
		// * bases on the passed options
		// */
		//function setColumnsWidth() {
		//	if (!self.opts.column)return;
		//	$timeout(function () {
		//		var listItems = element ? element[0].querySelectorAll('li') : [];
		//		angular.forEach(listItems, function (item, index) {
		//			var ele = angular.element(item);
		//			ele.css({width: Number(100 / self.opts.column) + '%', float: 'left'})
		//			if (index >= listItems.length - (listItems.length % self.opts.column)) {
		//				ele.css({'padding-bottom': '0px'});
		//			}
		//		})
		//	}, 1)
		//};

		self.onSelection = function (event, obj) {
			var selection = e.target.text;
			//event.preventDefault();
			event.stopPropagation();
			var openParent = this.getParentWithClass($(e.target), 'dropdown'); //should this come from link
			if (openParent) {
				var trigger = $(openParent).find('a');
				var inputElem = $(openParent).find('input');
				trigger.removeClass('open');
				this.ngModel = selection;
				this.selection = selection;
			} else {
				console.log('no open Parent found');
			}
			//delete self.inputValue.selected;
			//self.setModel(obj);
			////if there is a callback
			//if (self.opts.onSelected) {
			//	self.opts.onSelected.apply(event, [obj])
			//}
		};

		self.getParentWithClass = function(elem, targetClass) {
			console.log('elem: ', elem);
			if (elem.parent()[0].className && elem.parent()[0].className.length > 0) {
				var classList = elem.parent()[0].className.split(/\s+/);
				if (classList.indexOf(targetClass) > -1) {
					return elem.parent();
				}
			}
			return this.getParentWithClass(elem.parent(), targetClass);
		};

		//self.onKeyUp = function (event) {
		//	var obj = self.options,
		//		handler = [],
		//		refused = [];
        //
		//	if (event.keyCode === 13) {
		//		self.setModel(self.pending);
		//		self.pending = null;
		//		return;
		//	}
        //
		//	if (self.inputValue.name && event.keyCode !== 8) {
		//		var model = self.inputValue.name.toLowerCase();
        //
		//		for (var i in obj) {
		//			var value = String(obj[i].value).toLowerCase(),
		//				name = String(obj[i].name).toLowerCase(),
		//				isName = name.indexOf(model) !== -1 ? true : false,
		//				isValue = value.indexOf(model) !== -1 ? true : false;
        //
        //
		//			if (isName || isValue) {
		//				handler.push(obj[i])
        //
		//				if ((isValue && model === value) || (isName && model === name) || handler.length === 1) {
		//					obj[i].selected = true;
		//					self.pending = obj[i];
		//				}
		//			} else {
		//				refused.push(obj[i]);
		//				delete obj[i].selected;
		//			}
		//		}
        //
		//		self.options = handler.concat(refused)
		//	} else {
		//		self.setModel();
		//		self.options = optionsCopy;
		//	}
		//}

	}

	function linkFunc(scope, ele, attr, ctrl) {
		console.log('combo link');

		var trigger = ele.find('a');
		var inputElem = ele.find('input');
		if (trigger.length > 1) {
			trigger.forEach(function(el) {
				console.log('trigger element: ', el);
			})
		} else {
			console.log('single trigger element: ', trigger, ele);
		}
		trigger.on('click', onFocus);

		function onFocus(event) {
			console.log('onFocus: ', event, trigger, inputElem);
			event.stopPropagation();
			if(!trigger.hasClass('open')) {
				trigger.addClass('open');
			}
		}

		//ctrl.opts = angular.extend({}, {
		//	placeholder: attr.placeholder,
		//	options    : ctrl.options,
		//	name       : attr.name,
		//	id         : attr.id || Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1) + Date.now().toString(),
		//	selected   : ctrl.selected,
		//	column     : attr.column || 3
		//}, ctrl.opts || {});
        //
		//console.log("link ctrl.opts: ", ctrl.opts);
        //
		//ctrl.buildDropDowns(ctrl.opts.options, ele)
        //
		//var trigger = ele.find('a').on('click', onFocus),
		//	input = ele.find('input').attr({
		//		id  : ctrl.opts.id,
		//		name: ctrl.opts.name
		//	})
		//		.addClass('truncate')
		//		.css({'padding-right': '25px'})
		//		.on('focus', onFocus)
		//		.on('blur', function (e) {
		//			$timeout(function () {
		//				ctrl.open = false;
		//				scope.$digest();
		//				if (ctrl.pending !== null)
		//					ctrl.setModel(ctrl.pending)
		//			}, 200)
		//		});
        //
		//function onFocus(e) {
		//	if (!trigger.hasClass('open')) {
		//		ctrl.open = true;
		//		scope.$digest();
		//		input[0].focus();
		//	}
		//}
        //
		////remove these from the element we don't need them there
		//Object.keys(attr.$attr).forEach(function (key) {
		//	if (key !== 'class' && key !== 'id' && key !== 'ngClass')
		//		ele.removeAttr(attr.$attr[key]);
		//});
        //
		//input.attr({'name': ctrl.opts.id})
        //
		//Object.keys(attr).forEach(function (key) {
		//	switch (key) {
		//		case 'disabled':
		//			input.attr('disabled', true)
		//			break;
		//		case 'required':
		//			input.attr({'required': true})
		//			break;
		//		case 'name':
		//			input.attr({'name': attr.name})
		//			break;
		//		default :
		//			break;
        //
		//	}
		//});

	}

	return directive;
};


module.exports = function (app) {
	app.directive('lcpComboBox', ComboBox).filter('lcpSelectBoxSearch', function () {
		return function (input, model) {
			//todo: do something awesome here
			//currently this is in a key function
			return input;
		};
	});
};

