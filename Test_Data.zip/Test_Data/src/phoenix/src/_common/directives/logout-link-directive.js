module.exports = function (app) {
	'use strict';

	logoutLink.$inject = ['authService'];

	app.directive('lcpLogoutLink', logoutLink);

	function logoutLink(authService) {

		var directive = {};

		directive.restrict = 'A';

		directive.link = function postLink($scope, element) {
			$(element).click(function () {
				console.log('logout link is clicked ');
				authService.doLogout();
			});
		};

		return directive;
	};


}
