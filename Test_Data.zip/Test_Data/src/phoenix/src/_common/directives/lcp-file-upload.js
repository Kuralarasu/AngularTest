module.exports = function (app) {
	"use strict";

	app.directive('fileUpload', fileUpload);

	function fileUpload() {
		var directive = {};
		directive.restrict = 'E';
		directive.replace = true;
		directive.scope = {
			file: '=',
			onFileChange: '&'
		};
		directive.template = '<input type="file">';
		directive.link = link;

		/**
		 * @name link
		 * @desc File Upload Link
		 * @type {Function}
		 */
		function link($scope, $element) {
			$element.on('change', function (e) {
				var files = e.target.files;
				$scope.file = files[0];
				if ($scope.onFileChange) {
					$scope.$apply(function () {
						$scope.onFileChange({files: files});
					});
				}
			});

		}

		return directive;
	}


}
