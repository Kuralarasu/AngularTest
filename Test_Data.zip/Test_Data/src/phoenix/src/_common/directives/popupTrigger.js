module.exports = function (app) {

	app
		.directive('popup', Popup)
		.directive('popupHeader', PopupHeader)
		.directive('popupActionClose', PopupActionClose)
		.directive('popupTrigger', PopupTrigger)
		.factory('popupService', PopupService);

	PopupTrigger.$inject = ['$window', '$document', '$templateCache', '$compile', 'popupService'];
	Popup.$inject = ['popupService'];
	PopupHeader.$inject = ['$window', '$document'];
	PopupActionClose.$inject = ['$rootScope', '$parse'];

	function PopupService() {
		return {
			items: {}
		};
	}

	function PopupTrigger($window, $document, $templateCache, $compile, popupService) {
		return {
			restrict: 'A',
			scope: {
				id: '@popupTrigger',
				title: '@popupTitle',
				context: '=popupContext',
				width: '@popupWidth',
				height: '@popupHeight'
			},
			link: function (scope, element, attr) {
				element.on('click', function (e) {
					show();

					if (typeof attr.stopPropagation !== 'undefined') {
						e.stopPropagation();
					}
				});

				scope.$on('$destroy', function(){
					element.off('click');
				});

				function show() {
					if (popupService.items.hasOwnProperty(scope.id)) {
						return;
					}

					popupService.items[scope.id] = true;

					var popupTpl = angular.element($templateCache.get('phx.popupTrigger.html'));
					var bodyTpl = angular.element($templateCache.get(attr.popupTemplate));

					var popupBody = popupTpl[0].querySelector('#popup-body');
					angular.element(popupBody).append(bodyTpl);

					var linkTo = $compile(popupTpl[0]);

					var popupScope = scope.$new();
					popupScope.context = scope.context;

					var popup = linkTo(popupScope);

					var $element = $(element),
						pos = $element.offset(),
						height = $element.height(),
						width = parseInt(scope.width) || $element.width(),
						left =
							pos.left + width / 2 > $window.innerWidth - 20
								? pos.left - width
								: pos.left - width / 2 < 20
								? pos.left
								: pos.left - width / 2,
						top = pos.top + height;

					popup.css({left: left + 'px', top: top + 'px'});
					popup.attr('popup-id', scope.id);

					$document.find('body').append(popup);
				}
			}
		}
	}

	function Popup(popupService) {
		return {
			restrict: 'A',
			controller: ['$scope', '$element', function (scope, element) {
				this.element = element;

				this.destroy = function () {
					delete popupService.items[element.attr('popup-id')];

					element.remove();
					scope.$destroy();
				}
			}],
			// link: {
			//    pre: function preLink(scope, element, attr) {
			//       var pos = $(element).position();
			//       element.css({left: pos.left + 'px', top: pos.top + 'px'});
			//    }
			// }
		}
	}

	function PopupHeader($window, $document) {
		return {
			restrict: 'A',
			require: '^^popup',
			link: {
				pre: function preLink(scope, element, attr, parent) {
					element.attr('draggable', true);
				},
				post: function (scope, element, attr, parent) {
					var onDragover = function (event) {
						event.preventDefault();
					};

					var x = 0,
						y = 0;

					element.bind('mousedown', function (e) {
						x = e.offsetX;
						y = e.offsetY;
					});

					element.bind('drag', function (event) {
						var left = event.clientX - x,
							top = event.clientY - y;

						// TODO: use popup width and height instead of -50
						if (left >= 0 && left <= $window.innerWidth - 50) {
							parent.element.css('left', left + 'px');
						}

						if (top >= 0 && top <= $window.innerHeight - 50) {
							parent.element.css('top', top + 'px');
						}
					});

					$document.find('body').bind('dragover', onDragover);

					scope.$on('$destroy', function () {
						$document.find('body').unbind('dragover', onDragover);
					});
				}
			}
		}
	}

	function PopupActionClose($rootScope, $parse) {
		return {
			restrict: 'A',
			require: '^^popup',
			link: function (scope, element, attr, ctrl) {
				var fn = $parse(attr.popupActionClose);
				element.on('click', function () {
					fn(scope);
					ctrl.destroy();
					$rootScope.$digest();
				});

				scope.$on('$destroy', function () {
					element.off('click');
				})
			}
		}
	}
};
