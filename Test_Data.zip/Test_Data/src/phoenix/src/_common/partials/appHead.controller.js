module.exports = function (app) {
	'use strict';

	app.controller('phxCommonTopNavigationController', TopNavigationCtrl);

	TopNavigationCtrl.$inject = ['$rootScope', 'userService', 'helpRouteService', '$filter', 'phxState', '$templateCache'];

	function TopNavigationCtrl($rootScope, userService, helpRouter, $filter, phxState, $templateCache, $location) {

		var self = this,
			uiMap = phxState.uiResourceMap,
			phxModules = $filter('orderBy')(uiMap.DisplayName, 'order');

		self.imageUrl = "../../assets/CovanceLogoClear.png";

		self.imageUrlLogo = "../../assets/EORLogo_White.png";

		$rootScope.$on('userInfoDetails', function (event, data) {
  			self.userObject = data;
		});
		self.phxModules = [];
		self.phxPrimaryModules = [];

		//customize the application header branding
		self.applicationBranding = uiMap._applicationBranding || $templateCache.get('/phx/application.branding.tpl.html');

		angular.forEach(phxModules, function (phx) {

			if (phx.order > -1) {

				var param = {
					name: phx.name,
					state: phx.source.maps ? phx.source.maps.filter(function (obj) {
						return obj.id === phx.source.auth[0];
					})[0].state : "dashboard",
					map: phx.source.auth ? phx.source.auth[0] : ""
				};

				if (phx.position === 'secondary') {
					self.phxModules.push(param)
				} else if (!angular.isDefined(phx.position) || phx.position === 'primary') {
					self.phxPrimaryModules.push(param)
				}

			}

		});


		self._getUser = function () {
			return userService.getUserName();
		};

		// this method is to disable/enable the links based on role, refer to user-service.js for id's
		// this method is directly accessible from html templates
		self._isDisabled = function (_id) {
			return !userService.canAccess(_id);
		};


		self.onIconClick = function (menuName, alien) {

			var _this = this;

			function fnc() {
				console.log('DOES NOTHING RIGHT NOW');
			};


			switch (menuName) {
				case 'HELP':
					var hRoute = helpRouter.get();
					console.log('hRoute', hRoute);
					hRoute.external ? helpRouter.opener(function () {
						_this.activeMenuPanel = "MENU";
					}) : fnc.apply(this);

					break;
				default:
					fnc.apply(this)
					break;
			}
		}
	}
};

