module.exports = function (app) {
	'use strict';
	app.controller('common.ctrls.appMessagesCtrl', AppMessagesCtrl);

	AppMessagesCtrl.$inject = ['$rootScope', 'MsgHistoryService'];


	/**
	 *
	 */
	function AppMessagesCtrl(rootScope, _msgHistoryService) {

		this.appmessages = _msgHistoryService.getMessagesHistory();
		this.sort = {prop: 'date', dir: true, count: 1};
		this.sortBy = function (_prop) {

			if (this.sort.prop == _prop) {

				this.sort.dir = !this.sort.dir;
				this.sort.count = this.sort.count == 1 ? 2 : 1;

			} else {
				this.sort.prop = _prop;
				this.sort.dir = true;
				this.sort.count = 1;
			}

		}

	};

}

