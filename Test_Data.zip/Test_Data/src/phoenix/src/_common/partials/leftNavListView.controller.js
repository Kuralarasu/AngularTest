/**
 * Created by ramor11 on 3/11/2016.
 */
module.exports = function (app) {
	'use strict';


	app.controller('phxCommonAsideNavigationController', AsideNavigationController)

	AsideNavigationController.$inject = ['userService', 'sidebarSvc', '$rootScope', '$state'];

	function AsideNavigationController(userService, sidebarSvc, $rootScope, $state) {
		var self = this;


		self.jarvisMenu = {
			closedSign: '<i class="material-icons">arrow_drop_down</i>',
			openedSign: '<i class="material-icons">arrow_drop_up</i>',
			accordion: false,
			speed: 200
		};


		//this method is to find state based on Id.
		//this method is directly accessible from html templates
		self._getAccess = function (_id, _params) {
			//var _stateToGo = userService.canAccess(_id);
			//_params = _params ? _params : {};
			//if (_stateToGo) {
			//
			//	$state.go(_stateToGo, _params, { inherit: false}).finally(function () {
			//		$log.log('GET_ACCESS', _stateToGo, _params);
			//	});
			//}
		};


		self.toggleSideBar = function (e) {
			var ele = document.querySelector('body'),
				_class = 'aside-close',
				list = ele.querySelectorAll('.jarvis-menu.open');

			ele.classList.toggle(_class);

			var sbStatus = ele.className.indexOf(_class) > -1,
				target = e ? e.target : false;

			if (target)
				target.innerHTML = sbStatus ? 'chevron_right' : 'chevron_left';
			angular.forEach(list, function (el) {
				el[sbStatus ? '$slideup' : '$slidedown'](function () {
					angular.element(el).addClass('open')
				});
			});
		};

		self._isDisabled = function (_id) {
			return !userService.canAccess(_id);
		};

		self._getUser = function () {
			return userService.getUserName();
		};


		self.closeSidebar = function() {
			sidebarSvc.closeSidebar();
			var appMain = document.getElementById('appMain');
			if (appMain) {
				appMain.focus();
			}
		}


		self.forceStateReload = function(state) {
			//debugger;

			console.log($state.current);
			console.log($rootScope.stateHistory[$rootScope.stateHistory.length-1]);

			if ($state.current.name != state ) {

				$state.go(state, {}, {reload: true});

			}


		}


	}

};
