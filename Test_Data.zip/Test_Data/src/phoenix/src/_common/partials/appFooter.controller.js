
module.exports = function (app) {
	'use strict';


	app.controller('phxCommonFooterController', footerCtrl);

	function footerCtrl() {

		var vm = this;

		var now = new Date();
		var theYear = now.getFullYear();
		if (theYear < 1900) {
			theYear=theYear+1900;
		}
		vm.theYear = theYear;
		//Do we really need this in the console?
		//console.log("footer year: ", vm.theYear);
	}
};

