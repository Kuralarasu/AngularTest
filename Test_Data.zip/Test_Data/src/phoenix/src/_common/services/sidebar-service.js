module.exports = function (app) {
	app.factory('sidebarSvc', SideBarService);

	function SideBarService() {

		var _closeSidebar = function () {
			var ele = document.querySelector('body'),
				_classRemoved = 'aside-mouse-enter';

			if (angular.element(ele).hasClass('aside-mouse-enter')) {
				angular.element(ele).removeClass(_classRemoved);
			}
		};

		var _setSideBarState = function () {
			var ele = document.querySelector('body'),
				_class = 'aside-close aside-animation-end animation-end aside-mouse-enter';
			angular.element(ele).addClass(_class);
		};

		return {
			closeSidebar: _closeSidebar,
			setSideBarState: _setSideBarState
		};
	}


};


