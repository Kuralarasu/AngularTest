/**
 * Created by Ramor11 on 11/12/2015.
 *
 * THIS IS FOR ELECTRON INJECTION WITHIN THE WEBVIEW WEBAPPLICATION
 *
 */
module.exports = function (app) {
	'use strict';


	/**
	 * @ngdoc service
	 * @name phx.common.factory:electron
	 *
	 * @requires $q
	 *
	 * @description
	 * Defines the state of the electron service,If the user is within the browser of the application it will return exist = false;
	 * Once the application is loaded into the electron desktop main process it will inject into the html header the following reference.
	 * This will identify the position state of the application
	 *
	 ```js
	 	document.documentElement.getAttribute('id') !== 'ELECTRON_PARENT_CONTAINER'
	 ```
	 *
	 *
	 * @return {Object|Array} Reference to electron service
	 *
	 *
	 */
	app.factory('electron', ['$q', function ($q) {

			var objElec = new angular.noop, electron = {exist: false};

			var init = function () {
				var defer = $q.defer();

				if (document.documentElement.getAttribute('id') !== 'ELECTRON_PARENT_CONTAINER')return function () {
					var resolve = $q(function (resolve) {
						resolve({});
					});
					return {
						send: function () {
							return resolve;
						}
					}
				}();


				try {
					objElec = new Electron();
					electron.exist = true;

					defer.resolve(true)

				} catch (e) {
					init().then(function () {
						init = null;
					});
				}

				return defer.promise;
			};

		/**
		 * @ngdoc function
		 * @name phx.common.factory:electron#send
		 * @methodOf phx.common.factory:electron
		 *
		 *
		 * @param {string=} eventType, message to send to main process to get response
		 * @param {object=} Obj to send with eventType to main process
		 *
		 * @description
		 * This will send a message based on eventType to main process, if that message type exist with the necessary parameters
		 * it will return a promise with the necessary response.
		 *
		 * @returns {Object|Array|promise} reference to eventType response
		 *
		 *
		 * @example
		 *
		 ```js
		 	electron.send('getVersion').then(function (results) {
				//results messages
			});
		 ```
		 *
		 *
		 */


			electron.send = function (eventType, msg) {
				if (objElec.hasOwnProperty('send')) {
					return objElec.send(eventType, msg);
				} else {
					return $q(function (resolve) {
						resolve({});
					});
				}
			};


			init();
			return angular.extend({}, objElec, electron);

		}]);

}
