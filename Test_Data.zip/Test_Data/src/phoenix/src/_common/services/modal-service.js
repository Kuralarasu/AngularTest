/**
 * @ngdoc service
 * @name common.svcs.modalService
 * @module phxApp
 *
 * @description Provides dialog services using $mdDialog.  These are wrapper methods around $mdDialog for easier use.
 */

/**
 * @ngdoc function
 * @name showAlert
 * @description shows an alert with a specified message.
 * @param {object} dialogOptions - defines the options to use for this alert.
 * @param {string} [dialogOptions.title] - title of alert
 * @param {string} [dialogOptions.textContent] - alert message. Either textContent or htmlContent are required.
 * @param {string} [dialogOptions.htmlContent] - alert message as html Requires ngSanitize to be loaded.  Html not compiles by Angular.  Either textContent or htmlContent are required.
 * @param {string} [dialogOptions.ok] - OK button text. Defaults to "OK".
 * @param {string} [dialogOptions.theme] - theme of alert
 * @param {DOMClickEvent} ]dialogOptions.targetEvent] - click's event object. When passed in, the location will be used as the starting point for the opening animation.
 */

/**
 * @ngdoc function
 * @name showConfirmation
 * @description shows a confirmation dialog with a specified message.
 * @param {object} dialogOptions - defines the options to use for this confirmation.
 * @param {string} [dialogOptions.title] - title of confirmation
 * @param {string} [dialogOptions.textContent] - confirmation message. Either textContent or htmlContent are required.
 * @param {string} [dialogOptions.htmlContent] - confirmation message as html Requires ngSanitize to be loaded.  Html not compiles by Angular.  Either textContent or htmlContent are required.
 * @param {string} [dialogOptions.ok] - OK button text. Defaults to "OK".
 * @param {string} [dialogOptions.ok] - Cancel button text. Defaults to "Cancel".
 * @param {string} [dialogOptions.theme] - theme of confirmation
 * @param {DOMClickEvent} ]dialogOptions.targetEvent] - click's event object. When passed in, the location will be used as the starting point for the opening animation.
 * @returns {promise} Promise returned resolved if user clicks the confirm action on hte dialog.
 */

/**
 * @ngdoc function
 * @name showPrompt
 * @description shows a dialog with a specified message and input box.
 * @param {object} dialogOptions - defines the options to use for this prompt.
 * @param {string} [dialogOptions.title] - title of prompt
 * @param {string} [dialogOptions.textContent] - prompt message. Either textContent or htmlContent are required.
 * @param {string} [dialogOptions.htmlContent] - prompt message as html Requires ngSanitize to be loaded.  Html not compiles by Angular.  Either textContent or htmlContent are required.
 * @param {string} [dialogOptions.placeholder] - Placeholder text for input.
 * @param {string} [dialogOptions.ok] - OK button text. Defaults to "OK".
 * @param {string} [dialogOptions.ok] - Cancel button text. Defaults to "Cancel".
 * @param {string} [dialogOptions.theme] - theme of prompt
 * @param {DOMClickEvent} ]dialogOptions.targetEvent] - click's event object. When passed in, the location will be used as the starting point for the opening animation.
 * @returns {promise} Promise returned resolved if user clicks the prompt action on the dialog with the input value as the first argument.
 */

/**
 * @ngdoc function
 * @name showDialog
 * @description shows a dialog with specified options.  This fuction provides a wrapper around the $mdDialog.show() function
 * @param {object} dialogOptions - defines the options to use for this dialog.
 * @param {string=} dialogOptions.templateUrl - The url of a template that will be used as the content of the dialog.
 * @param {string=} dialogOptions.template - HTML template to show in the dialog. This must be trusted HTML with respect to Angular's $sce service. This template should never be constructed with any kind of user input or user data.
 * @param {boolean=} dialogOptions.autoWrap - Whether or not to automatically wrap the template with a <md-dialog> tag if one is not provided. Defaults to true. Can be disabled if you provide a custom dialog directive.
 * @param {DOMClickEvent=} dialogOptions.targetEvent - A click's event object. When passed in as an option, the location of the click will be used as the starting point for the opening animation of the the dialog.
 * @param {string|Element|object} dialogOptions.openFrom - The query selector, DOM element or the Rect object that is used to determine the bounds (top, left, height, width) from which the Dialog will originate.
 * @param {string|Element|object} dialogOptions.closeTo - The query selector, DOM element or the Rect object that is used to determine the bounds (top, left, height, width) to which the Dialog will target.
 * @param {object=} dialogOptions.scope - the scope to link the template / controller to. If none is specified, it will create a new isolate scope. This scope will be destroyed when the dialog is removed unless preserveScope is set to true.
 * @param {boolean=} dialogOptions.preserveScope - whether to preserve the scope when the element is removed. Default is false
 * @param {boolean=} dialogOptions.disableParentScroll - Whether to disable scrolling while the dialog is open. Default true.
 * @param {boolean=} dialogOptions.hasBackdrop - Whether there should be an opaque backdrop behind the dialog. Default true.
 * @param {boolean=} dialogOptions.clickOutsideToClose - Whether the user can click outside the dialog to close it. Default false.
 * @param {boolean=} dialogOptions.escapeToClose - Whether the user can press escape to close the dialog. Default true.
 * @param {boolean=} dialogOptions.focusOnOpen - An option to override focus behavior on open. Only disable if focusing some other way, as focus management is required for dialogs to be accessible. Defaults to true.
 * @param {function|string=} dialogOptions.controller - The controller to associate with the dialog. The controller will be injected with the local $mdDialog, which passes along a scope for the dialog.
 * @param {object=} dialogOptions.locals - An object containing key/value pairs. The keys will be used as names of values to inject into the controller. For example, locals: {three: 3} would inject three into the controller, with the value 3. If bindToController is true, they will be copied to the controller instead.
 * @param {boolean} dialogOptions.bindToController - bind the locals to the controller, instead of passing them in.
 * @param {object=} dialogOptions.resolve - Similar to locals, except it takes promises as values, and the dialog will not open until all of the promises resolve.
 * @param {string=} dialogOptions.controllerAs - {string=}: An alias to assign the controller to on the scope.
 * @param {element=} dialogOptions.parent - The element to append the dialog to. Defaults to appending to the root element of the application.
 * @param {function=} dialogOptions.onShowing - Callback function used to announce the show() action is starting.
 * @param {function=} dialogOptions.onComplete Callback function used to announce when the show() action is finished.
 * @param {function=} dialogOptions.onRemoving Callback function used to announce the close/hide() action is starting. This allows developers to run custom animations in parallel the close animations.
 * @param {boolean=} dialogOptions.fullscreen An option to apply .md-dialog-fullscreen class on open. * @returns {promise} Promise returned resolved if user clicks the prompt action on the dialog with the input value as the first argument.
 *
 */
var modalService = function ($mdDialog, $q) {

	var _showAlert = function(dialogOptions) {
		if (!dialogOptions) {
			return;
		}

		var deferred = $q.defer();
		var contentProvided = false;
		var dialogPreset = $mdDialog.alert();
		if (dialogOptions.title) {
			dialogPreset.title(dialogOptions.title);
		}
		if (dialogOptions.textContent) {
			dialogPreset.textContent(dialogOptions.textContent);
			contentProvided = true;
		}
		if (dialogOptions.htmlContent) {
			dialogPreset.htmlContent(dialogOptions.htmlContent);
			contentProvided = true;
		}
		if (!contentProvided) {
			deferred.reject("Neither text nor html message provided.");
		}

		dialogPreset.ok(dialogOptions.ok || "OK");

		if (dialogOptions.theme) {
			dialogPreset.theme(dialogOptions.theme);
		}
		if (dialogOptions.targetEvent) {
			dialogPreset.targetEvent(dialogOptions.targetEvent);
		}

		$mdDialog
			.show(dialogPreset)
			.then(function() { deferred.resolve();})
			.catch(function() { deferred.reject(); })
			.finally(function() {
				dialogPreset = undefined;
			});

		return deferred.promise;
	}

	var _showConfirmation = function(dialogOptions) {
		if (!dialogOptions) {
			return;
		}

		console.log("modalService.showConfirmation: ", dialogOptions);
		var deferred = $q.defer();
		var contentProvided = false;
		var dialogPreset = $mdDialog.confirm();
		if (dialogOptions.title) {
			dialogPreset.title(dialogOptions.title);
		}
		if (dialogOptions.textContent) {
			dialogPreset.textContent(dialogOptions.textContent);
			contentProvided = true;
		}
		if (dialogOptions.htmlContent) {
			dialogPreset.htmlContent(dialogOptions.htmlContent);
			contentProvided = true;
		}
		if (!contentProvided) {
			deferred.reject("Neither text nor html message provided.");
		}

		dialogPreset.ok(dialogOptions.ok || "OK");
		dialogPreset.cancel(dialogOptions.cancel || "Cancel");

		if (dialogOptions.theme) {
			dialogPreset.theme(dialogOptions.theme);
		}
		if (dialogOptions.targetEvent) {
			dialogPreset.targetEvent(dialogOptions.targetEvent);
		}

		$mdDialog
			.show(dialogPreset)
			.then(function() { deferred.resolve();})
			.catch(function() { deferred.reject(); })
			.finally(function() {
				dialogPreset = undefined;
			});

		return deferred.promise;
	}

	var _showPrompt = function(dialogOptions) {
		if (!dialogOptions) {
			return;
		}

		var deferred = $q.defer();
		var contentProvided = false;
		var dialogPreset = $mdDialog.prompt();
		if (dialogOptions.title) {
			dialogPreset.title(dialogOptions.title);
		}
		if (dialogOptions.textContent) {
			dialogPreset.textContent(dialogOptions.textContent);
			contentProvided = true;
		}
		if (dialogOptions.htmlContent) {
			dialogPreset.htmlContent(dialogOptions.htmlContent);
			contentProvided = true;
		}
		if (!contentProvided) {
			deferred.reject("Neither text nor html message provided.");
		}

		if (dialogOptions.placeholder) {
			dialogPreset.placeholder(dialogOptions.placeholder);
			contentProvided = true;
		}
		dialogPreset.ok(dialogOptions.ok || "OK");
		dialogPreset.cancel(dialogOptions.cancel || "Cancel");

		if (dialogOptions.theme) {
			dialogPreset.theme(dialogOptions.theme);
		}
		if (dialogOptions.targetEvent) {
			dialogPreset.targetEvent(dialogOptions.targetEvent);
		}

		$mdDialog
			.show(dialogPreset)
			.then(function() { deferred.resolve();})
			.catch(function() { deferred.reject(); })
			.finally(function() {
				dialogPreset = undefined;
			});

		return deferred.promise;
	}

	// TODO: this method remains only to provide backwards compatibility
	var _showModal = function (dialogOptions) {
		return this.showDialog(dialogOptions);
	};

	var _showDialog = function (dialogOptions) {
		console.log("calling show: ", dialogOptions);
		return $mdDialog.show(dialogOptions);

	};

	return {
		showAlert: _showAlert,
		showConfirmation: _showConfirmation,
		showDialog: _showDialog,
		showModal: _showModal,
		showPrompt: _showPrompt
	};
};

modalService.$inject = ['$mdDialog', '$q'];

module.exports = function (app) {
	app.factory('common.svcs.modalService', modalService);

	/**
	 * This is not active since we have not DeCoupled from UIBootstrap, this application
	 * seems to be heavy depended on UIBootstrap
	 */
	//app.run(["$templateCache", function ($templateCache) {
	//
	//	$templateCache.put("template/modal/backdrop.html",
	//		"<div class=\"modal-backdrop fade {{ backdropClass }}\"\n" +
	//		"     ng-class=\"{in: animate}\"\n" +
	//		"     ng-style=\"{'z-index': 1040 + (index && 1 || 0) + index*10}\"\n" +
	//		"></div>\n");
	//
	//	$templateCache.put("template/modal/window.html",
	//		"<div tabindex=\"-1\" role=\"dialog\" class=\"modal fade\" ng-class=\"{in: animate}\" ng-style=\"{'z-index': 1050 + index*10, display: 'block'}\" ng-click=\"close($event)\">\n" +
	//		"    <div class=\"modal-dialog\" ng-class=\"{'modal-sm': size == 'sm', 'modal-lg': size == 'lg'}\"><div class=\"modal-content\" modal-transclude></div></div>\n" +
	//		"</div>");
	//
	//}]);
};

