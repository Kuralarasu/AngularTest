/**
 * Created by ramor11 on 2/17/2016.
 */

module.exports = function (app) {


    "user strict";


    app.factory('helpRouteService', HelpRouteService);

    HelpRouteService.$inject = ['phxCommonUtilities', '$window'];

    function HelpRouteService(utilities, $window) {
        //http://www.javascript-coder.com/window-popup/javascript-window-open.phtml
        var defaults = {
            external: false,
            url: "",
            windowName: "", //A name to be given to the new window. The name can be used to refer this window again.
            windowFeatures: {//A string that determines the various window features to be included in the popup window (like status bar, address bar etc)
                status: false, //The status bar at the bottom of the window.
                toolbar: false, //The standard browser toolbar, with buttons such as Back and Forward.
                location: false,//The Location entry field where you enter the URL.
                menubar: false,//The menu bar of the window
                directories: false,//The standard browser directory buttons, such as What’s New and What’s Cool
                resizable: true,//Allow/Disallow the user to resize the window.
                scrollbars: true,//Enable the scrollbars if the document is bigger than the window
                height: false,//Specifies the height of the window in pixels. (example: height=’350′)
                width: false//Specifies the width of the window in pixels.
            },
            moveTo: "0,0"
        },
            service = {},
            properties = angular.copy(defaults);

        service.init = function (obj) {
            //console.log('RESET HELP ROUTES SERVICE ...');
            properties = angular.copy(defaults);
            this.remove('windowOpener');

            if (!obj) return;

            if (Object.keys(obj).length) Object.keys(obj).forEach(function (key) {
                properties[key] = obj[key];
            });

            return;
        };


		/**
		 * Save a Object data in memory
		 * @param key
		 * @param value
		 * @returns {*|Array}
		 */
        service.set = function (key, value) {
            return value ? properties[key] = value || null : this.remove(key);
        };

		/**
		 * Get Object values based on key, if no key is available then return all
		 * object
		 * @param key
		 * @returns {*}
		 */
        service.get = function (key) {
            return typeof key === 'string' ? (utilities.getObjData(properties, key) || false) : properties;
        };


        function ObjectKeys(obj, cb, _t) {
            Object.keys(obj).forEach(function (k, i) {
                cb.apply(_t || obj, [k, i]);
            });
        }

        service.opener = function () {
            var callback = angular.noop,
                opts = null;

            angular.forEach(arguments, function (r, i) {
                if (!isNaN(i)) {
                    if (typeof r === 'object') {
                        opts = r;
                    } else if (typeof r === 'function') {
                        callback = r;
                    }
                }
            });

            //local variables
            var data = opts ? opts : angular.extend({}, properties),
                windowOpener = this.get('windowOpener'),
                handler = {
                    url: properties.url,
                    windowName: data.windowName,
                    windowFeatures: {}
                },
                wProp = angular.extend({}, data.windowFeatures);

            angular.extend(properties, data);

            if (!windowOpener) {
                ObjectKeys(wProp, function (key) {
                    if (this[key]) {
                        handler.windowFeatures[key] = this[key];
                    }
                });

                if (Object.keys(handler.windowFeatures).length) {
                    var features = [];
                    ObjectKeys(handler.windowFeatures, function (key) {
                        this.push(key + "=" + (handler.windowFeatures[key] ? "1" : "0"));
                    }, features);
                    handler.windowFeatures = features.join(",");
                }
                this.set('windowOpener', angular.extend({}, properties, handler))
            } else {
                $window.open(windowOpener.url, windowOpener.windowName, windowOpener.windowFeatures);
                if (!angular.equals(windowOpener.moveTo, defaults.moveTo)) {
                    var moveTo = windowOpener.moveTo.split(",");
                    $window.moveTo(isNumeric(moveTo[0]), isNumeric(moveTo[1]));
                }
            }

            callback.apply(this, [this.get('windowOpener')]);
        };

		/**
		 * Test the conversion of String to numeric value
		 * @param num
		 * @returns {*}
		 */
        function isNumeric(num) {
            return !isNaN(num) ? Number(num) : num;
        };

		/**
		 * Delete the key params from memory, return boolean if successfull
		 * @param key
		 * @returns {boolean}
		 */
        service.remove = function (key) {
            delete properties[key];
            return properties.hasOwnProperty(key);
        };


        return service;

    }


};
