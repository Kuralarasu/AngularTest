'use strict';

var inject = ['$http', '$q', 'RestUrlService', '$log', 'phxCommonUtilities'];
var StateService = function ($http, $q, restUrlService, $log, utilities) {

	var _armedStates = ['AA','AE','AP'];
	var _armedCities = [
		{city: 'AIR/ARMY POST OFFICE', abbrev: 'APO'},
		{city: 'FLEET POST OFFICE', abbrev: 'FPO'},
		{city: 'DIPLOMATIC POST OFFICE', abbrev: 'DPO'}
	];

	var _validateState = function (city, state) {
		$log.log('state service, _isValidState: ', city, state);

		if (state && _armedStates.some(function(s) {return s === state.toUpperCase();})) {
			console.log('is armed state');
			if (!city || !_armedCities.some(function(c) {return (c.city === city.toUpperCase() || c.abbrev === city.toUpperCase());})) {
				//don't call
				//lcdMessage.error();
				return {status: false, error: 'You cannot use an Armed Forces state unless you specify an Armed Forces city.'};
			}
		}
		return {status: true, error: ''};
	};

	return {
		validateState : _validateState,
		armedStates: _armedStates,
		armedCities: _armedCities
	};
};

StateService.$inject = inject;

module.exports = function (app) {
	app.factory('stateService', StateService);
};
