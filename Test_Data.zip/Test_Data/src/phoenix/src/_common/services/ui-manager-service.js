'use strict';
module.exports = function (app) {
	app.factory('uiManager', uiMananger);
	function uiMananger() {
		var manager = {},
			paginator = {

				getDefaultGridOptions: function () {

					var defaultVals = function () {
						this.pageSizes = [10, 25, 50],
							this.currentPageSize = 100,
							this.totalItems = 0,
							this.currentPage = 1,
							this.maxPageLinks = 4,
							this.onPageNavigation = function () {
								throw 'Implement this function';
							},
							this.onPageSizeChange = function () {
								throw 'Implement this function';
							}
					};

					defaultVals.prototype.setTotalItems = function (newTotalItems) {
						this.totalItems = newTotalItems;
						this.currentPageSize = newTotalItems < this.currentPageSize ? newTotalItems : this.currentPageSize;
					};

					defaultVals.prototype.setCurrentPageSize = function (newPageSize) {
						this.currentPageSize = newPageSize;
					};

					defaultVals.prototype.setCurrentPage = function (pageNo) {
						this.currentPage = pageNo;
					};

					defaultVals.prototype.getPageRowOffset = function () {
						var offset = 0;
						offset = (this.currentPage - 1) * this.currentPageSize + 0;

						return offset;
					};

					return new defaultVals();
				}
			};

		//Expose variables
		manager.paginator = paginator;

		return manager;
	}
};
