SpinnerService.$inject = ['$rootScope', '$compile', '$animate', '$document'];


/**
 * @ngdoc directive
 * @name lcpSpinnerDirective
 * @module phx.common
 *
 * @restrict E
 *
 * @description
 * Replace element <loader> with $templateCache.get('/lcp/loader/lcp-spinner.html')
 *
 */
function SpinnerDirective() {
	return {
		restrict: 'E',
		replace: true,
		templateUrl: '/lcp/loader/lcp-spinner.html'
	};
}



/**
 * @ngdoc service
 * @name phxCommonSpinnerService
 * @module phx.common
 *
 * @kind function
 *
 * @description
 *
 *
 */

function SpinnerService($rootScope, $compile, $animate, $document) {

	var self = this,
		$parent = angular.element($document.find('body')),
		compiled = null;


	// jQuery object of the directive to load the service
	self.loaderContainer = angular.element('<lcp-spinner-directive></lcp-spinner-directive>');

	function _show(opts) {

		// get compiled bound view, by compiling template and binding to rootScope
		compiled = $compile(self.loaderContainer)($rootScope);
		$animate.enter(compiled,$parent);
	}


	function _hide() {
		$animate.leave(compiled);
	}


	return {
		/**
		 * @ngdoc function
		 * @name phxCommonSpinnerService#hide
		 * @module phx.common
		 *
		 * @kind function
		 *
		 *
		 * @description
		 * Runs the leave animation operation and, upon completion, removes the element from the DOM
		 *
		 */
		hide: _hide,
		/**
		 * @ngdoc function
		 * @name phxCommonSpinnerService#show
		 * @module phx.common
		 *
		 *
		 * @kind function
		 *
		 * @param {object} object with parameters
		 *
		 *
		 * @description
		 * Enters the animation and add the element to the DOM
		 *
		 * @example
		 *
		 * ```js
		 * var options = {
             *  includeBar:true,
             *   includeSpinner:false,
             *   parentSelector:'body',
             *   message:""
             * },
		 *
		 * loaderService.start(options);
		 *
		 * ```
		 */
		show: _show
	};


}


module.exports = function (app) {
	app.run([
		'$templateCache',
		function ($templateCache) {
			$templateCache.put('/lcp/loader/lcp-spinner.html', [
					'<div id="spinner">',
					'<div class="spinner-container">',
					'<div class="outer-circle"></div>',
					'<div class="color-circle"></div>',
					'<div class="inner-circle"></div>',
					'</div></div>'
				].join("")
			)
		}
	])
		.directive('lcpSpinnerDirective', SpinnerDirective)
		.factory('phxCommonSpinnerService', SpinnerService);
};
