"use strict";

var MsgHistoryService = function () {

    var _service = {

           _messages: [ 
           // { module:'Customer', page:'Provider entity search', msg:'PHX-300 database error', type:'success', date:new Date('04/04/2015 03:34:00') },
           // { module:'Billing', page:'Eligibility Verification', msg:'PHX-300 database error', type:'success', date:new Date('04/04/2015 06:34:00') }, 
           // { module:'Customer', page:'RulesEditor', msg:'PHX-300 database error', type:'error', date:new Date('04/04/2015 12:34:00') }, 
           // { module:'Billing', page:'Eligibility Verification', msg:'PHX-300 database error', type:'error', date:new Date('04/04/2015 19:34:00') }, 
           // { module:'Billing', page:'Eligibility Verification', msg:'PHX-300 database error', type:'error', date:new Date('04/04/2015 22:34:00') }, 

          ],
           pathsMap: {
                '/phx-rest/eligibility' : ['Billing', 'Eligibility Verification'],
                '/phx-rest/eligibility?fullResponseOnError=true' : ['Billing', 'Eligibility Verification'],
                '/phx-rest/patient/update': ['Billing', 'Create Patient'],
                '/phx-rest/address/validate' : ['Billing', 'Address Validation'],
                '/phx-rest/phone/standardize' : ['Billing', 'Address Validation'],
                '/phx-rest/diagnosis/validate' : ['Billing', 'Diagnosis Validation'],
                '/phx-rest/testlevelcoverage/save': ['Billing', 'Create Payer Policy']
           },

           getMessagesHistory: function(){
                return this._messages;
           },

           logMessage: function(_module, _page, _message, _type){
                this._messages.push( {module: _module, page:_page, msg:_message, type: _type, date: new Date()} );
           },

           //This is called from auth interspector for general system error. 
           //so this method will find module and page names has to be found by the headers
           logByHeader: function(msg, headerObj){
                var msgObj = { };
                msgObj.date = new Date();
                msgObj.module = '';
                msgObj.page = '';

                if( headerObj.config ){
                   var getModulePage = this.pathsMap[ headerObj.config.url ];
                   if( getModulePage ){
                       msgObj.module = getModulePage[0];
                       msgObj.page = getModulePage[1];
                   }else{
                      //lets handle for customer
                      if( headerObj.config.url.indexOf('customer') != -1 ){
                            msgObj.module = 'Customer';
                            msgObj.page = 'Provider Entity';
                      } 

                   }                   
                }

                this.logMessage( msgObj.module, msgObj.page, msg, 'error');
        
           }

    };

    return _service;
};

module.exports = function(app) {
    app.factory('MsgHistoryService', MsgHistoryService);
};
