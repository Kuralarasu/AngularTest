/**
 * Created by ramor11 on 8/8/2016.
 */

module.exports = function (app) {

	"use strict";

	/**
	 * @ngdoc overview
	 * @name phxCommon.Loki
	 *
	 * @description
	 * <https://rawgit.com/techfort/LokiJS/master/jsdoc/index.html>
	 */

	app.run(['Storage', function (loki) {
		loki.setKey()
	}]).service('Storage', ['$q', 'electron', StorageService]);

	function StorageService($q, electron) {

		var _this = this,
			_defaultCollection = 'settings',
			_defaults = {
				options: {
					env: electron.exist ? 'NODEJS' : 'BROWSER'
				},
				KeyStorage: 'app.db'
			},
			service = {
				getCollection: function (name) {
					return name ? _this.db.getCollection(name) || function () {
						var collection = _this.db.addCollection(name, _this.options);
						_this.db.saveDatabase();
						return collection;
					}() : _this.collection;
				},
				saveDatabase: function () {
					return service.db.saveDatabase();
				},
				setKey: function (key, options) {
					Object.assign(_defaults, {
						KeyStorage: key || _defaults.KeyStorage,
						options: options || _defaults.options
					});
					ngOnInit.apply(service, []);
					delete service.setKey;
				}
			};


		var ngOnInit = function () {
			var _this = this;
			return $q(function (resolve, reject) {
				_this.db = function (e) {
					var loki = !e.exist ? function () {
						return require('lokijs/src/lokijs.js');

					}() : e.require('lokijs');

					return new loki(e.exist ? e.path.resolve(e.__dirname, '..', _defaults.KeyStorage) : _defaults.KeyStorage, _defaults.options);
				}(electron);

				reload.apply(_this, []).then(function () {
					_this.collection = _this.db.getCollection(_defaultCollection);
					if (!_this.collection)addCollection.apply(_this, []);
					resolve(_this);
				}).catch(function (e) {
					// create collection
					_this.db.addCollection(_defaultCollection);
					// save and create file
					_this.db.saveDatabase();

					resolve(_this);
				});

				function addCollection() {
					// create collection
					this.db.addCollection(_defaultCollection);
					// save and create file
					this.db.saveDatabase();
					this.collection = this.db.getCollection(_defaultCollection);
					this.loaded = true;
				}

			});

			function reload() {
				var _this = this;
				return $q(function (resolve, reject) {
					_this.loaded = false;
					_this.db.loadDatabase({}, function (e) {
						if (e) {
							reject(e);
						} else {
							_this.loaded = true;
							resolve(_this);
						}
					}.bind(_this));

				});
			};
		};

		return service;
	}

};
