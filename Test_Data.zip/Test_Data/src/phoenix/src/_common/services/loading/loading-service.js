module.exports = function (app) {

	"use strict";

	/**
	 * @ngdoc overview
	 * @name phxCommon.Loader
	 *
	 * @description
	 * Complete customizable loading bar, which uses $templateCache to load onto the DOM when called
	 * upon service
	 *
	 */

	app.run(['$templateCache', function ($templateCache) {
		$templateCache.put('/phxCommon/loading-bar.html', [
			'<div class="loader-block"><div class="loading-backdrop" data-ng-show="loader.backdrop"></div>' +
			'<div class="loader-message"><span data-ng-bind-html="loader.message"></span></div></div>'
		].join(""))
	}]).directive('lcpLoadingDirective',
		/**
		 * @ngdoc directive
		 * @name loader.directive.directive:loader
		 * @restrict E
		 *
		 * @description
		 * Replace element <loader> with $templateCache.get('/loader/loader.html')
		 *
		 */
		function () {
			return {
				restrict: 'E',
				replace: true,
				templateUrl: '/loader/loader.html'
			};
		})
		.service('phxCommonLoaderService', LoadingService);


	LoadingService.$inject = ['$document', '$timeout', '$rootScope', '$parse']


	/**
	 * @ngdoc service
	 * @name reyramos.loader.loaderService
	 *
	 * @description
	 * This service handles adding and removing the actual element in the DOM.
	 * Generally, best practices for DOM manipulation is to take place in a
	 * directive, but because the element itself is injected in the DOM only upon
	 * requests, and it's likely needed on every view, the best option is to
	 * use a service, that inject a directive.
	 *
	 */
	function LoadingService($document, $timeout, $rootScope, $parse) {


		var options = {
				// target:'JQuery'
				loadingBar: '<div id="loading-bar"><div class="bar"></div></div>',
				backdrop: true
			},
			$loaderContainer = angular.element('<loader></loader>'),
			loadingBar = angular.element(options.loadingBar),
			bar = loadingBar.find('div').eq(0),
			incTimeout,
			completeTimeout,
			setCompleteTimeout,
			started = false,
			status = 0,
			startCount = 0,
			hideCount = 0;

		/**
		 * Inserts the loading bar element into the dom, and sets it to 2%
		 */
		function _start(obj) {

			//keep the count of the start trigger
			startCount++;

			var opts = angular.copy(options);
			opts = angular.extend(opts, obj || {});

			$timeout.cancel(completeTimeout);
			$timeout.cancel(setCompleteTimeout);

			var $parent = opts.target || angular.element($document.find('body'));


			// do not continually broadcast the started event:
			if (started) return;

			$rootScope.$broadcast('loaderService:started');

			$parent.append($loaderContainer);

			started = true;

			$parent.append(loadingBar)


			_set(0.02);

		}

		/**
		 * Set the loading bar's width to a certain percent.
		 *
		 * @param n any value between 0 and 1
		 */
		function _set(n) {
			if (!started) {
				return;
			}
			var pct = (n * 100) + '%';
			bar.css('width', pct);
			status = n;
			// increment loadingbar to give the illusion that there is always
			// progress but make sure to cancel the previous timeouts so we don't
			// have multiple incs running at the same time.
			$timeout.cancel(incTimeout);
			incTimeout = $timeout(function () {
				_inc();
			}, 250);

		}

		/**
		 * Increments the loading bar by a random amount
		 * but slows down as it progresses
		 */
		function _inc() {
			if (_status() >= 1) {
				return;
			}
			var rnd = 0,
				stat = status;

			if (stat >= 0 && stat < 0.25) {
				// Start out between 3 - 6% increments
				rnd = (Math.random() * (5 - 3 + 1) + 3) / 100;
			} else if (stat >= 0.25 && stat < 0.65) {
				// increment between 0 - 3%
				rnd = (Math.random() * 3) / 100;
			} else if (stat >= 0.65 && stat < 0.9) {
				// increment between 0 - 2%
				rnd = (Math.random() * 2) / 100;
			} else if (stat >= 0.9 && stat < 0.99) {
				// finally, increment it .5 %
				rnd = 0.005;
			} else {
				// after 99%, don't increment:
				rnd = 0;
			}

			var pct = Number.parseFloat(stat) + Number.parseFloat(rnd);
			_set(pct);
		}

		function _status() {
			return status;
		}


		//if the number of starts === the number of hide request then it is time to hide the bar
		function _hide() {
			hideCount++;

			if (!started && startCount !== hideCount)return;

			$parse('loader').assign($rootScope, {});

			$rootScope.$broadcast('loaderService:hide');

			return status < 1 ? function () {
				_set(1);
				complete();
			}() : complete();
		}


		function complete() {
			started = false;
			status = 0;

			if (!$loaderContainer)return;
			completeTimeout = $timeout(function () {
				loadingBar.addClass('loader-end');

				completeTimeout = $timeout(function () {
					$loaderContainer.remove();
					loadingBar.removeClass('loader-end').remove();
				}, 100)

			}, 900);


		}

		return {
			/**
			 * @ngdoc function
			 * @name loader.loaderService#hide
			 * @methodOf reyramos.loader.loaderService
			 * @kind function
			 *
			 *
			 * @description
			 * Runs the leave animation operation and, upon completion, removes the element from the DOM
			 *
			 */
			hide: _hide,
			/**
			 * @ngdoc function
			 * @name loader.loaderService#start
			 * @methodOf reyramos.loader.loaderService
			 * @kind function
			 *
			 * @param {object} object with parameters
			 *
			 *
			 * @description
			 * Enters the animation and add the element to the DOM
			 *
			 * @example
			 *
			 * ```js
			 * var options = {
             *   parentSelector:'body',
             *   message:""
             * },
			 *
			 * loaderService.start(options);
			 *
			 * ```
			 */
			start: _start
		};

	}

};
