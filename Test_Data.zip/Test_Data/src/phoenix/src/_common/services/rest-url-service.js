module.exports = function (app) {

	"use strict";

	app.factory('RestUrlService', RestUrlService);


	function RestUrlService() {

		var urlPrefix = '/phx-rest',
			isObject = angular.isObject,
			URLS = {
				//@formatter:off
				//Authentication/Authorization Start
				AUTHC_URL: '/user/profile', //'/ping',
				AUTHZ_URL: '/authz/ui/eval',

				//USER Start
				USER_PROFILE: '/user/profile',
				USER_ROLE_SAVE: '/user',
				USER_ROLE_SEARCH: '/user/search',
				USER_ROLE_ROLES: '/user/roles'
			},
			nonRestURLs = {
				//Non RESTful URLs (external system, ex: Siteminder)
				AUTHC_SIGNOUT_URL: '/siteminderagent/forms/logoutpx.fcc'
			},
			service = {
				define: function (URLS, CB) {
					Object.keys(URLS).forEach(function (key) {
						service[key] = angular.isFunction(CB) ? CB(key, URLS[key]) : urlPrefix + URLS[key];
					});
					Object.keys(nonRestURLs).forEach(function (key) {
						service[key] = angular.isFunction(CB) ? CB(key, URLS[key]) : nonRestURLs[key];
					});
				},
				getUrl: function (urlTmplt) {
					var returnVal = '';
					//urlTmplt = URLS[urlKey];
					var argObj = arguments[1];

					if (isObject(argObj)) {
						var keys = Object.keys(argObj);
						keys.forEach(function (origKey) {
							//Remove spl chars to avoid injection attack!!!
							var clnKey = origKey.replace(/\W/g, '');

							var rgx = new RegExp(':' + clnKey, 'ig');
							urlTmplt = urlTmplt.replace(rgx, argObj[origKey]);
						});

						returnVal = urlTmplt;
					} else {
						var valArray = [], _args = arguments;
						Object.keys(_args).forEach(function (argKey) {
							valArray.push(_args[argKey])
						});

						//remove urlTmplt from value array
						valArray.splice(0, 1);

						if (valArray.length == 1) {
							//replace all the keys with one value
							urlTmplt = urlTmplt.replace(/:\w+/g, valArray[0]);
						} else {
							valArray.forEach(function (val) {
								urlTmplt = urlTmplt.replace(/(:\w+)/, val);
							});
						}

						returnVal = urlTmplt;

					}

					return returnVal;
				}
			};

		//initialize the URLS
		service.define(URLS);

		return service;
	};

};
