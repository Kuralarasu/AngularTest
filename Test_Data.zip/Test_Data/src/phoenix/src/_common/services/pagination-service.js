var pagination = ['$rootScope', function($rootScope) {

	
	
	 return paginator;
}];


module.exports = function(app) {
	app.factory('paginationService', pagination);
}