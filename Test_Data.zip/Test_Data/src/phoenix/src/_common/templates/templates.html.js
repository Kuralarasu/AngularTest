/**
 * Created by ramor11 on 4/20/2016.
 */
module.exports = function (app) {


	app.run(["$templateCache", function ($templateCache) {
		$templateCache.put('/phx/sidebar.tpl.html', require('html!./sidebar.html'));
		$templateCache.put('/phx/actions.tpl.html', require('html!./actions.html'));
		$templateCache.put('/phx/sidebar.actions.tpl.html', require('html!./sidebar-actions.html'));
		$templateCache.put('/phx/application.branding.tpl.html', require('html!./applicationBranding.default.html'));
		$templateCache.put('/phx/default.modal.tpl.html', require('html!./default-modal.html'));
		$templateCache.put('/phx/email.dialog.tpl.html', require('html!./email-dialog.html'));
	}]);

};
