/**
 * Created by ramor11 on 10/5/2016.
 */


require('./lcp-scrollbar.less');
require('./jquery.scrollbar');


var module = require('./lcpScrollbar');
module.exports = module;
