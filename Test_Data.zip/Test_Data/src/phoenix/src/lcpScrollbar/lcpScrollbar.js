/**
 * Created by ramor11 on 12/16/2015.
 */

/**
 * TODO:// COMBINE BOTH DIRECTIVE INTO ONE
 */
(function (angular) {
	'use strict';

	angular.module('lcp.scrollbar.directive', []).run(["$templateCache", function ($templateCache) {
			$templateCache.put('lcp.scrollbar.template.tpl.html',
				['<scrollbar-table-head>',
					'<div style="overflow: hidden;width: 100%;"  ng-transclude="shead"></div>',
					'</scrollbar-table-head>',
					'<div class="lcp-scrollbar scrollbar-external_wrapper">',
					'<div class="scrollbar-external" scrollbar-table-body ng-transclude="sbody"></div>',
					'<div class="external-scroll-x-position">',
					'<div class="external-scroll_x">',
					'<div class="scroll-element_outer">',
					'<div class="scroll-element_size"></div>',
					'<div class="scroll-element_track"></div>',
					'<div class="scroll-bar"></div>',
					'</div>',
					'</div>',
					'</div>',
					'<div class="external-scroll_y">',
					'<div class="scroll-element_outer">',
					'<div class="scroll-element_size"></div>',
					'<div class="scroll-element_track"></div>',
					'<div class="scroll-bar"></div>',
					'</div>',
					'</div>',
					'</div>'].join(" "))
		}])
		.service('lcpScrollbarService', [function () {
			return {
				/**
				 * @ngdoc function
				 * @name lcpScrollbarService.setFocusColumn
				 * @methodOf lcpScrollbarService
				 * @kind function
				 *
				 * @param {object} obj to add magnify class
				 * @param {function} callback, optional
				 *
				 *
				 * @description
				 * Set the focus header
				 *
				 */
				setFocusColumn: function (obj, callback) {
					obj.magnify = !obj.magnify;
					if (angular.isFunction(callback))
						callback(obj)
				},
				/**
				 * @ngdoc function
				 * @name lcpScrollbarService.setSelectRow
				 * @methodOf lcpScrollbarService
				 * @kind function
				 *
				 * @param {array} rows,  array object
				 * @param {integer} $index, of row clicked, return from ngRepeat $index
				 * @param {function} callback, optional
				 *
				 *
				 * @description
				 * Set the focus header
				 *
				 */
				setSelectRow: function (rows, $index, callback) {
					var object = null;
					//loop through row
					angular.forEach(rows, function (obj, idx) {
						var bool = angular.equals(idx, $index) ? null : false;
						//return a referent of the object selected
						if (bool === null)object = obj;
						//loop through the columns of the row
						angular.forEach(obj, function (o) {
							if (typeof o === 'object')
								o.selected = typeof bool === 'boolean' ? bool : !o.selected;
						});
					});

					if (angular.isFunction(callback))callback(object, $index)

				}

			}


		}])

		/**
		 * @ngdoc controller
		 * @name lcp.scrollbar.directive.lcpScrollbarController
		 *
		 *
		 *
		 * @description
		 * This is a helper controller to set the focused column
		 *
		 * @return {object}
		 *
		 */

		.controller('lcpScrollbarController', ['lcpScrollbarService', function (lcpScroll) {


			/**
			 * @ngdoc function
			 * @name lcpScrollbarController.setFocusColumn
			 * @methodOf lcpScrollbarController
			 * @kind function
			 *
			 * @param {object} obj to add magnify class
			 * @param {function} callback, optional
			 *
			 *
			 * @description
			 * Set the focus header
			 *
			 */
			this.setFocusColumn = lcpScroll.setFocusColumn;


			/**
			 * @ngdoc function
			 * @name lcpScrollbarController.setSelectRow
			 * @methodOf lcpScrollbarController
			 * @kind function
			 *
			 * @param {array} rows,  array object
			 * @param {integer} $index, of row clicked, return from ngRepeat $index
			 * @param {function} callback, optional
			 *
			 *
			 * @description
			 * Set the focus header
			 *
			 */
			this.setSelectRow = lcpScroll.setSelectRow;


		}])
		/**
		 * @ngdoc directive
		 * @name lcp.scrollbar.directive.lcpScrollbar
		 *
		 *
		 * @requires $templateCache
		 *
		 * @description
		 *
		 * Component directive for creating table with fix header and custom scrollbar theme
		 *
		 * @scope
		 *   opts: '=?options' //WIP
		 *
		 * @example:
		 *
		 *
		 * ```html
		 *    <lcp-scrollbar>
		 *        <scroll-head class="analytics-table-head">
		 *            //WRITE YOUR HEADER TABLE CONTENT
		 *        </scroll-head>
		 *        <scroll-body class="analytics-table-body">
		 *            //WRITE YOUR BODY TABLE CONTENT
		 *        </scroll-body>
		 *  </lcp-scrollbar>
		 * ```
		 *
		 *
		 */
		.directive('lcpScrollbar', lcpScrollbar);


	function lcpScrollbar() {

		var directive = {
			restrict: 'E',
			transclude: {
				'shead': '?scrollHead',
				'sbody': '?scrollBody'
			},
			scope: {
				opts: '=?options'
			},
			controller: 'lcpScrollbarController',
			controllerAs: 'ctrl',
			bindToController: true,
			templateUrl: 'lcp.scrollbar.template.tpl.html',
			link: {
				pre: function (scope, ele) {
					ele.addClass('lcp-scrollbar');
				},
				post: function (scope, ele, attr, ctrl, trans) {
					/*
					 trans(function (transEl) {
					 angular.forEach(['shead', 'sbody'], function (key) {
					 var ta = ele[0].querySelector('[ng-transclude="' + key + '"]');
					 if (!ta.hasChildNodes())ta.style.display = "none";
					 });
					 });
					 */


					scrollElements.apply(ele[0], [function (y, x) {
						var head = ele[0].querySelector('scrollbar-table-head > div');
						if (head)head.scrollLeft = x.scroll;
						if (ctrl.opts && angular.isFunction(ctrl.opts.onScroll)) {
							ctrl.opts.onScroll.apply(ele, [y, x])
						}
					}, function (element) {
						var eleClassList = element[0].className.replace(/scroll-scroll/g, '').replace(/scroll-content/g, '');
						ele.addClass(eleClassList);

						if (ctrl.opts && angular.isFunction(ctrl.opts.onUpdate))
							ctrl.opts.onUpdate.apply(ele, [element])
					}])
				}
			}
		};

		return directive;

	}


	function scrollElements(onScroll, onUpdate) {
		$(this.querySelector('[scrollbar-table-body]')).scrollbar({
			"scrollx": $(this.querySelector('.external-scroll_x')),
			"scrolly": $(this.querySelector('.external-scroll_y')),
			"onScroll": onScroll,
			"onUpdate": onUpdate
		});
	}


})(window.angular);
