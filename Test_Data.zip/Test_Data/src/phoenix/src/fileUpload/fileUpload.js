angular.module('phxuilib.fileUpload', [])
    .constant('uploadConfig', {})
    .controller('FileUploadController', function() {

    })
    .directive('fileUpload', fileUpload);

/**
 * @name fileUpload
 * @desc <file-upload> Directive
 * @usage <file-upload upload-service="UploadService">
 */
function fileUpload() {
    /**
     * @name fileUploadCtrl
     * @desc File Upload Controller
     * @type {Function}
     */
    function fileUploadCtrl($scope, $element, $attrs, $injector) {
        // exports
        this.files = files;
        this.uploadFiles = uploadFiles;

        var files = [];
        var uploadService = $injector.get($attrs.uploadService);

        function uploadFiles() {
            //hand files to service
            uploadService
                .uploadFiles(files)
                .then(function(response) {
                    //success, we can render some feedback for teh user in hte view, perhaps a list of files uploaded.

                }, function(reason) {
                    //error, we need to provide the user some meaningful feedback.
                });
        }
    }

    /**
     * @name link
     * @desc File Upload Link
     * @type {Function}
     */
    function link($scope, $element, $attrs, $ctrl) {
        var drop = $element.find('.drop-zone')[0];
        drop.addEventListener('dragenter', function(e) {
            //do dragenter stuff
        }, false);
        drop.addEventListener('dragleave', function(e) {
            //do dragleave stuff
        }, false);
        drop.addEventListener('dragover', function(e) {
            //do dragover stuff
        }, false);
        drop.addEventListener('drop', onDrop, false);

        function onDrop(e) {
            //do drop stuff here
            if (e.dataTransfer && e.dataTransfer.files) {
                $ctrl.uploadFiles(e.dataTransfer.files);

                $scope.apply();
            }
        }
    }

    return {
        restrict: 'E',
        scope: {},
        template: [
            '<div>',
            '<inpout type="file" ng-model="vm.files">',
            '<button type="button" ng-change="vm.uploadFiles(vm.files);">',
            '<div class="drop-zone">Drop your files here!</div>',
            '</div>'
        ].join(''),
        controllerAs: 'vm',
        controller: fileUploadCtrl,
        link: link
    };
}
