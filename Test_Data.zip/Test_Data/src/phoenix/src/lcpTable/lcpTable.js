/**
 * Created by ramor11 on 10/28/2015.
 * Depended
 * <http://gromo.github.io/jquery.scrollbar/>
 */


(function (angular) {
	'use strict';


	angular.module('phxuilib.lcpTable', ['phxuilib/components/lcpTable/lcp.table.template.tpl.html'])
		.directive('lcpTable', LcpTable)
		.directive('thead', tHead)

	LcpTable.$inject = ['$timeout'];
	tHead.$inject = ['$timeout'];
	function toPix(v) {
		return v.toFixed(3) + 'px';
	}

	/**
	 * Use vanilla JS to append class element, from original element
	 * @param ele
	 * @param list
	 * @returns {string}
	 */
	function appendClass(ele, list) {
		var cl = ele[0] || ele,
			cN = cl.getAttribute('classNames') || function () {
					cl.setAttribute('classNames', cl.className)
					return cl.className;
				}(),
			ca = cN.split(" "), la = list.split(" "), a = ca.concat(la);

		return cl.className = (a.filter(function (x, i) {
			return a.indexOf(x) === i
		})).join(" ");
	}


	function upTo(el, tagName) {
		tagName = tagName.toLowerCase();
		while (el && el.parentNode) {
			el = el.parentNode;
			if (el.tagName && el.tagName.toLowerCase().indexOf(tagName) > -1) {
				return el;
			}
		}
		return null;
	}

	function tHead($timeout) {

		var directive = {
			restrict: 'E',
			transclude: 'element',
			link: function (scope, ele, attr, ctrl, transclude) {
				var parent = ele[0].parentNode,
					tagName = upTo(ele[0], 'lcp-table');

				transclude(function (transEl) {

					if (tagName) {
						var table = tagName.querySelector('[lcp-table-head]');
						table.appendChild(transEl[0]);
					} else {
						parent.insertBefore(transEl[0], parent.firstChild);
					}
				})

				transclude(function (transEl) {
					if (tagName) {
						var body = tagName.querySelector('[lcp-table-body] table');
						transEl[0].style.display = 'none';
						$timeout(function () {
							body.insertBefore(transEl[0], body.querySelector('tbody'));
						}, 0, false)
					}
				})
			}
		};

		return directive;

	}

	function LcpTable($timeout) {

		var directive = {
			restrict: 'E',
			transclude: true,
			scope: {
				actions: '=',
				data: '='
			},
			controller: [function () {
				var self = this;
				self.close = function (event) {
					upTo(event.target, 'ul').parentNode.querySelector('a').click();
					return true;
				}
			}],
			controllerAs: 'ctrl',
			bindToController: true,
			templateUrl: 'phxuilib/components/lcpTable/lcp.table.template.tpl.html',
			link: {
				pre: function (scope, ele) {
					ele.addClass('lcp-table');
				},
				post: function (scope, ele, attr, ctrl) {

					var scrollExternal = ele[0].querySelector('[lcp-table-body]'),
						scrollX = ele[0].querySelector('.external-scroll_x'),
						scrollY = ele[0].querySelector('.external-scroll_y');

					/**
					 * Build the scroll from library
					 */
					$(scrollExternal).scrollbar({
						"scrollx": $(scrollX),
						"scrolly": $(scrollY),
						"onScroll": function (y, x) {
							ele[0].querySelector('.lcp-table-head .scroll-y-position').scrollLeft = x.scroll;

							if (ctrl.data && ctrl.data.hasOwnProperty('onScroll'))
								ctrl.data.onScroll(y, x)

						},
						"onUpdate": function (element) {
							$timeout(function () {
								var eleClassList = element[0].className.replace(/scroll-scroll/g, '').replace(/scroll-content/g, '');
								appendClass(ele, eleClassList);
							}, 0, false)

							if (ctrl.data && ctrl.data.hasOwnProperty('onUpdate'))
								ctrl.data.onUpdate(element)

						}
					});
				}
			}
		};

		return directive;

	}

})(window.angular);
