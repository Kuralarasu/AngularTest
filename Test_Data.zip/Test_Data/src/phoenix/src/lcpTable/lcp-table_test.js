'use strict';

describe('Directive: lcpTable ', function() {
    beforeEach(module('phxuilib'));

    var tableOptions = [
        {
            name: 'Actions',
            disable: true,
            onClick: function(event) {
            },
            class: 'PrimaryAction',
            actions: [
                {
                    name: 'Actions1',
                    disable: false,
                        //onClick: function (event) {},
                        //class: 'action-one-class'
                },
                {
                    name: 'Actions2',
                    disable: true,
                        //onClick: function (event) {},
                        //class: 'action-one-class'
                }
            ]
        }
        ],
        element, scope, trigger;


    beforeEach(inject(function($rootScope, $compile, $injector) {
        scope = $rootScope.$new();

        element = angular.element([
            '<lcp-table actions="tableOptions">' +
            '    <table>' +
            '    <thead> ' +
            '        <tr>' +
            '        <td style="width: 25%;text-align: left"> thead1 </td>' +
            '        <td style="width: 25%;text-align: left"> thead2 </td>' +
            '        <td style="width: 25%;text-align: left"> thead3 </td>' +
            '        <td style="width: 25%;text-align: left"> thead4 </td>' +
            '        </tr>' +
            '    </thead> ' +
            '    <tbody ng-repeat="row in tableRow"> ' +
            '        <tr>' +
            '        <td style="width: 25%;text-align: left">row1</td>' +
            '        <td style="width: 25%;text-align: left">row2</td>' +
            '        <td style="width: 25%;text-align: left">row3</td>' +
            '        <td style="width: 25%;text-align: left">row4</td>' +
            '        </tr>' +
            '    </tbody>' +
            '    </table>' +
            '</lcp-table>'
        ].join(' '));


        scope.tableOptions = tableOptions;
        scope.tableRow = [];
        for (var i = 0; i < 10; i++) {
            scope.tableRow.push({index: i});
        }

        $compile(element)(scope);


        scope.$digest();
    }));


    /******
     * Make sure some of the basic design still exist
     */
    //TODO: this test was marked out due to failing.  Need to determine cause
    xit('should have 2 tables', function() {
        var table = element[0].querySelectorAll('table');
        expect(table.length).toBe(2);
    });

    it('should have 10 tbody', function() {
        var tbody = element.find('tbody');
        expect(tbody.length).toBe(10);
    });



    describe('The rows Changes', function() {
        beforeEach(function() {
            scope.tableRow.push({index: 'another'});
            scope.$digest();
        });

        it('should have 11 tbody', function() {
            var tbody = element.find('tbody');
            expect(tbody.length).toBe(11);
        });
    });

});
