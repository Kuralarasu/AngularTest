var filter = function() {

	var formatter = function (value, mask) {
		var value = value.toString().trim().replace(/^\+/, '');
		if (value.match(/[^0-9]/)) {
			return value;
		}

		var first, last;

		switch (value.length) {
			case 1:
				first  = !mask? value.slice(0, 1) : '*';
				break;
			case 2:
				first = !mask? value.slice(0, 2) : '**';
				break;
			case 3:
				first = !mask? value.slice(0, 3) : '***';
				break;
			case 4:
				first = !mask? value.slice(0, 4) : '***-**-' + value.slice(0, 4);
				break;
			case 5:
				first = !mask? value.slice(0, 3) : '***';
				last = !mask? value.slice(3) : '**';
				break;
			case 6:
			case 7:
			case 8:
			case 9:
				first = !mask? value.slice(0, 3) : '***';
				last = !mask? value.slice(3) : '**' + value.slice(5);
				break;
		}

		if (last && last.length == 1) {
			return first + last;
		}

		if (last) {
			if (last.length > 2) {
				last = last.slice(0, 2) + '-' + last.slice(2, 6);
			} else {
				last = last;
			}

			return (first + "-" + last).trim();
		} else {
			return first;
		}
	};

	return function(input, mask) {
		if(!input) return;
		var ssn9digits = input;

		if(typeof input === 'object') {
			if (input) {
				ssn9digits = (input.areaCode ||'') + '-' + (input.prefix || '') + '-'+ (input.lineNumber || '');
			}

			ssn9digits = ssn9digits === '--' ? '' : ssn9digits;
		}

		return formatter(ssn9digits, mask);
	}

};

//module.exports = function(app) {
//	app.filter('ssn', filter);
//}
(function (angular) {
	'use strict';

	angular.module('lcp.ssn.formatter').filter('ssn', filter);
})(window.angular);
