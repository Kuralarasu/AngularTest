(function (angular) {
	'use strict';

	angular.module('lcp.ssn.directive', []).directive('lcpSsnInput', lcpSsnInput);

	lcpSsnInput.$inject = ['$compile'];

	function lcpSsnInput($compile) {
		var directive = {};
			directive.restrict = 'E';
			directive.replace = true;
			directive.template = function ($elem, $attrs) {
				var beforeHtml = ['<md-input-container class="md-block">',
						'<label>'+$attrs['label']+'</label> ',
						'<input class="phxtxt-input"',
					    'ng-class="{\'phxtxt-input--notempty\':value || ctrl.focused === true}"',
					    'ng-focus="ctrl.focused = true" ng-blur="ctrl.focused = false"'].join(''),

					afterHtml = ['> </md-input-container>'].join('');

				//iterate over all the attrs and add to <input> tag
				var keys = Object.keys($attrs.$attr);
				angular.forEach(keys, function (key) {
					var _name = $attrs.$attr[key] || key,
						val = $attrs[key] || true;

					beforeHtml += _name + '="' + val +'"';
				});
				return beforeHtml + afterHtml;
			}
			return directive;
		}
	})(window.angular);

(function (angular) {
	'use strict';

	angular.module('lcp.ssn.formatter', []).directive('lcpSsnFormatter', lcpSsnFormatter);

	lcpSsnFormatter.$inject = ['$filter', '$browser', '$compile', 'phxCommonMessenger'];

	function lcpSsnFormatter($filter, $browser, $compile, lcdMessage) {
		return {
			require: 'ngModel',
			link: function($scope, $element, $attr, ngModelCtrl) {
				//for some reason directive is called for .lcpInputTxtGrp tag
				if($element.prop('tagName') !== 'INPUT') return;

				var listener = function() {
					var value = $element.val().replace(/[^0-9]/g, '');
					$element.attr('isempty', (!value) + '');
					if(!value && value !== '') return; //non-number return
					$element.val($filter('ssn')(value, false));
					$element.data('raw', value);
				};

				//format text going to user (model to view)
				ngModelCtrl.$formatters.push(function (value) {
					$element.data('raw', value);
					return $filter('ssn')(value, true);
				});

				// This runs when we update the text field
				ngModelCtrl.$parsers.push(function(viewValue) {

					var ssn9digits = viewValue.replace(/[^0-9]/g, '').slice(0, 9);

					if(!ssn9digits) {
						return '';
					}

					if(ssn9digits.length < 4 || (ssn9digits.length > 4 && ssn9digits.length < 9 ) || ssn9digits.length > 9) {
						return '';
					}

					var areaNumber = ssn9digits.substring(0, 3),
						groupNumber = ssn9digits.substring(3, 5),
						serialNumber = ssn9digits.substring(5, ssn9digits.length);

					return areaNumber + groupNumber + serialNumber;
				});
				// This runs when the model gets updated on the scope directly and keeps our view in sync
				ngModelCtrl.$render = function() {
					$element.val($filter('ssn')(ngModelCtrl.$viewValue, false));
					$element.attr('isempty', (!ngModelCtrl.$viewValue) + '');
					$element.data('raw', ngModelCtrl.$viewValue);
				};
				var blurListener = function() {
					var rawValue = $element.val();
					var value = rawValue.replace(/[^0-9]/g, '');
					$element.removeClass('ng-not-empty');

					$element.attr('isempty', (!value) + '');
					if(!value) return; //non-number return

					var copyofstring = value;
					$element.val($filter('ssn')(value, true));
					$element.data('raw', value);

					if ((copyofstring.length != 4 && copyofstring.length != 9))
					{
						lcdMessage.growl({class: 'error', message: 'SSN must be 4 or 9 digits.'});
					}
				};
				$element.bind('change', listener);
				$element.bind('blur', blurListener);
				$element.bind('focus', function(event) {
					$element.addClass('ng-not-empty');
					$element.val($filter('ssn')($element.data('raw'), false));
				});
				$element.bind('keydown', function(event) {
					console.log('event is: ', event);
					var key = event.keyCode;

					// If the keys include the CTRL, SHIFT, ALT, or META keys, or the arrow keys, do nothing.
					// This lets us support copy and paste too
					if (key == 91 || (15 < key && key < 19) || (37 <= key && key <= 40)) {
						return;
					}

					// Process differently for 'TAB' key
					if (key == 9) {
						return;
					}

					$browser.defer(listener); // Have to do this or changes don't get picked up properly
				});
				$element.bind('keyup', function(event) {

					var replacedValue = event.target.value.replace(/\b(?!000)(?!666)(?:[0-6]\d{3}|7(?:[0-356]\d|7[012]))[- ](?!00)\d{2}[- ](?!0000)\d{4}\b/g, '');
					console.log('SSN-DIRECTIVE: replacedValue ==>', replacedValue);

					if (event.target.value != replacedValue) {
						event.target.value = replacedValue
					}

					$browser.defer(listener); // Have to do this or changes don't get picked up properly
				});
				$element.bind('paste cut', function() {
					$browser.defer(listener);
				});
			}
		};
	}

})(window.angular);
