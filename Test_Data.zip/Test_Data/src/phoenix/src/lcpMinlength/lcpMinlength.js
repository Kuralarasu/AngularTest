var lcp;
(function (lcp) {
    var minlength;
    (function (minlength_1) {
        var directive;
        (function (directive) {
            var LcpMinlength = (function () {
                function LcpMinlength() {
                    this.priority = 1;
                    this.restrict = "A";
                    this.require = "ngModel";
                    this.link = this.linkFunc;
                }
                LcpMinlength.instance = function () {
                    return new LcpMinlength();
                };
                LcpMinlength.prototype.linkFunc = function (scope, ele, attrs) {
                    var input = ele.find("input")[0] ? ele.find("input") : ele, ngModel = input.controller("ngModel");
                    console.log("linkFunc: ", input, ngModel);
                    input.on("keyup", function (event) {
                        var value = event.target.value, minlength = Number(attrs["lcpMinlength"]), validity = event.target.selectionStart === 0
                            && event.target.selectionEnd === minlength ? true : (value.length < minlength ? false : true);
                        if (!value) {
                            return;
                        }
                        ngModel.$setValidity("minlength", validity);
                    });
                };
                return LcpMinlength;
            }());
            angular.module("phxuilib.lcpMinlength", []).directive("lcpMinlength", LcpMinlength.instance);
        })(directive = minlength_1.directive || (minlength_1.directive = {}));
    })(minlength = lcp.minlength || (lcp.minlength = {}));
})(lcp || (lcp = {}));
//# sourceMappingURL=lcpMinlength.js.map