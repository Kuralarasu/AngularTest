/// <reference path="../../../typings/tsd.d.ts" />
/* tslint:disable:no-string-literal */
/**
 * @ngdoc directive
 * @name lcpMinlength
 *
 * @description
 *
 * Since ngMinlength set the validity it also remove the render content, this lcpMinlength is to set the validity
 * but not to remove the render content from the model.
 *
 *
 */
module lcp.minlength.directive {
    class LcpMinlength implements ng.IDirective {
        public  priority = 1;
        public restrict = "A";
        public require = "ngModel";
        public link: (scope: ng.IScope, ele: ng.IAugmentedJQuery, attrs: ng.IAttributes) => void;

        public static instance(): ng.IDirective {
            return new LcpMinlength();
        }
        constructor() {
            this.link = this.linkFunc;
        }

        public linkFunc(scope: ng.IScope, ele: ng.IAugmentedJQuery, attrs: ng.IAttributes) {

            let input = ele.find("input")[0] ? ele.find("input") : ele,
                ngModel = input.controller("ngModel");

            console.log("linkFunc: ", input, ngModel);
            input.on("keyup", function (event: any) {

                let value = event.target.value,
                    minlength = Number(attrs["lcpMinlength"]),
                    validity = event.target.selectionStart === 0
                                && event.target.selectionEnd === minlength ? true : (value.length < minlength ? false : true);

                if (!value) {
                    return;
                }


                ngModel.$setValidity("minlength", validity);

            });
        }

    }

        angular.module("phxuilib.lcpMinlength", []).directive("lcpMinlength", LcpMinlength.instance);
}






