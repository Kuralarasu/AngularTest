/**
 * Created by ramor11 on 10/5/2016.
 */

require('./lcp-toggle.less')
var module = require('./lcp-toggle');
module.exports = module;
