/**
 * Created by ramor11 on 4/8/2016.
 */
(function (angular) {
	'use strict';


	angular.module('lcp.toggle.directive', []).run(["$templateCache", function ($templateCache) {

		$templateCache.put(
			'/lcp.toggle.directive/lcp.toggle.tpl.html',
			[
				'<lcp-switch data-ng-model="ctrl.ngModel" ng-class="{\'md-checked\':ctrl.ngModel}" >',
				'	<div class="_md-container">',
				'		<div class="_md-bar"></div>',
				'		<div class="_md-thumb-container">',
				'			<div class="_md-thumb md-ink-ripple pointer"  ng-class="{\'md-checked\':ctrl.ngModel}" md-ink-ripple md-ink-ripple-checkbox>',
				'				<span ng-bind="(ctrl.ngModel === ctrl.ngTrueValue?ctrl.ngTrueDisplay:ctrl.ngFalseDisplay)"></span>',
				'				<div class="md-ripple-container"></div>',
				'			</div>',
				'		</div>',
				'	</div>',
				'</lcp-switch>'
			].join(" "));


	}]).directive('lcpToggle', lcpToggle);


	lcpToggle.$inject = ['$window'];

	function lcpToggle($window) {

		var directive = {
			restrict: 'E',
			require: ['lcpToggle', '?ngModel'],
			scope: {
				ngModel: "=",
				ngTrueValue: "@",
				ngTrueDisplay: "@",
				ngFalseValue: "@",
				ngFalseDisplay: "@",
			},
			templateUrl: '/lcp.toggle.directive/lcp.toggle.tpl.html',
			controller: [function () {
				var self = this,
					ngModelController;

				//define with value from attr, or set boolean
				this.ngTrueValue = isDefined(this.ngTrueValue) ? this.ngTrueValue : true;
				this.ngFalseValue = isDefined(this.ngFalseValue) ? this.ngFalseValue : false;
				//set the default value
				this.ngModel = this.ngModel ? this.ngTrueValue : this.ngFalseValue;

				this.init = function (scope, $ctrl) {
					ngModelController = $ctrl
					var _watchers = [];

					_watchers.push(scope.$parent.$watch(function () {
						return self.ngModel;
					}, function (value) {
						if (typeof value === "undefined")return;

						ngModelController.$setViewValue(value);
						ngModelController.$render();

					}).bind(self));

					scope.$on('$destroy', function () {
						while (_watchers.length) {
							_watchers.shift();
						}
					});
				};
			}],
			controllerAs: 'ctrl',
			bindToController: true,
			link: function (scope, ele, attr, ctrl) {

				var ngModelCtrl = angular.extend({}, {$setViewValue: angular.noop}, ctrl[1]),
					lcpToggleCtrl = ctrl[0];

				if (!ngModelCtrl) {
					return; // do nothing if no ng-model
				}

				ngModelCtrl.$viewChangeListeners.push(function () {
					scope.$eval(attr.ngChange);
				});

				lcpToggleCtrl.init(scope, ngModelCtrl);

				ele[0].addEventListener('click', function (e) {
					var e = event || $window.event;
					if (e)e.stopPropagation();
					trigger(!lcpToggleCtrl.ngModel)
				});

				function trigger(isChecked) {
					ngModelCtrl.$setViewValue(isChecked);
					ngModelCtrl.$render()
				}

			}
		};

		function isDefined(obj) {
			return angular.isDefined(obj) ? obj : false;
		};


		return directive;

	}


})(window.angular);
