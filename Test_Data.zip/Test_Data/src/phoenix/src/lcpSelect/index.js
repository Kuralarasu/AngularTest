/**
 * Created by ramor11 on 10/5/2016.
 */


require('./lcp-select.less');
var module = require('./lcpSelect');
module.exports = module;
