/**
 * Created by ramor11 on 3/29/2016.
 */


(function (angular) {
	'use strict';

	/**
	 * @ngdoc directive
	 * @name lcp.select.directive.lcpSelect
	 *
	 *
	 * @requires $timeout
	 * @requires $window
	 *
	 * @description
	 *
	 * Component directive for select dropdown based on ngMaterial design.
	 *
	 * @scope
	 *    label: "@placeholder",  //placeholder to define the label within element
	 *    ariaLabel: "sting",
	 *    id: "string",
	 *    ngChange: "function expression", //expression to evaluate
	 *    map: '=?', //if the options object needs to map to a different parameters for name and value name => anotherName, value => anotherValue
	 *    model: "=ngModel",
	 *    ngReadonly: "string",  //boolean default false
	 *    focused: "string", //boolean default false
	 *    options: 'array', //an array of items to pass into the select drop downs [{value:'',name:''}]
	 *    lcpOptions: 'object', // Object defining the current scope variables in object referent in controller vs attribute
	 *    required: 'string'  //boolean default false
	 *
	 * @example:
	 *
	 *
	 * ```html
	 *
	 * <lcp-select lcp-options="ctrl.predefinedDataSetOpts" ng-model="ctrl.src.predefinedDataSet"></lcp-select>
	 *
	 * <!-- OR -->
	 *
	 * <lcp-select placeholder="Saved Views"
	 *                options="ctrl.savedVisualization"
	 *                ng-change="ctrl.onSavedVisualizationChange"
	 *                ng-model="ctrl.src.savedVisualization">
	 * </lcp-select>
	 *
	 * ```
	 *
	 * ```js
	 *
	 *    self.predefinedDataSetOpts = {
	 *		placeholder: 'Predefined Data Set',
	 *		options: [
	 *			{name:'Batman', value:'123'},
	 *			{name:'Superman', value:'456'},
	 *			{name:'Aquaman', value:'789', disabled:true}
	 *  	],
	 *		name: "predefinedDataSetOpts",
	 *		id: "predefinedDataSetOpts",
	 *		onSelected: function (obj) {
	 *			//return the object reference on select
	 *		}
	 *	};
	 *
	 * ```
	 *
	 */


	angular.module('lcp.select.directive', []).directive('lcpSelect', lcpSelect);

	lcpSelect.$inject = ['$timeout', '$window', '$parse']

	function lcpSelect($timeout, $window, $parse) {

		function isDefined(obj) {
			return angular.isDefined(obj) ? obj : false;
		}

		var directive = {
			restrict: 'E',
			require: ['lcpSelect', '?ngModel', '^?form'],
			scope: {
				label: "@placeholder",
				ariaLabel: "@",
				id: "@",
				map: '=?', //if the options object needs to map to a different parameters for name and value name => onotherName, value => anotherValue
				model: "=ngModel",
				ngReadonly: "=?",
				focused: "=?",
				options: '=?', //an array of items to pass into the select drop downs
				lcpOptions: '=', //if this object exist, it will override the existing attributes in the element
				required: '@'
			},
			controller: ['$scope', '$element', '$attrs', function ($scope, $element, $attrs) {
				var self = this,
					lcpOptions = isDefined(this.lcpOptions) || {},
					ngModelCtrl = {$setViewValue: angular.noop},
					$scope;

				self.isRequired = $attrs.hasOwnProperty('lcpRequired');

				self.loopObj = [];
				self.loopObjSorted = [];
				self.charFromCharCode = null;
				self.label = isDefined(this.label) ? this.label : (isDefined(lcpOptions.placeholder) ? lcpOptions.placeholder : "");
				self.ariaLabel = isDefined(this.ariaLabel) ? this.ariaLabel : this.label;
				self.focused = isDefined(self.focused) ? self.focused : false;

				function buildOptions(obj) {
					self.loopObj = [];
					angular.forEach(obj, function (obj) {
						if (!obj.hasOwnProperty('value') && typeof obj === 'string') {
							obj = {
								name: String(obj).trim(),
								value: String(obj).trim()
							};
						} else if (!obj.hasOwnProperty('value') || !obj.hasOwnProperty('name')) {
							//if the object is an object but does not contain name, value
							obj = {
								name: String(obj[self.map['name']]).trim(),
								value: String(obj[self.map['value']]).trim()
							};
						}
						this.push(obj);
					}, self.loopObj);

					self.loopObjSorted = self.loopObj.map(function (obj) {
						return obj;
					}).sort(function(a, b) {
						var nameA = a.name.toUpperCase();
						var nameB = b.name.toUpperCase();
						if (nameA < nameB) {
							return -1;
						}
						if (nameA > nameB) {
							return 1;
						}
						return 0;
					});
				}


				self.init = function (scope, $ctrl) {
					ngModelCtrl = $ctrl
					$scope = scope;

					var _watchers = [];

					[function () {
						return lcpOptions.options;
					}, function () {
						return self.options;
					}].forEach(function (func) {
						_watchers.push(scope.$parent.$watch(func, function (options) {
							if (options)buildOptions(options);
						}).bind(self));
					});

					scope.$on('$destroy', function () {
						while (_watchers.length) {
							_watchers.shift();
						}
					});

				}


				self.onChangeOptions = function ($event, value) {

					var e = event || $window.event;
					if (e)e.stopPropagation();


					var func = isDefined(lcpOptions.onSelected) || angular.noop,
						selected = self.loopObj.filter(function (ob) {
								return value === ob.value;
							})[0] || false;


					ngModelCtrl.$setViewValue(self.model);
					ngModelCtrl.$render();

					if (typeof func === 'function')func.apply(self, [selected]);

				};

				// Array.findIndex (ES6) polyfill for IE:
				// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/findIndex#Polyfill
				if (!Array.prototype.findIndex) {
					Array.prototype.findIndex = function(predicate) {
						if (this === null) {
							throw new TypeError('Array.prototype.findIndex called on null or undefined');
						}
						if (typeof predicate !== 'function') {
							throw new TypeError('predicate must be a function');
						}
						var list = Object(this);
						var length = list.length >>> 0;
						var thisArg = arguments[1];
						var value;

						for (var i = 0; i < length; i++) {
							value = list[i];
							if (predicate.call(thisArg, value, i, list)) {
								return i;
							}
						}
						return -1;
					};
				}

				function findByValue (element) {
					return element.value == self.model;
				}

				function filterByChar (obj) {
					return obj.name.substr(0, 1) == self.charFromCharCode;
				}

				self.onKeyDown = function ($event) {
					var keyCode = $event.charCode || $event.keyCode,
						downArrowPressed = $event.keyCode === 40;
					if (!self.model) {
						// If the first option is disabled, we must manually select the next non-disabled option:
						if (downArrowPressed && self.loopObj[0].disabled) {
							var firstEnabled = self.loopObj.filter(function (obj) {
								return !obj.hasOwnProperty('disabled') || obj.hasOwnProperty('disabled') && obj.disabled !== true;
							});
							if (firstEnabled.length) {
								self.model = firstEnabled[0].value;
							}
						}
						return;
					}
					var modelName = self.loopObjSorted.filter(findByValue)[0].name;
					var modelCharCodeAt0 = modelName.charCodeAt(0);
					self.charFromCharCode = null;
					// Match keyCodes (31 through 90) used by md-select in handleKeypress():
					// https://github.com/angular/material/blob/release/1.0.7/src/components/select/select.js#L448
					if (keyCode <= 90 && keyCode >= 31 && keyCode == modelCharCodeAt0) {
						self.charFromCharCode = String.fromCharCode(keyCode);
						var options = self.loopObjSorted.filter(filterByChar);
						var selectedIndex = options.findIndex(findByValue);
						$event.preventDefault();
						$timeout(function () {
							//if (keyCode === 40)
								self.model = options[selectedIndex + 1] ? options[selectedIndex + 1].value : options[0].value;
						}, 0);
					}
				};


			}],
			controllerAs: 'ctrl',
			bindToController: true,
			link: postLinkFunc
		};


		directive.template = [
			'<div class="lcp-select" ng-class="{\'md-focused\':ctrl.focused,\'has-input-values\':ctrl.model.length,\'lcp-readonly\':ctrl.ngReadonly}">',
			'<md-input-container class="md-block">',
			'<label ng-bind-html="ctrl.label"></label>',
			'<md-select ng-model="ctrl.model" aria-label="{{ctrl.ariaLabel}}" ng-class="{\'ng-touched\':ctrl.toShow(), \'ng-empty\':ctrl.toShow()}"',
			'ng-change="ctrl.onChangeOptions($event, ctrl.model)" ng-keydown="ctrl.onKeyDown($event)">',
			'<md-option ng-repeat="f in ctrl.loopObj track by $index" value="{{f.value}}" ng-disabled="{{f.disabled}}">',
			'<span ng-bind-html="f.name"></span>',
			'</md-option>',
			'</md-select>',
			'<div class="required">Required.</div>',
			'</md-input-container>',
			'</div>'
		].join(' ');

		function postLinkFunc(scope, ele, attr, _ctrl) {

			var lcpSelectCtrl = _ctrl[0],
				ngModelCtrl = angular.extend({}, {$setViewValue: angular.noop}, _ctrl[1]), formCtrl = _ctrl[2];

			if (!ngModelCtrl) {
				return; // do nothing if no ng-model
			}

			ngModelCtrl.$viewChangeListeners.push(function () {
				scope.$eval(attr.ngChange);
			});


			lcpSelectCtrl.init(scope, ngModelCtrl);

			lcpSelectCtrl.toShow = function () {

				var bool = false;
				if (formCtrl && angular.isDefined(formCtrl.$submitted)) {
					if (formCtrl.$submitted && !this.model) {
						bool = true;
					}
				}

				return bool;
			};

			$timeout(function () {
				if (attr.hasOwnProperty('lcpRequired') && !attr.hasOwnProperty('ngRequired')) {
					ele.find('label').addClass('md-required');
					ele.find('md-select-value').addClass('md-select-required');
					ele.find('md-select').attr('required', 'required');
				}
			});

			// $timeout(function () {
			// 	ele.find('input').on('focus', function (e) {
			// 		ctrl.focused = true;
			// 		ele.addClass('md-focused')
			// 	}).on('blur', function (e) {
			// 		ctrl.focused = false;
			// 		ele.removeClass('md-focused');
			// 	});
			// })


		};


		return directive;
	};

})(window.angular);
