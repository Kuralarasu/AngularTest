/**
 * Created by ramor11 on 10/14/2016.
 */

// this is needed for rules editor
// , 'ui.bootstrap' is added as a dependency to the module



module.exports = function(){

	require('./src/_vendor/angular-bootstrap/custom-ui-bootstrap');
	require('./src/_vendor/angular-bootstrap/custom-ui-bootstrap-tpls');
	require('./src/_vendor/angular-bootstrap/src/dateparser/dateparser');
	require('./src/_vendor/angular-bootstrap/src/position/position');

}();
