module.exports = function (app) {
    'use strict';

    app.controller('ErrorDetailsController', function ($scope, $stateParams, $filter, uiGridConstants, $mdDialog, $location, $window, ERROR_MANAGEMENT_CONSTANTS, errorDetailservice) {

        var errorId = $stateParams.id;
        var selectedStatusId = $stateParams.selectedStatusId;
        $scope.fileData="";

        

        $scope.getErrorDetails  = function() {
            

            //TODO make a constants or a config file for these URLs
                errorDetailservice.geterrorData(errorId)
                    .then(function (response) {
                        $scope.errorData = response.data;
                        var parameters = JSON.parse($scope.errorData.Parameters);
                        var fileStoreId = parameters.FileStoreId;
                        if (fileStoreId != null){
                            errorDetailservice.getfileData(fileStoreId)
                            .then(function (response) {
                            $scope.fileData = response.FileData;
                        });
					}
                    }, function (message) {
                        displayErrors(message);
                    });
            
            
                errorDetailservice.geterrorResolutionData(errorId)
                    .then(function (response) {
                        $scope.errorResolutionData = response.data;
                        console.log("errorResolutionData");
					console.log($scope.errorResolutionData);
					$scope.errorResolutionGrid.data = $scope.errorResolutionData;
                }, function (message) {
                        displayErrors(message);
                    });
            
            $scope.errorResolutionGrid = {
				enableRowSelection: false,
				enableSelectAll: false,
				selectionRowHeaderWidth: 35,
				rowHeight: 35,
				showGridFooter: true, 
                enableFiltering: true,
				enableGridMenu: true
			};

			$scope.errorResolutionGrid.columnDefs = [
				{ field: 'CreatedDateTime', displayName: 'Date', minWidth: 150,  },
				{ field: 'UserId', displayName: 'User', minWidth: 100 },
				{ field: 'ActionStatus.Description', displayName: 'Status', minWidth: 130 },
				{ field: 'ActionResolution.Description', displayName: 'Resolution', minWidth: 200 },
				{ field: 'ActionSend.Description', displayName: 'Resend', minWidth: 120 },
				{ field: 'Comment', displayName: 'Comment', minWidth: 3825 }
			];
        };
        $scope.getErrorDetails();
        

        $scope.showResoluitonDetailsModal = function () {
            $mdDialog.show({
				scope: $scope,
				contentElement: '#resolutionDetailEntry',
				preserveScope: true
			});
		};
        function displayErrors(message) {
                var outputMessage = message ? message : "error connecting to service.";

                alert(outputMessage);
                console.log(outputMessage);
            }
		

    });

}