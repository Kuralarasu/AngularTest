module.exports = function (app) {
	'use strict';

	app.controller('ErrorManagementController', function ($scope, $stateParams, uiGridConstants, $mdDialog, $location, $window, ERROR_MANAGEMENT_CONSTANTS, errorManagementservice) {
		//$scope.errorsAvailable = $scope.getErrors();

		$scope.getErrorOnChange = function () {
			$scope.getErrors();
		}

		$scope.getLabNameOnHover = function () {
			getLabName();
		}

		$scope.message = "Enabledtitle";

		$scope.getErrors = function() {

			//Get the error statuses
			
			errorManagementservice.geterroractionStatus()
                    .then(function (response) {
                        $scope.actionStatus = response.data;
					console.log("action statuses");
					console.log(response.data);
					}, function (message) {
                        displayErrors(message);
                    });
			

			//First get the types. This call is done separately because calling it as expand graph causes performance issues
			errorManagementservice.geterrorsAvailable()
                    .then(function (response) {
                        var typesArray = response.data;
					console.log("typesArray");
					console.log(typesArray);

					var selectedActionStatus = $scope.selectedActionStatus;
					console.log("selectedActionStatus");
					console.log(selectedActionStatus);

					if (selectedActionStatus == "1") {
						
						errorManagementservice.getAllerrorsAvailable()
                    .then(function (response) {
                        $scope.errorsAvailable = response.data;
					mergeTypesToErrorsAndUpdateGrid(typesArray);
					}, function (message) {
                        displayErrors(message);
                    });
						
					} else if (selectedActionStatus == 2) {
						errorManagementservice.geterrorsAvailableforUnassigned()
                    .then(function (response) {
                        $scope.errorsAvailable = response.data;
					mergeTypesToErrorsAndUpdateGrid(typesArray);
					}, function (message) {
                        displayErrors(message);
                    });
						
					}
						 else if (selectedActionStatus >= 3) {
						errorManagementservice.geterrorsAvailableforselectedActionStatus(selectedActionStatus)
                    .then(function (response) {
                        $scope.errorsAvailable = response.data;
					mergeTypesToErrorsAndUpdateGrid(typesArray);
					}, function (message) {
                        displayErrors(message);
                    });
						
						 }
					});
		}

		$scope.getErrors();
		function displayErrors(message) {
                var outputMessage = message ? message : "error connecting to service.";

                alert(outputMessage);
                console.log(outputMessage);
            }

		function getLabName() {
        
			//First get the types. This call is done separately because calling it as expand graph causes performance issues
			errorManagementservice.getlabName()
                    .then(function (response) {
                        $scope.labName = response;
					
					}, function (message) {
                        displayErrors(message);
                    });
						
			

		};

		function mergeTypesToErrorsAndUpdateGrid(typesArray) {

			$scope.errorsAvailable.forEach(function (errorItem) {

				typesArray.forEach(function (errorType) {
					if (errorItem.TypeId === errorType.Id) {
						errorItem.Type = errorType;
					}
				});

			});

			$scope.errorManagementGrid.data = $scope.errorsAvailable;
			$scope.gridApi.core.handleWindowResize();
		};

		$scope.errorManagementGrid = {
			enableRowSelection: true,
			enableSelectAll: true,
			selectionRowHeaderWidth: 35,
			rowHeight: 35,
			showGridFooter: true, enableFiltering: true,
			enableGridMenu: true,
			enableGroupHeaderSelection: false
		}
		$scope.errorManagementGrid.columnDefs = [

			{ field: 'Id', cellTemplate: '<div class="ui-grid-cell-contents tooltip-uigrid" title="{{row.entity.Id}}"><a ui-sref="errorDetails({id: row.entity.Id})">{{COL_FIELD}}</a></div>', minWidth: 50 },
			{ field: 'Type.TypeEorSystemXRefs[0].EorSystem.Description', displayName: 'Source', minWidth: 75 },
			{ field: 'Summary', minWidth: 150 },
			{ field: 'Type.Description', displayName: 'Type', minWidth: 100 },
			{ field: 'SendingApplication', displayName: 'Lab Id', minWidth: 130 },
			{ field: 'LaboratoryName', displayName: 'Lab Name', minWidth: 200 },
			{ field: 'AccessionNo', displayName: 'Acc-Cont', minWidth: 120 },
			{ field: 'MasterTestCode', cellTemplate: '<div class="ui-grid-cell-contents tooltip-uigrid" title="{{ getLabNameOnHover() }}">{{COL_FIELD}}</div>', displayName: 'Master Test', minWidth: 130 },
			{ field: 'ZavacorTestCode', displayName: 'CLS Source Test', minWidth: 100 },
			{ field: 'ProjectNo', displayName: 'Project No', minWidth: 100 },
			{ field: 'DateCreated', displayName: 'Date Time', minWidth: 120, type: 'date', cellFilter: 'date:\'medium\'' } //,
		];

		$scope.errorManagementGrid.multiSelect = true;

		$scope.errorManagementGrid.onRegisterApi = function (gridApi) {
			$scope.gridApi = gridApi;
			gridApi.grouping.clearGrouping();
			//gridApi.selection.selectRow(vm.gridOptions.data[0]);
			gridApi.selection.on.rowSelectionChanged($scope, function (row) {
				console.log(row.entity.Id);
			});
			gridApi.selection.on.rowSelectionChangedBatch($scope, function (row) {
				$scope.countRows = $scope.gridApi.selection.getSelectedRows().length;
				console.log($scope.countRows);
			});
		};

		// Take selected rows and export them
		$scope.exportSelectedErrors = function () {
			var selectedErrors = $scope.gridApi.selection.getSelectedRows();
			console.log(selectedErrors);
			console.log("Export");

			//initalize an array to hold selected error IDs to pass to webAPI controller
			var selectedErrorIdList = [];

			selectedErrors.forEach(function (element) {
				selectedErrorIdList.push(element.Id);
			});

			console.log(selectedErrorIdList);

			if (selectedErrors != null) {

				errorManagementservice.postselectedErrorIdList()
                    .then(function (response) {
                        console.log(response.data);
						var filename = 'testcsv.csv';
						var contentType = 'text/csv;charset=utf-8';
						var blob = new Blob([data], { type: contentType });
						if (window.navigator && window.navigator.msSaveOrOpenBlob) {
							window.navigator.msSaveOrOpenBlob(blob, filename);
						} else {
							var e = document.createEvent('MouseEvents'),
								a = document.createElement('a');
							a.download = filename;
							a.href = window.URL.createObjectURL(blob);
							a.dataset.downloadurl = ['text/json', a.download, a.href].join(':');
							e.initEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
							a.dispatchEvent(e);
							//window.URL.revokeObjectURL(url); // clean the url.createObjectURL resource
						}
					}, function (message) {
                        displayErrors(message);
                    });
				
				console.log("outside of http call");
			}
		};

		$scope.resolveSelectedErrors = function () {
			$scope.selectedErrors = $scope.gridApi.selection.getSelectedRows();
			console.log("resolveErrors");
			console.log($scope.selectedErrors);

			var errorType = $scope.selectedErrors[0].TypeId;
			if ($scope.selectedErrors.every(errorTypeUnique)){
				//Replace with component 
				$scope.showResoluitonDetailsModal();
			}
			else{
				var displayMessage = "Not all errors selected for resolution are of the same type. Batch error resolution can only be performed on a single Type.";
				alert(displayMessage);
			};			
		};

		function errorTypeUnique(typeIdElement, index, arr) {
			if (index === 0){
				return true;
			}
			else{
				return (typeIdElement.TypeId === arr[index - 1].TypeId);
			}
		};
		
		//Everything below here is logic going in component
		$scope.showResoluitonDetailsModal = function () {
			$mdDialog.show({
				scope: $scope,
				contentElement: '#resolutionDetailEntry',
				preserveScope: true
			});
		};
	});
};
