/**
 * Created by ramor11 on 4/20/2016.
 */
/**
 * Created by ramor11 on 4/20/2016.
 */



module.exports = {
	"order": 6, //define the order of the module to display onto UI
	// "position": 'secondary', //position of the order, default secondary, primary is reserved for topmost nav bar
	"display": "Error Management",//Module name to display to UI
	/**
	 * Siteminder Authorization ID name
	 */
	"auth": ["errorManagement"],
	"maps": [
		{ id: "errorManagement", state: 'errorManagement'},
		{ id: "errorManagement.cloverleaf", state: 'cloverleaf'},
		{ id: "errorManagement.eorErrorManagement", state: 'eorErrorManagement'}	,
		{ id: "errorManagement.errorDetails", state: 'errorDetails' }	
	 ]
};
