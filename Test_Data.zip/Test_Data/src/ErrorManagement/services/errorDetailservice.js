module.exports = function (errorManagementModule) {
    'use strict';
    errorManagementModule.factory('errorDetailservice', ErrorDetailservice);

ErrorDetailservice.$inject = ['$q', 'eorRestAPIService', 'errorManagementUrlservice'];

    function ErrorDetailservice($q, eorRestAPIService, errorManagementUrlservice) {

        var errorDetailsObject = {};
        errorDetailsObject.geterrorData = geterrorData;
        errorDetailsObject.geterrorResolutionData = geterrorResolutionData;
        errorDetailsObject.getfileData = getfileData;
        
       function geterrorData(errorId) {

             var deferred = $q.defer();
            var url = errorManagementUrlservice.geterrorDataUrl(errorId);
            var config = { withCredentials: true };
            eorRestAPIService.get(url, config).then(
                function (response) {
                    deferred.resolve(response);
                },
                function (error) {
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }
        function geterrorResolutionData(errorId) {

             var deferred = $q.defer();
            var url = errorManagementUrlservice.geterrorResolutionDataUrl(errorId);
            var config = { withCredentials: true };
            eorRestAPIService.get(url, config).then(
                function (response) {
                    deferred.resolve(response);
                },
                function (error) {
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }
        function getfileData(fileStoreId) {

             var deferred = $q.defer();
            var url = errorManagementUrlservice.getfileDataUrl(fileStoreId);
            var config = { withCredentials: true };
            eorRestAPIService.get(url, config).then(
                function (response) {
                    deferred.resolve(response);
                },
                function (error) {
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }
        
         return errorDetailsObject;
    }

};