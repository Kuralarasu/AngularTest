module.exports = function (errorManagementUrlModule) {
    'use strict';
    errorManagementUrlModule.service('errorManagementUrlservice', ErrorManagementUrlservice);

    ErrorManagementUrlservice.$inject = ['ERROR_MANAGEMENT_CONSTANTS'];

    function ErrorManagementUrlservice(ERROR_MANAGEMENT_CONSTANTS) {
        //error details urls
        this.geterrorDataUrl = geterrorDataUrl;
        this.getfileDataUrl = getfileDataUrl;
        this.geterrorResolutionDataUrl = geterrorResolutionDataUrl;
        //error management urls
        this.geterroractionStatusUrl = geterroractionStatusUrl;
        this.geterrorsAvailableUrl = geterrorsAvailableUrl;
        this.getAllerrorsAvailableUrl = getAllerrorsAvailableUrl;
        this.geterrorsAvailableforUnassignedUrl = geterrorsAvailableforUnassignedUrl;
        this.geterrorsAvailableforselectedActionStatusUrl = geterrorsAvailableforselectedActionStatusUrl;
        this.getlabNameUrl = getlabNameUrl;
        this.postselectedErrorIdListUrl = postselectedErrorIdListUrl;

         //error details urls
        
        function geterrorDataUrl(errorId) {
            
            var url = ERROR_MANAGEMENT_CONSTANTS.errorMangementApiUrl + "ErrorManagements\\" + errorId + "?expandGraph=[%22ActionStatus%22,%22Type.TypeEorSystemXRefs.EorSystem%22]";
            return url;
        }

        function getfileDataUrl(fileStoreId) {
            var url = ERROR_MANAGEMENT_CONSTANTS.errorMangementApiUrl+ "FileStores\\" + fileStoreId;
            return url;
        }

        function geterrorResolutionDataUrl(errorId) {
            var url = ERROR_MANAGEMENT_CONSTANTS.errorMangementApiUrl + "ErrorManagementActions\\?searchExpression=p => p.ErrorManagementId == " + errorId +"&expandGraph=[%22ActionStatus%22,%22ActionResolution%22,%22ActionSend%22]";
            return url;
        }

         //error management urls
       function geterroractionStatusUrl() {
            
            var url = ERROR_MANAGEMENT_CONSTANTS.errorMangementApiUrl + "ActionStatus";
            return url;
        }
        
        function geterrorsAvailableUrl() {
            
            var url = ERROR_MANAGEMENT_CONSTANTS.errorMangementApiUrl + "Types?expandGraph=[%22TypeEorSystemXRefs.EorSystem%22]";
            return url;
        } 

        function getAllerrorsAvailableUrl() {
            var url = ERROR_MANAGEMENT_CONSTANTS.errorMangementApiUrl + "ErrorManagements?searchExpression=p => p.TypeId != 14";
            return url;
        }

        function geterrorsAvailableforUnassignedUrl() {
            var url = ERROR_MANAGEMENT_CONSTANTS.errorMangementApiUrl + "ErrorManagements?searchExpression=p => p.ActionStatusId == null and p.TypeId != 14";
            return url;
        }
        function geterrorsAvailableforselectedActionStatusUrl(selectedActionStatus) {
            
            var url = ERROR_MANAGEMENT_CONSTANTS.errorMangementApiUrl + "ErrorManagements?searchExpression=p => p.ActionStatusId == " + selectedActionStatus + " and p.TypeId != 14";
            return url;
        }

        function getlabNameUrl() {
            var url = ERROR_MANAGEMENT_CONSTANTS.errorMangementApiUrl + "MasterPerformingLocations?searchExpression=p=>p.CPRODUCTID==%22000000000140%22";
            return url;
        }

        function postselectedErrorIdListUrl() {
            var url = ERROR_MANAGEMENT_CONSTANTS.errorMangementApiUrl + "ErrorManagements/Export";
            return url;
        }

        
    }
}