module.exports = function (errorManagementModule) {
    'use strict';
    errorManagementModule.factory('errorManagementservice', ErrorManagementservice);

ErrorManagementservice.$inject = ['$q','eorRestAPIService', 'errorManagementUrlservice'];

    function ErrorManagementservice($q, eorRestAPIService, errorManagementUrlservice) {

              var errorManagementObject = {};
        errorManagementObject.geterroractionStatus = geterroractionStatus;
        errorManagementObject.geterrorsAvailable = geterrorsAvailable;

        errorManagementObject.getAllerrorsAvailable = getAllerrorsAvailable;
        errorManagementObject.geterrorsAvailableforUnassigned = geterrorsAvailableforUnassigned;
        errorManagementObject.geterrorsAvailableforselectedActionStatus = geterrorsAvailableforselectedActionStatus;
        errorManagementObject.getlabName = getlabName;
        errorManagementObject.postselectedErrorIdList = postselectedErrorIdList;
        function geterroractionStatus() {

            var deferred = $q.defer();
            var url = errorManagementUrlservice.geterroractionStatusUrl();
            var config = { withCredentials: true };
            eorRestAPIService.get(url, config).then(
                function (response) {
                    deferred.resolve(response);
                },
                function (error) {
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }
        function geterrorsAvailable() {

            var deferred = $q.defer();
            var url = errorManagementUrlservice.geterrorsAvailableUrl();
            var config = { withCredentials: true };
            eorRestAPIService.get(url, config).then(
                function (response) {
                    deferred.resolve(response);
                },
                function (error) {
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }

        function getAllerrorsAvailable() {

            var deferred = $q.defer();
            var url = errorManagementUrlservice.getAllerrorsAvailableUrl();
            var config = { withCredentials: true };
            eorRestAPIService.get(url, config).then(
                function (response) {
                    deferred.resolve(response);
                },
                function (error) {
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }
        function geterrorsAvailableforUnassigned() {

            var deferred = $q.defer();
            var url = errorManagementUrlservice.geterrorsAvailableforUnassignedUrl();
            var config = { withCredentials: true };
            eorRestAPIService.get(url, config).then(
                function (response) {
                    deferred.resolve(response);
                },
                function (error) {
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }
        function geterrorsAvailableforselectedActionStatus(selectedActionStatus) {

            var deferred = $q.defer();
            var url = errorManagementUrlservice.geterrorsAvailableforselectedActionStatusUrl(selectedActionStatus);
            var config = { withCredentials: true };
            eorRestAPIService.get(url, config).then(
                function (response) {
                    deferred.resolve(response);
                },
                function (error) {
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }
        function getlabName() {

            var deferred = $q.defer();
            var url = errorManagementUrlservice.getlabNameUrl();
            var config = { withCredentials: true };
            eorRestAPIService.get(url, config).then(
                function (response) {
                    deferred.resolve(response.data);
                },
                function (error) {
                    deferred.reject(error.data);
                }
            );
            return deferred.promise;
        }
        function postselectedErrorIdList(selectedErrorIdList) {

            var deferred = $q.defer();

            var url = errorManagementUrlservice.postselectedErrorIdListUrl();
            var data = selectedErrorIdList;
            var config = {
                withCredentials: true,
                headers: {
							'Content-Type': 'application/json'
						}
            };

            eorRestAPIService.post(url, data, config).then(
                function (response) {
                    deferred.resolve(response.data);
                },
                function (error) {
                    deferred.reject(error.data);
                }
            );
            return deferred.promise;
        }
         return errorManagementObject;
  
    }

};