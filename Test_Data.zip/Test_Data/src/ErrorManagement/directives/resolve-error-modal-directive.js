module.exports = function (app) {
    'use strict';

    app.directive('resolveErrorModal',['$http', '$mdDialog', 'ERROR_MANAGEMENT_CONSTANTS',  function ($http, $mdDialog, ERROR_MANAGEMENT_CONSTANTS) {

       var directive = {};

		directive.restrict = 'EA';
		directive.template	   = require('html!../views/resolve-error-modal-directive.html'),
		directive.scope = {selectedErrors: '=',  geterrors: '&' },
		directive.link = function ($scope, element, attributes) {
			
            $scope.$watch('selectedErrors', function(newValue, oldValue) {
                            $scope.dialogData = {
                                ActionStatus: "",
                                ActionResolution: "",
                                ActionSend: "",
                                Comment: ""
                            };
                            if(newValue){
                                if(Array.isArray(newValue)){
                                  $scope.typeId = $scope.selectedErrors[0].Type.Id;
                                }
                                else{
                                    $scope.typeId = $scope.selectedErrors.Type.Id;
                                }
                               getDataForActions(); 
                            }
                        });
        
            function getDataForActions() {
                var url = ERROR_MANAGEMENT_CONSTANTS.errorMangementApiUrl;
                $http.get(url + "ActionStatus\\?searchExpression=p => p.Id >= 3")
                .then(function (response) {
                    $scope.statusData = response.data;
                    console.log("statusData");
                    console.log($scope.statusData);
                });

                $http.get(url + "ActionResolutions")
                .then(function (response) {
                    $scope.resolutionData = response.data;
                    console.log("resolutionData");
                    console.log($scope.resolutionData);
                });

                $http.get(url + "ActionSends\\?searchExpression=p => p.TypeId == " + $scope.typeId)
                .then(function (response) {
                    $scope.sendData = response.data;
                    console.log("sendData");
                    console.log($scope.sendData);
                });
            };

		$scope.closeDialog = function () {
			$mdDialog.hide();
		};

		$scope.saveEntry = function () {
            if ($scope.dialogData.Comment == undefined )
            {
                alert("Comment entered exceeds maximum character limit.");
            }
            else{
				//Validate associated records
				var url = ERROR_MANAGEMENT_CONSTANTS.errorMangementApiUrl;
				var errorDataArray = buildArray($scope.selectedErrors);
                var parameterString = buildParameterQueryString(errorDataArray);
                $http.get(url + "ErrorManagements?searchExpression= p => p.ActionStatusId != 5 and " + parameterString)
                .then(function (response) {
                    $scope.relatedData = response.data;
					console.log("relatedData");
                    console.log($scope.relatedData);
                    
                    var relatedDataArray = buildArray($scope.relatedData);
                    if (confirmRelatedErrorProcessing(errorDataArray, relatedDataArray)){
                        //Process unique records with resend
                        var uniqueDataArray = buildUniqueDataArray(relatedDataArray);
                        if(uniqueDataArray.length > 0){
                            uniqueDataArray.forEach(function (item){
                                relatedDataArray = removeArrayElement(relatedDataArray, item);
                                var actionData = buildActionDataJson(item.Id);
                                postActionEntry(actionData, true);
                            });
                        }
                        
                        //Processing remaining duplicate records w/o resending
                        if(relatedDataArray.length > 0){
                            relatedDataArray.forEach(function (item){
                                var actionData = buildActionDataJson(item.Id);
                                postActionEntry(actionData, false);
                            });						
                        }
                        if(((uniqueDataArray.length > 0 ) || (relatedDataArray.length > 0))){
                                
                        }
                        else{
                            refreshTheGrid();
                        }
                        
                    }else{
                        refreshTheGrid();
                    }
                }, function (message) {
                    var displayMessage = message ? message : "Error connecting to service.";
                    alert(displayMessage);
                    console.log(displayMessage);
                });
            };
        };

		function refreshTheGrid(){
            $mdDialog.hide();
            $scope.geterrors();
        }
        function buildArray(dataObject){
            var dataArray = [];
            if (dataObject.constructor == Array){
                dataArray = dataObject;
            }else{
                dataArray.push(dataObject);
            }
            return dataArray;
        };

        function buildParameterQueryString(dataArray){
			var tmpString = "(";
			dataArray.forEach(function(item) {
				tmpString += "p.Parameters = \"" + item.Parameters.replace(/\"/g,"\"\"") + "\" or ";
			});
			return tmpString.slice(0,-4) + ")";
		};

		function confirmRelatedErrorProcessing(errorDataArray, relatedDataArray){
            var relatedRecordProcessingPermitted = true;
            if (errorDataArray.length < relatedDataArray.length){
                var tmpIds = "";
                relatedDataArray.forEach(function (item){
                    tmpIds = tmpIds + item.Id + ", ";
                });
                var errorIds = tmpIds.slice(0,-2);
                relatedRecordProcessingPermitted = confirm("The error(s) selected for resolution have associated error records.  Proceeding will apply same resolution to the following error record(s): " + errorIds);
            }
            return relatedRecordProcessingPermitted;
        };

		function buildUniqueDataArray(dataArray){
            var uniqueDictionary = {};
            var uniqueArray = [];
            dataArray.forEach(function (item){
                if(typeof(uniqueDictionary[item.Parameters]) == "undefined"){
                    uniqueArray.push(item);
                    uniqueDictionary[item.Parameters] = item.Id;
                }
            });
            return uniqueArray;
        };

		function removeArrayElement(theArray, element){
            var index = theArray.indexOf(element);
            if (index > -1) {
                theArray.splice(index,1);
            }
            return theArray;
        };

		function buildActionDataJson(errorId){
            var actionData = {
                "ActionResolutionId": $scope.dialogData.ActionResolution.Id,
                "ActionSendId": $scope.dialogData.ActionSend.Id,
                "ActionStatusId": $scope.dialogData.ActionStatus.Id,
                "Comment": $scope.dialogData.Comment,
                "ErrorManagementId": errorId
            };
            return actionData;
		};
		
		function postActionEntry(data, resubmitError) {
			var url = ERROR_MANAGEMENT_CONSTANTS.errorMangementApiUrl;
			console.log("Posting action to: " + url);

			$http.post(
			//"http://localhost:53198/api/",
			url + "ErrorManagementActions", 
			JSON.stringify(data), 
				{
					withCredentials: true,
					headers: {
						'Content-Type': 'application/json'
					}
				}
			)
			.success(function (response) {
				if (data.ActionSendId != undefined && resubmitError)
				{
					resubmitErrorFun();
				}
                else{
                    refreshTheGrid();
                }
			});
		};

		function resubmitErrorFun()
        {
            if ($scope.dialogData.ActionSend.Id === ERROR_MANAGEMENT_CONSTANTS.zavacorSendId)
            {
                 alert("Error marked as resolved. Order will have to be manually resent from Zavacor");
                 refreshTheGrid();
            }
            else if ($scope.dialogData.ActionSend.Id === ERROR_MANAGEMENT_CONSTANTS.zavOErrorSendId)
            {
                 alert("Error marked as resolved. Order error will have to be manually resent from Zavacor");
                 refreshTheGrid();
            }
            else if ($scope.dialogData.ActionSend.Id === ERROR_MANAGEMENT_CONSTANTS.workflowSendId)
            {
                reInsertOrder();
            }
            else if ($scope.dialogData.ActionSend.Id === ERROR_MANAGEMENT_CONSTANTS.orderSendId)
            {
                reprocessOrder();
            }
            else if ($scope.dialogData.ActionSend.Id === ERROR_MANAGEMENT_CONSTANTS.resultSendId)
            {
                reprocessResult();
            }
            else if ($scope.dialogData.ActionSend.Id === ERROR_MANAGEMENT_CONSTANTS.cloverleafSendId)
            {
                terminateResult();
            }
            else if ($scope.dialogData.ActionSend.Id === ERROR_MANAGEMENT_CONSTANTS.externalSendId)
            {
                terminateResult();
            }
            else if ($scope.dialogData.ActionSend.Id === ERROR_MANAGEMENT_CONSTANTS.orderInsertTermianteSendId)
            {
                terminateOrder();
            }
            else if ($scope.dialogData.ActionSend.Id === ERROR_MANAGEMENT_CONSTANTS.orderTerminateSendId)
            {
                terminateOrder();
            }
            else if ($scope.dialogData.ActionSend.Id === ERROR_MANAGEMENT_CONSTANTS.resultTerminateSendId)
            {
                terminateResult();
            }
            else if ($scope.dialogData.ActionSend.Id === ERROR_MANAGEMENT_CONSTANTS.cimEventSendId)
            {
                reprocessOrder();
            }
            else if ($scope.dialogData.ActionSend.Id === ERROR_MANAGEMENT_CONSTANTS.cimEventTerminateSendId)
            {
                terminateOrder();
            }
            else if ($scope.dialogData.ActionSend.Id === ERROR_MANAGEMENT_CONSTANTS.zavResendOrder)
            {
                alert("Error cannot be resent.  Please resend the order manually from Zavacor.");
            }
            else if ($scope.dialogData.ActionSend.Id === ERROR_MANAGEMENT_CONSTANTS.externalResend)
            {
                alert("Error cannot be resent.  Please contact the external lab, requesting them to correct the result identifier and resend result.");
            }
            else
            {
                alert("Undefined error type. Error cannot be resent.");
                refreshTheGrid();
				console.log("Undefined error type.");
            }
        };

		function reprocessOrder() 
        {
			console.log("Resending order error: " + $scope.typeId);
			$http.post(
			ERROR_MANAGEMENT_CONSTANTS.resendOrderApiUrl + "OrderWF/RetryOrder",
			//"http://localhost:62084/api/OrderWF/RetryOrder",
			$scope.selectedErrors.Parameters,
			{
				headers: {
					'Content-Type': 'application/json'
				}
			}).success(function (response) {
				refreshTheGrid();
                alert("Order error submitted for reprocessing.");
			}).error(function (response) {
				alert("Undefined error type. Error cannot be resent.");
                refreshTheGrid();
			});
		};

		function reprocessResult() 
        {
			console.log("Resending result error: " + $scope.typeId);
			$http.post(
			ERROR_MANAGEMENT_CONSTANTS.resendOrderApiUrl + "ResultWF/RetryResult",
			//"http://localhost:62084/api/ResultWF/RetryResult",
			$scope.selectedErrors.Parameters,
			{
				headers: {
					'Content-Type': 'application/json'
				}
			}).success(function (response) {
				alert("Result error submitted for reprocessing.");
                refreshTheGrid();
			}).error(function (response) {
				alert("Undefined error type. Error cannot be resent.");
                refreshTheGrid();
			});
		};

		function reInsertOrder() 
        {
			console.log("Re-inserting order error: " + $scope.typeId);

			$http.post(
			ERROR_MANAGEMENT_CONSTANTS.resendOrderApiUrl + "OrderWF/ReceiveOrder",
			//"http://localhost:62084/api/OrderWF/ReceiveOrder",
			$scope.selectedErrors.Parameters,
			{
				headers: {
					'Content-Type': 'application/json'
				}
			}).success(function (response) {
				alert("Order error inserted for reprocessing.");
                refreshTheGrid();
			}).error(function (response) {
				alert("Undefined error type. Error cannot be resent.");
                refreshTheGrid();
			});
		};

		function terminateOrder() 
        {
			console.log("Teminate order error: " + $scope.typeId);

           	//parse out parameters to allow addition of reason for termination
            var params = JSON.parse($scope.selectedErrors.Parameters);
            var data = 
            {
                    "OrderId": params.OrderId,
                    "WorkflowInstanceId": params.WorkflowInstanceId,
                    "Reason": $scope.dialogData.ActionResolution.Description
            };
            console.log(data);
			$http.post(
			ERROR_MANAGEMENT_CONSTANTS.resendOrderApiUrl + "OrderWF/TerminateOrder",
            JSON.stringify(data),
			//"http://localhost:62084/api/OrderWF/TerminateOrder", JSON.stringify(data),
			{
				headers: {
					'Content-Type': 'application/json'
				}
			}).success(function (response) {
				alert("Order termination completed.");
                refreshTheGrid();
			}).error(function (response) {
				alert("Undefined error type. Error cannot be resent.");
                refreshTheGrid();
			});
		};

        function terminateResult() 
        {
			console.log("Terminating result error: " + $scope.typeId);

           	//parse out parameters to allow addition of reason for termination
            var params = JSON.parse($scope.selectedErrors.Parameters);
            var data = 
            {
                    "OrderId": params.OrderId,
                    "WorkflowInstanceId": params.WorkflowInstanceId,
                    "Reason": $scope.dialogData.ActionResolution.Description
            };

			$http.post(
			ERROR_MANAGEMENT_CONSTANTS.resendOrderApiUrl + "ResultWF/TerminateResult",
			//"http://localhost:62084/api/ResultWF/TerminateResult",
			JSON.stringify(data),
			{
				headers: {
					'Content-Type': 'application/json'
				}
			}).success(function (response) {
				alert("Result termination completed.");
                refreshTheGrid();
			}).error(function (response) {
				alert("Undefined error type. Error cannot be resent.");
                refreshTheGrid();
			});
		};


		}

		return directive;
    }]);
}