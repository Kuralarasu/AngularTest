/**
 * Created by ramor11 on 11/18/2015.
 */
module.exports = function () {
	"use strict";

	//For custom styles in Reference Data
	require("./styles.less");

	var envConfig = require("../../config/env-config")();
	var phxModule = angular.module("errorManagement", ['ngTouch','ui.grid','ui.grid.selection', 'ui.grid.grouping','ui.grid.resizeColumns',
	require('../_common/eor.Common.js').name, envConfig.name]);

	//Main landing page
	require('./controllers/errorManagementController')(phxModule);

	//Details controller
	require('./controllers/errorDetailsController')(phxModule);	

	require('./filters/prettyJSONFilter')(phxModule);


	//Constants
	require('./constants/errorManagementConstant')(phxModule);

	//Services
	require('./services/errorManagementUrlservice')(phxModule);	

	require('./services/errorDetailservice')(phxModule);

	require('./services/errorManagementservice')(phxModule);	

	

	//Directives
	require('./directives/resolve-error-modal-directive.js')(phxModule);

	return phxModule;
}();
