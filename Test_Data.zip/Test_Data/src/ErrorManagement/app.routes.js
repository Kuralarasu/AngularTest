module.exports = function () {

	var routes = [
		{
			name: 'errorManagementLayout',
			parent: 'dashboard',
			abstract: true,
			views: {
				'appBody@': {
					templateUrl: '/phx/sidebar.tpl.html',
					controller: ['helpRouteService', function (helpRoute) {
						helpRoute.init();
					}]
				},
				'leftNavListView@errorManagementLayout': {
					template: require('html!./views/sidebar.html'),
					controller: 'phxCommonAsideNavigationController',
					controllerAs: 'ctrl'
				},
				'breadcrumb@errorManagementLayout': {
                    template: require('html!./views/breadcrumb.html')
                }
			},
			resolve: {
				jsBundle: ['jsBundleResolver', function (jsBundleResolver) {
					return jsBundleResolver(function (app, resolve) {
						require.ensure([], function () {
							app.register(require('./app.js'));
							resolve();
						});
					});
				}]
			}
		},
		{
			name: 'errorManagement',
			parent: 'errorManagementLayout',
			url: 'errorManagement/',
			views: {
				'pageContainer': {
					template: require('html!./views/index.html'),
					controller: "ErrorManagementController",
					controllerAs: "ctrl"
				}
			}
		},
		{
			name: 'errorDetails',
			parent: 'errorManagementLayout',
			url: 'errorDetails/:id',
			views: {
				'pageContainer': {
					template: require('html!./views/errorDetails.html'),
					controller: "ErrorDetailsController",
					controllerAs: "ctrl"
				}
			}
		},
		{
			name: 'cloverleaf',
			parent: 'errorManagement',
			url: 'cloverleaf/',
			views: {
				'modulePages': {
					template: require('html!./views/cloverleafErrorManagement.html'),
					controller: "ErrorManagementController",
					controllerAs: "ctrl"
				}
			}
		},
		{
			name: 'eorErrorManagement',
			parent: 'errorManagement',
			url: 'eorErrorManagement/',
			views: {
				'modulePages': {
					template: require('html!./views/index.html'),
					controller: "ErrorManagementController",
					controllerAs: "ctrl"
				}
			}
		}
	];




	/**
	 * Bit of code to define the module for all routes, this will be added to the body.className to add another level
	 * of specificity to the classes
	 */
	return function (r) {
		r.map(function (o) {
			o.data = {
				module: 'errorManagement.Module'
			}
		});
		return r;
	}(routes);
}();
