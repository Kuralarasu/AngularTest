module.exports = function (app) {

    "use strict";

    app.factory('ERROR_MANAGEMENT_CONSTANTS', function(EnvironmentConstants){

        var urlObj = {
        //Error Management
        "errorMangementApiUrl": EnvironmentConstants.host + EnvironmentConstants.errorManagementServicePort + "/api/",
        //Workflow Assembley
        "resendOrderApiUrl": EnvironmentConstants.host + EnvironmentConstants.messageAssemblyServiceport + "/api/",
        //Resend Identifiers
        "zavacorSendId": 1,       
        "workflowSendId": 2,
        "orderSendId": 3,
        "resultSendId": 4,
        "cloverleafSendId": 5,
        "externalSendId": 6,
        "orderInsertTermianteSendId": 7,
        "orderTerminateSendId": 8,
        "resultTerminateSendId": 9,
        "zavOErrorSendId": 1007,       
        "cimEventSendId": 1008,
        "cimEventTerminateSendId": 1009,
        "zavResendOrder": 1010,
        "externalResend": 1011
    }

    return urlObj;
    });
};
