Error.stackTraceLimit = Infinity;


//IMPORT ALL THE OF ANGULAR LIBRARIES


//require('../bower_components/angular-mocks/angular-mocks.js');
/*require('../bower_components/angular/angular.js');
require('../bower_components/angular-mocks/angular-mocks.js');
//require('../bower_components/phoenix/jasmine-jquery/lib/jasmine-jquery.js');
//IMPORT THE APPLICATION ENTRIES
require('../bower_components/phoenix/src/_common/app');
require('../bower_components/phoenix/src/_common/bootstrap');

//IMPORT ALL OF DEV VENDOR'S LIBRARIES


require('../bower_components/phoenix/src/phxRoot.js');
require('../src/ReferenceData/app.js');
require('../src/ErrorManagement/app.js');*/
require('../src/phoenix/src/_common/vendors.imports.js');
require('../node_modules/angular/angular.js');
require('../node_modules/angular-mocks/angular-mocks.js');
require('../src/phoenix/phxRoot.js');
require('../src/vendors.js');
require('../src/ReferenceData/app.js');

/**
 * ./ROOT/COMPONENTS
 * This will inject all necessary components into Karma test file for dependencies injection
 * @param requireContext
 * @returns {*}
 */

function requireAll(requireContext) {
	return requireContext.keys().map(requireContext);
}
// requires and returns all modules that match


// //LOADING ALL THE TEST WITHIN THE TEST DIRECTORY
// var appContext = require.context('../test', true, /[^\/]+test\/*\.js$/g);
// appContext.keys().forEach(appContext);


//LOADING ALL THE TEST WITHIN THE SRC DIRECTORY
//var appContext = require.context('../test/unit/eor/', true, /[^\/]+test\/*\.js$/g);
var appContext = require.context('../src/test/', true, /[^\/]+test\/*\.js$/g);
appContext.keys().forEach(appContext);





