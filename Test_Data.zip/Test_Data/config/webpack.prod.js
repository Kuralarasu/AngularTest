const path = require("path");

const webpack = require('webpack');
const webpackMerge = require('webpack-merge');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const commonConfig = require('./webpack.common.js');
const helpers = require('./helpers');
const CompressionPlugin = require("compression-webpack-plugin");
const CopyWebpackPlugin = require('copy-webpack-plugin');
const ngAnnotatePlugin = require('ng-annotate-webpack-plugin');


const ENV = process.env.NODE_ENV = process.env.ENV = 'production';

module.exports = webpackMerge(commonConfig, {
	devtool: 'source-map',
	debug: false,
	output: {
		path: helpers.root('dist'),
		filename: '[name].[chunkhash].bundle.js',
		sourceMapFilename: '[name].[chunkhash].bundle.map',
		chunkFilename: '[id].[chunkhash].chunk.js'
	},
	htmlLoader: {
		minimize: true,
		removeAttributeQuotes: false,
		caseSensitive: true,
		customAttrSurround: [
			[/#/, /(?:)/],
			[/\*/, /(?:)/],
			[/\[?\(?/, /(?:)/]
		],
		customAttrAssign: [/\)?\]?=/]
	},

	plugins: [
		new ngAnnotatePlugin({
			add: true
			// other ng-annotate options here
		}),
		new webpack.IgnorePlugin(/spec\.js$/),
		new webpack.NoErrorsPlugin(),
		new webpack.optimize.DedupePlugin(),
		new webpack.optimize.MinChunkSizePlugin({
			minChunkSize: 51200 // ~50kb
		}),
		new webpack.optimize.UglifyJsPlugin({
			preserveComments: false,
			mangle: {
				screw_ie8: true,
				except: ['$super', '$', 'exports', 'require']
			},
			compress: {
				screw_ie8: true,
				sequences: true,
				dead_code: true,
				conditionals: true,
				booleans: true,
				unused: true,
				if_return: true,
				join_vars: true,
				drop_console: true
			}
		}),
		new ExtractTextPlugin('[name].[hash].css'),
		new webpack.DefinePlugin({
			'PRODUCTION_ENVIRONMENT': JSON.stringify(ENV),
			'APP_INFORMATION': helpers.webpackDefinePlugin(ENV),
			'process.env': {
				'ENV': JSON.stringify(ENV)
			}
		}),
		new CompressionPlugin({
			asset: '[path].gz[query]',
			algorithm: 'gzip',
			test: /\.js$|\.html$/,
			threshold: 10240,
			minRatio: 0.8
		}),
		new CopyWebpackPlugin([
			{
				context: helpers.root('src', 'assets'),
				from: {glob: '**/*', dot: true},
				ignore: ['.gitkeep'],
				to: helpers.root('dist', 'assets')
			}, {
				from: helpers.root('config', 'bootstrap.txt'),
				to: helpers.root('dist', 'bootstrap.txt')
			}
		])
	]
});
