var path = require("path");
var webpack = require('webpack');
var helpers = require('./helpers');
var ExtractTextPlugin = require('extract-text-webpack-plugin');

var HtmlWebpackPlugin = require('html-webpack-plugin');
var projectRoot = path.dirname(__dirname);


/*
 * Webpack Constants
 */
var METADATA = {
	title: 'LabCorp Phoenix Web UI',
	isDevServer: helpers.isWebpackDevServer()
};

module.exports = {
	context: projectRoot,
	cache: true,

	metadata: METADATA,

	entry: {
		'app': [
			helpers.root('src', 'main.js')
		],
		'vendor': [
			helpers.root('src', 'vendors.js')
		]
	},
	output: {
		path: helpers.root('dist'),
		publicPath: "/",
		filename: '[name].bundle.js'
	},
	resolve: {
		root: path.dirname(__dirname),
		modulesDirectories: ['.tmp', 'node_modules', 'vendors', 'src', 'phoenix'],
		extensions: [
			'',
			'.webpack.js',
			'.web.js',
			'.js',
			'.json',
			'.coffee',
			'.css',
			'.ts',
			'.less',
			'.png',
			'.jpg',
			'.woff',
			'.woff2',
			'.tsv'
		],
		alias: {
			jquery: 'jquery/dist/jquery',
			angular: 'angular/angular',
			jsface: 'jsface/dist/jsface',
			saveAs: 'FileSaver/FileSaver',
			moment: 'moment/moment'
		}
	},
	resolveLoader: {
		root: helpers.root('node_modules'),
		modulesDirectories: ['node_modules'],
		fallback: helpers.root('node_modules')
	},
	module: {
		noParse: [
			/\.\/phoenix\/+/
		],
		loaders: [

			{
				test: /^(?!.*\.min\.css$).*\.css$/,
				exclude: helpers.root('src'),
				loader: ExtractTextPlugin.extract('style', 'css?sourceMap')
			},
			{
				test: /\.less$/,
				exclude: helpers.root('src'),
				loader: ExtractTextPlugin.extract("style-loader", "css-loader!postcss-loader!less-loader")
			},
			{
				test: /^(?!.*\.min\.css$).*\.css$/,
				include: helpers.root('src'),
				loader: "style!css?root=."
			},
			{
				test: /\.less$/,
				include: helpers.root('src'),
				loader: "style!css!less?root=."
			},
			//TODO: fix all the code to depend on pre loaded config
			// {test: /\.html$/, loader: "html"},
			{
				test: /\.svg$/,
				loader: 'url-loader?limit=65000&mimetype=image/svg+xml&name=style/fonts/[name]-[hash].[ext]'
			},
			{
				test: /\.woff$/,
				loader: 'url-loader?limit=65000&mimetype=application/font-woff&name=style/fonts/[name]-[hash].[ext]'
			},
			{
				test: /\.woff2$/,
				loader: 'url-loader?limit=65000&mimetype=application/font-woff2&name=style/fonts/[name]-[hash].[ext]'
			},
			{
				test: /\.[ot]tf$/,
				loader: 'url-loader?limit=65000&mimetype=application/octet-stream&name=style/fonts/[name]-[hash].[ext]'
			},
			{
				test: /\.eot$/,
				loader: 'url-loader?limit=65000&mimetype=application/vnd.ms-fontobject&name=style/fonts/[name]-[hash].[ext]'
			},

			//required for images file loaders
			{test: /\.(png|jpg|gif)$/, loader: "url-loader?limit=50000&name=[path][name].[ext]"},
			{test: /\.worker/, loader: "webworker-loader"}
		]
	},

	plugins: [
		new webpack.optimize.CommonsChunkPlugin({
			name: [
				'vendor',
				'app'
			].reverse()
		}),
		new webpack.optimize.CommonsChunkPlugin({
			minChunks: Infinity,
			name: 'common',
			filename: 'common.js',
			sourceMapFilename: 'common.map'
		}),
		new HtmlWebpackPlugin({
			// hash: true,
			minify: {
				removeComments: true,
				collapseWhitespace: true,
				conservativeCollapse: true,
				collapseBooleanAttributes: false,
				removeCommentsFromCDATA: true
			},
			template: helpers.root('src', 'index.html'),
			chunksSortMode: 'dependency'

		}),
		new webpack.ProvidePlugin({
			"$": "jquery",
			"jQuery": "jquery",
			"jquery": "jquery",
			"window.jQuery": "jquery",
			"jsface": "jsface",
			"saveAs": "saveAs"
		})
	],

	/*
	 * Include polyfills or mocks for various node stuff
	 * Description: Node configuration
	 *
	 * See: https://webpack.github.io/docs/configuration.html#node
	 */
	node: {
		fs: 'empty',
		global: 'window',
		crypto: 'empty',
		process: true,
		module: false,
		clearImmediate: false,
		setImmediate: false
	}


};
