var __PHOENIX_URL__ = 'https://dev2-phoenix.labcorp.com/web-ui/#/';
var helpers = require('./helpers');

// A reference configuration file.
exports.config = {

	//Jasmine 2.x version
	framework: 'jasmine2',

	// The location of the selenium standalone server .jar file.
	seleniumServerJar: helpers.root('node_modules', 'protractor/selenium/selenium-server-standalone-2.45.0.jar'),

	// The port to start the selenium server on, or null if the server should
	// find its own unused port.
	seleniumPort: 4444,

	chromeDriver: helpers.root('node_modules', 'protractor/selenium/chromedriver'),
	seleniumArgs: [],

	// Spec patterns are relative to the location of this config.
	specs: ['../test/e2e/**/*_e2e.js'],

	capabilities: {
		'browserName': 'chrome'
	},

	// A base URL for your application under test. Calls to protractor.get()
	// with relative paths will be prepended with this.
	baseUrl: __PHOENIX_URL__,
	// Selector for the element housing the angular app - this defaults to
	// body, but is necessary if ng-app is on a descendant of <body>
	rootElement: 'body',

	// ----- Options to be passed to minijasminenode -----
	jasmineNodeOpts: {

		// If true, print colors to the terminal.
		showColors: true,
		// Default time to wait in ms before a test fails.
		defaultTimeoutInterval: 30000,

		//removes the deafult 'spec' console printer
		print: function () {
		}
	},

	onPrepare: function () {
		console.log("This is from onPrepare() in protractor.conf.js");
		browser.manage().window().maximize();

		//Setup jasmine XML report
		/*require('jasmine-reporters');
		 jasmine.getEnv().addReporter(
		 new jasmine.JUnitXmlReporter(null, true, true, "e2e-test-results.xml")
		 );*/

		// add jasmine spec reporter
		var SpecReporter = require('jasmine-spec-reporter');
		jasmine.getEnv().addReporter(new SpecReporter({displayStacktrace: true}));

		//commonjs 'require()' needs the path to relative to where it gets pulled in.
		//that might be convenient at times, but also,
		//having an option to requrie from root is helpful at times
		//__basedire__ is used to require from e2e root directory
		var path = require("path");
		global.__basedir__ = path.resolve('.', 'test/e2e/') + '/';
		console.log('__basedir__ configured for commonjs require(): ', __basedir__);


		//Handle Login Screen
		browser.driver.get(__PHOENIX_URL__ + '#/login');
		element(by.model('auth.user.username')).sendKeys('wtadmin');
		element(by.model('auth.user.password')).sendKeys('labcorp1');
		element(by.buttonText('Log In')).click();

		// Login takes some time, so wait until it's done.
		// For the test app's login, we know it's done when it redirects to
		// index.html.
		return browser.driver.wait(function () {
			return browser.driver.getCurrentUrl().then(function (url) {
				return /#\/$/.test(url);
			});
		}, 10000);

	}
};
