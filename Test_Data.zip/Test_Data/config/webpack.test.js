var webpack = require('webpack');
var commonConfig = require('./webpack.common.js');
var helpers = require('./helpers');
var ExtractTextPlugin = require('extract-text-webpack-plugin');

const ENV = process.env.NODE_ENV = process.env.ENV = 'development';


module.exports = {
	devtool: 'inline-source-map',
	resolve: Object.assign({}, commonConfig.resolve, {
		modulesDirectories: ['.', '.tmp', 'node_modules', 'vendors', 'src', 'phoenix']
	}),
	resolveLoader: commonConfig.resolveLoader,
	module: commonConfig.module,
	plugins: [
		new ExtractTextPlugin('[name].css'),
		new webpack.DefinePlugin({
			'PRODUCTION_ENVIRONMENT': JSON.stringify(ENV),
			'APP_INFORMATION': helpers.webpackDefinePlugin(ENV),
			'process.env': {
				'ENV': JSON.stringify(ENV)
			}
		}),
		new webpack.ProvidePlugin({
			"$": "jquery",
			"jQuery": "jquery",
			"window.jQuery": "jquery",
			"jsface": "jsface",
			"saveAs": "saveAs"

		})
	],
	/*
	 * Include polyfills or mocks for various node stuff
	 * Description: Node configuration
	 *
	 * See: https://webpack.github.io/docs/configuration.html#node
	 */
	node: commonConfig.node
};
