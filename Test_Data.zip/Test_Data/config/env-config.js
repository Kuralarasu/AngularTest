"use strict";

 module.exports = function(){

 return angular.module('env-config', [])

.constant('EnvironmentConstants', {name:'development',host:'http://dfwdw0app152.ent.covance.com:',zavacorServiceport:'21567',userAuthServiceport:'54576',hl7ComposerRestAPIServiceport:'51528',labServiceport:'43015',cimServiceport:'21599',errorManagementServicePort:'53198',receiveResultsRestAPIServiceport:'55451',transactionIndexingRestAPIServiceport:'14306',messageAssemblyServiceport:'62084',testDataServicePort:'17407',e2eDefaultZavacor:'VIRGO'})

;
}