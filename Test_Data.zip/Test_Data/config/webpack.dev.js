var path = require("path"),
	fs = require('fs');

var webpack = require('webpack');
var webpackMerge = require('webpack-merge');
var ExtractTextPlugin = require('extract-text-webpack-plugin');
var commonConfig = require('./webpack.common.js');
var helpers = require('./helpers');

var userConfig = fs.existsSync('.user.config.js') ? require('./.user.config') : {
	devServer: {
		historyApiFallback: true,
		stats: 'minimal'
	}
};

const ENV = process.env.NODE_ENV = process.env.ENV = 'development';


const HOST = process.env.HOST || 'localhost';
const PORT = process.env.PORT || 8080;
const HMR = helpers.hasProcessFlag('hot');
const METADATA = webpackMerge(commonConfig.metadata, {
	host: HOST,
	port: PORT,
	ENV: ENV,
	HMR: HMR
});


module.exports = webpackMerge(commonConfig, {
	debug: true,
	devtool: '#eval',
	output: {
		filename: "[name].bundle.js",
		chunkFilename: "[id].[chunkhash].js"
	},
	stats: {
		colors: true,
		reasons: true
	},
	plugins: [
		new ExtractTextPlugin('[name].css',
			{
				//I dont need this in development
				disable: true
			}),
		new webpack.DefinePlugin({
			'PRODUCTION_ENVIRONMENT': JSON.stringify(ENV),
			'APP_INFORMATION': helpers.webpackDefinePlugin(ENV),
			'process.env': {
				'ENV': JSON.stringify(ENV)
			}
		})
	],
	devServer: {
		port: METADATA.port,
		host: METADATA.host,
		historyApiFallback: true,
		outputPath: helpers.root('dist'),
		stats: 'minimal'
	}
}, userConfig);
