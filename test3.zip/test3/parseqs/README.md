Provides methods for converting an object into string representation, and vice versa.
