import { Configuration } from "../configuration";
export declare class ColorsDisplay {
    static init(configuration: Configuration): void;
}
